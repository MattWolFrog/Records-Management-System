﻿
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Animation1 As Utilities.BunifuPages.BunifuAnimatorNS.Animation = New Utilities.BunifuPages.BunifuAnimatorNS.Animation()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim StateProperties1 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties2 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties3 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties4 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties5 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties6 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties7 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties8 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim BorderEdges1 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges2 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim StateProperties9 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties10 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties11 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties12 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties13 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties14 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties15 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties16 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties17 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties18 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties19 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties20 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties21 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties22 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties23 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties24 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties25 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties26 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties27 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties28 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties29 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties30 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties31 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties32 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim StateProperties33 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties34 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties35 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties36 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties37 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties38 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties39 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties40 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties41 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties42 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties43 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties44 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties45 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties46 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties47 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties48 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim BorderEdges3 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim StateProperties49 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties50 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties51 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties52 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties53 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties54 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties55 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties56 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties57 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties58 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties59 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties60 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties61 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties62 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties63 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties64 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim BorderEdges4 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges5 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges6 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges7 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges8 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges9 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges10 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges11 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges12 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges13 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Me.pnlTopBar = New System.Windows.Forms.Panel()
        Me.pcbMinimize = New System.Windows.Forms.PictureBox()
        Me.pcbClose = New System.Windows.Forms.PictureBox()
        Me.pnlMainPage = New System.Windows.Forms.Panel()
        Me.pages = New Bunifu.UI.WinForms.BunifuPages()
        Me.tabDashboard = New System.Windows.Forms.TabPage()
        Me.BunifuPanel4 = New Bunifu.UI.WinForms.BunifuPanel()
        Me.BunifuPanel7 = New Bunifu.UI.WinForms.BunifuPanel()
        Me.lblViolation = New Bunifu.UI.WinForms.BunifuLabel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.BunifuLabel32 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuPanel5 = New Bunifu.UI.WinForms.BunifuPanel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.lblStudent = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel31 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuPanel6 = New Bunifu.UI.WinForms.BunifuPanel()
        Me.lblAY = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel29 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel30 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel28 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.tabStudent = New System.Windows.Forms.TabPage()
        Me.BunifuLabel2 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.dgvStudent = New Bunifu.UI.WinForms.BunifuDataGridView()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEditStudent = New System.Windows.Forms.DataGridViewImageColumn()
        Me.colDeleteStudent = New System.Windows.Forms.DataGridViewImageColumn()
        Me.lblAddStudent = New System.Windows.Forms.LinkLabel()
        Me.tabViolation = New System.Windows.Forms.TabPage()
        Me.txtSearch = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuPanel1 = New Bunifu.UI.WinForms.BunifuPanel()
        Me.txtSanction = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel8 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.btnCancel = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnSave = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.cboTypeV = New Bunifu.UI.WinForms.BunifuDropdown()
        Me.BunifuLabel9 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel10 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel11 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtViolation = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.txtAY = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel12 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.pnlPersonalInfo = New Bunifu.UI.WinForms.BunifuPanel()
        Me.BunifuLabel7 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtSection = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.txtProgram = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel4 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel5 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.lblPersonalInfo = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtName = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.txtSno = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel6 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel3 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.dgvViolation = New Bunifu.UI.WinForms.BunifuDataGridView()
        Me.tabRecords = New System.Windows.Forms.TabPage()
        Me.dgvDisplay = New Bunifu.UI.WinForms.BunifuDataGridView()
        Me.DataGridViewTextBoxColumn26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn30 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn31 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn32 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn33 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn34 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgvRecords1 = New Bunifu.UI.WinForms.BunifuDataGridView()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn28 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn29 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDisplay = New System.Windows.Forms.DataGridViewImageColumn()
        Me.cboAYCode = New Bunifu.UI.WinForms.BunifuDropdown()
        Me.BunifuLabel14 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel13 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.tabProgram = New System.Windows.Forms.TabPage()
        Me.lblTitle = New Bunifu.UI.WinForms.BunifuLabel()
        Me.dgvProgram = New Bunifu.UI.WinForms.BunifuDataGridView()
        Me.colNumbering = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PCODE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescription = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cboType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEdit = New System.Windows.Forms.DataGridViewImageColumn()
        Me.colDelete = New System.Windows.Forms.DataGridViewImageColumn()
        Me.linkLblAddNew = New System.Windows.Forms.LinkLabel()
        Me.tabSection = New System.Windows.Forms.TabPage()
        Me.BunifuLabel1 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.dgvSection = New Bunifu.UI.WinForms.BunifuDataGridView()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSectionID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSection = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPcode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEditSection = New System.Windows.Forms.DataGridViewImageColumn()
        Me.colDeleteSection = New System.Windows.Forms.DataGridViewImageColumn()
        Me.lblAddsection = New System.Windows.Forms.LinkLabel()
        Me.tabAcademic = New System.Windows.Forms.TabPage()
        Me.llblAYList = New Bunifu.UI.WinForms.BunifuLabel()
        Me.dgvAY = New Bunifu.UI.WinForms.BunifuDataGridView()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOpen = New System.Windows.Forms.DataGridViewImageColumn()
        Me.colClose = New System.Windows.Forms.DataGridViewImageColumn()
        Me.lblAddAY = New System.Windows.Forms.LinkLabel()
        Me.tabUserAcc = New System.Windows.Forms.TabPage()
        Me.BunifuPanel3 = New Bunifu.UI.WinForms.BunifuPanel()
        Me.BunifuLabel22 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel23 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel24 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtCPUsername = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel25 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtCPOldPass = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel26 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtCPNewPass = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel27 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtCPConfirmPass = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.btnUpdate = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.BunifuLabel15 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuPanel2 = New Bunifu.UI.WinForms.BunifuPanel()
        Me.BunifuLabel21 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel16 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel20 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtUsername = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel19 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtPassword = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel18 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtConfirmPass = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel17 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtNameUA = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.btnSaveUA = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblSystemTitle = New System.Windows.Forms.Label()
        Me.lblCurrentUser = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.fpnlSidebar = New System.Windows.Forms.FlowLayoutPanel()
        Me.pnlButtons = New System.Windows.Forms.Panel()
        Me.pnlIndicator = New Bunifu.UI.WinForms.BunifuUserControl()
        Me.btnUserAccount = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnAcademic = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnSection = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnProgram = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnRecords = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnViolation = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnStudent = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnDashboard = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnLogout = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.ElipseFrmMain = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.SnbInformation = New Bunifu.UI.WinForms.BunifuSnackbar(Me.components)
        Me.DataGridViewImageColumn1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn2 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn3 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn4 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn5 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn6 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn7 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn8 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn9 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pnlTopBar.SuspendLayout()
        CType(Me.pcbMinimize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlMainPage.SuspendLayout()
        Me.pages.SuspendLayout()
        Me.tabDashboard.SuspendLayout()
        Me.BunifuPanel4.SuspendLayout()
        Me.BunifuPanel7.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuPanel5.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuPanel6.SuspendLayout()
        Me.tabStudent.SuspendLayout()
        CType(Me.dgvStudent, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabViolation.SuspendLayout()
        Me.BunifuPanel1.SuspendLayout()
        Me.pnlPersonalInfo.SuspendLayout()
        CType(Me.dgvViolation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabRecords.SuspendLayout()
        CType(Me.dgvDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvRecords1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabProgram.SuspendLayout()
        CType(Me.dgvProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabSection.SuspendLayout()
        CType(Me.dgvSection, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabAcademic.SuspendLayout()
        CType(Me.dgvAY, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabUserAcc.SuspendLayout()
        Me.BunifuPanel3.SuspendLayout()
        Me.BunifuPanel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.fpnlSidebar.SuspendLayout()
        Me.pnlButtons.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlTopBar
        '
        Me.pnlTopBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.pnlTopBar.Controls.Add(Me.pcbMinimize)
        Me.pnlTopBar.Controls.Add(Me.pcbClose)
        Me.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTopBar.Location = New System.Drawing.Point(0, 0)
        Me.pnlTopBar.Name = "pnlTopBar"
        Me.pnlTopBar.Size = New System.Drawing.Size(1600, 32)
        Me.pnlTopBar.TabIndex = 1
        '
        'pcbMinimize
        '
        Me.pcbMinimize.BackColor = System.Drawing.Color.Transparent
        Me.pcbMinimize.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_minimize_24__1_
        Me.pcbMinimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pcbMinimize.Dock = System.Windows.Forms.DockStyle.Right
        Me.pcbMinimize.Location = New System.Drawing.Point(1540, 0)
        Me.pcbMinimize.Name = "pcbMinimize"
        Me.pcbMinimize.Size = New System.Drawing.Size(30, 32)
        Me.pcbMinimize.TabIndex = 6
        Me.pcbMinimize.TabStop = False
        '
        'pcbClose
        '
        Me.pcbClose.BackColor = System.Drawing.Color.Transparent
        Me.pcbClose.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_close_24__1_
        Me.pcbClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pcbClose.Dock = System.Windows.Forms.DockStyle.Right
        Me.pcbClose.Location = New System.Drawing.Point(1570, 0)
        Me.pcbClose.Name = "pcbClose"
        Me.pcbClose.Size = New System.Drawing.Size(30, 32)
        Me.pcbClose.TabIndex = 5
        Me.pcbClose.TabStop = False
        '
        'pnlMainPage
        '
        Me.pnlMainPage.BackColor = System.Drawing.Color.White
        Me.pnlMainPage.Controls.Add(Me.pages)
        Me.pnlMainPage.Location = New System.Drawing.Point(240, 32)
        Me.pnlMainPage.Name = "pnlMainPage"
        Me.pnlMainPage.Size = New System.Drawing.Size(1360, 818)
        Me.pnlMainPage.TabIndex = 2
        '
        'pages
        '
        Me.pages.Alignment = System.Windows.Forms.TabAlignment.Bottom
        Me.pages.AllowTransitions = True
        Me.pages.Controls.Add(Me.tabDashboard)
        Me.pages.Controls.Add(Me.tabStudent)
        Me.pages.Controls.Add(Me.tabViolation)
        Me.pages.Controls.Add(Me.tabRecords)
        Me.pages.Controls.Add(Me.tabProgram)
        Me.pages.Controls.Add(Me.tabSection)
        Me.pages.Controls.Add(Me.tabAcademic)
        Me.pages.Controls.Add(Me.tabUserAcc)
        Me.pages.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pages.Location = New System.Drawing.Point(0, 0)
        Me.pages.Multiline = True
        Me.pages.Name = "pages"
        Me.pages.Page = Me.tabViolation
        Me.pages.PageIndex = 2
        Me.pages.PageName = "tabViolation"
        Me.pages.PageTitle = "Violation Entry"
        Me.pages.SelectedIndex = 0
        Me.pages.Size = New System.Drawing.Size(1360, 818)
        Me.pages.TabIndex = 0
        Animation1.AnimateOnlyDifferences = True
        Animation1.BlindCoeff = CType(resources.GetObject("Animation1.BlindCoeff"), System.Drawing.PointF)
        Animation1.LeafCoeff = 0!
        Animation1.MaxTime = 1.0!
        Animation1.MinTime = 0!
        Animation1.MosaicCoeff = CType(resources.GetObject("Animation1.MosaicCoeff"), System.Drawing.PointF)
        Animation1.MosaicShift = CType(resources.GetObject("Animation1.MosaicShift"), System.Drawing.PointF)
        Animation1.MosaicSize = 0
        Animation1.Padding = New System.Windows.Forms.Padding(0, 0, 0, 0)
        Animation1.RotateCoeff = 0!
        Animation1.RotateLimit = 0!
        Animation1.ScaleCoeff = CType(resources.GetObject("Animation1.ScaleCoeff"), System.Drawing.PointF)
        Animation1.SlideCoeff = CType(resources.GetObject("Animation1.SlideCoeff"), System.Drawing.PointF)
        Animation1.TimeCoeff = 0!
        Animation1.TransparencyCoeff = 0!
        Me.pages.Transition = Animation1
        Me.pages.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.VertBlind
        '
        'tabDashboard
        '
        Me.tabDashboard.Controls.Add(Me.BunifuPanel4)
        Me.tabDashboard.Controls.Add(Me.BunifuLabel28)
        Me.tabDashboard.Location = New System.Drawing.Point(4, 4)
        Me.tabDashboard.Name = "tabDashboard"
        Me.tabDashboard.Padding = New System.Windows.Forms.Padding(3)
        Me.tabDashboard.Size = New System.Drawing.Size(1352, 792)
        Me.tabDashboard.TabIndex = 0
        Me.tabDashboard.Text = "Dashboard"
        Me.tabDashboard.UseVisualStyleBackColor = True
        '
        'BunifuPanel4
        '
        Me.BunifuPanel4.BackgroundColor = System.Drawing.Color.Transparent
        Me.BunifuPanel4.BackgroundImage = CType(resources.GetObject("BunifuPanel4.BackgroundImage"), System.Drawing.Image)
        Me.BunifuPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuPanel4.BorderColor = System.Drawing.Color.DarkGray
        Me.BunifuPanel4.BorderRadius = 25
        Me.BunifuPanel4.BorderThickness = 1
        Me.BunifuPanel4.Controls.Add(Me.BunifuPanel7)
        Me.BunifuPanel4.Controls.Add(Me.BunifuPanel5)
        Me.BunifuPanel4.Controls.Add(Me.BunifuPanel6)
        Me.BunifuPanel4.Controls.Add(Me.BunifuLabel30)
        Me.BunifuPanel4.Location = New System.Drawing.Point(35, 62)
        Me.BunifuPanel4.Name = "BunifuPanel4"
        Me.BunifuPanel4.ShowBorders = True
        Me.BunifuPanel4.Size = New System.Drawing.Size(1181, 242)
        Me.BunifuPanel4.TabIndex = 50
        '
        'BunifuPanel7
        '
        Me.BunifuPanel7.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(107, Byte), Integer))
        Me.BunifuPanel7.BackgroundImage = CType(resources.GetObject("BunifuPanel7.BackgroundImage"), System.Drawing.Image)
        Me.BunifuPanel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuPanel7.BorderColor = System.Drawing.Color.Transparent
        Me.BunifuPanel7.BorderRadius = 25
        Me.BunifuPanel7.BorderThickness = 1
        Me.BunifuPanel7.Controls.Add(Me.lblViolation)
        Me.BunifuPanel7.Controls.Add(Me.PictureBox2)
        Me.BunifuPanel7.Controls.Add(Me.BunifuLabel32)
        Me.BunifuPanel7.Location = New System.Drawing.Point(784, 51)
        Me.BunifuPanel7.Name = "BunifuPanel7"
        Me.BunifuPanel7.ShowBorders = True
        Me.BunifuPanel7.Size = New System.Drawing.Size(366, 169)
        Me.BunifuPanel7.TabIndex = 52
        '
        'lblViolation
        '
        Me.lblViolation.AllowParentOverrides = False
        Me.lblViolation.AutoEllipsis = False
        Me.lblViolation.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblViolation.CursorType = System.Windows.Forms.Cursors.Default
        Me.lblViolation.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblViolation.ForeColor = System.Drawing.Color.White
        Me.lblViolation.Location = New System.Drawing.Point(24, 72)
        Me.lblViolation.Name = "lblViolation"
        Me.lblViolation.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblViolation.Size = New System.Drawing.Size(40, 51)
        Me.lblViolation.TabIndex = 56
        Me.lblViolation.Text = "00"
        Me.lblViolation.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblViolation.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.illegal1
        Me.PictureBox2.Location = New System.Drawing.Point(247, 66)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(85, 81)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 56
        Me.PictureBox2.TabStop = False
        '
        'BunifuLabel32
        '
        Me.BunifuLabel32.AllowParentOverrides = False
        Me.BunifuLabel32.AutoEllipsis = False
        Me.BunifuLabel32.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel32.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel32.Font = New System.Drawing.Font("Cascadia Mono", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel32.ForeColor = System.Drawing.Color.White
        Me.BunifuLabel32.Location = New System.Drawing.Point(24, 22)
        Me.BunifuLabel32.Name = "BunifuLabel32"
        Me.BunifuLabel32.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel32.Size = New System.Drawing.Size(165, 25)
        Me.BunifuLabel32.TabIndex = 54
        Me.BunifuLabel32.Text = "Total Violation"
        Me.BunifuLabel32.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel32.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuPanel5
        '
        Me.BunifuPanel5.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.BunifuPanel5.BackgroundImage = CType(resources.GetObject("BunifuPanel5.BackgroundImage"), System.Drawing.Image)
        Me.BunifuPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuPanel5.BorderColor = System.Drawing.Color.Transparent
        Me.BunifuPanel5.BorderRadius = 25
        Me.BunifuPanel5.BorderThickness = 1
        Me.BunifuPanel5.Controls.Add(Me.PictureBox3)
        Me.BunifuPanel5.Controls.Add(Me.lblStudent)
        Me.BunifuPanel5.Controls.Add(Me.BunifuLabel31)
        Me.BunifuPanel5.Location = New System.Drawing.Point(402, 51)
        Me.BunifuPanel5.Name = "BunifuPanel5"
        Me.BunifuPanel5.ShowBorders = True
        Me.BunifuPanel5.Size = New System.Drawing.Size(366, 169)
        Me.BunifuPanel5.TabIndex = 51
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.graduates
        Me.PictureBox3.Location = New System.Drawing.Point(137, 72)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(85, 81)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 57
        Me.PictureBox3.TabStop = False
        '
        'lblStudent
        '
        Me.lblStudent.AllowParentOverrides = False
        Me.lblStudent.AutoEllipsis = False
        Me.lblStudent.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStudent.CursorType = System.Windows.Forms.Cursors.Default
        Me.lblStudent.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudent.ForeColor = System.Drawing.Color.White
        Me.lblStudent.Location = New System.Drawing.Point(24, 81)
        Me.lblStudent.Name = "lblStudent"
        Me.lblStudent.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblStudent.Size = New System.Drawing.Size(40, 51)
        Me.lblStudent.TabIndex = 55
        Me.lblStudent.Text = "00"
        Me.lblStudent.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblStudent.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel31
        '
        Me.BunifuLabel31.AllowParentOverrides = False
        Me.BunifuLabel31.AutoEllipsis = False
        Me.BunifuLabel31.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel31.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel31.Font = New System.Drawing.Font("Cascadia Mono", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel31.ForeColor = System.Drawing.Color.White
        Me.BunifuLabel31.Location = New System.Drawing.Point(24, 22)
        Me.BunifuLabel31.Name = "BunifuLabel31"
        Me.BunifuLabel31.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel31.Size = New System.Drawing.Size(154, 25)
        Me.BunifuLabel31.TabIndex = 54
        Me.BunifuLabel31.Text = "Total Students"
        Me.BunifuLabel31.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel31.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuPanel6
        '
        Me.BunifuPanel6.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.BunifuPanel6.BackgroundImage = CType(resources.GetObject("BunifuPanel6.BackgroundImage"), System.Drawing.Image)
        Me.BunifuPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuPanel6.BorderColor = System.Drawing.Color.Transparent
        Me.BunifuPanel6.BorderRadius = 25
        Me.BunifuPanel6.BorderThickness = 1
        Me.BunifuPanel6.Controls.Add(Me.lblAY)
        Me.BunifuPanel6.Controls.Add(Me.BunifuLabel29)
        Me.BunifuPanel6.Location = New System.Drawing.Point(20, 51)
        Me.BunifuPanel6.Name = "BunifuPanel6"
        Me.BunifuPanel6.ShowBorders = True
        Me.BunifuPanel6.Size = New System.Drawing.Size(366, 169)
        Me.BunifuPanel6.TabIndex = 50
        '
        'lblAY
        '
        Me.lblAY.AllowParentOverrides = False
        Me.lblAY.AutoEllipsis = False
        Me.lblAY.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblAY.CursorType = System.Windows.Forms.Cursors.Default
        Me.lblAY.Font = New System.Drawing.Font("Cascadia Mono", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAY.ForeColor = System.Drawing.Color.White
        Me.lblAY.Location = New System.Drawing.Point(24, 83)
        Me.lblAY.Name = "lblAY"
        Me.lblAY.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblAY.Size = New System.Drawing.Size(132, 29)
        Me.lblAY.TabIndex = 54
        Me.lblAY.Text = "Sample Data"
        Me.lblAY.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblAY.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel29
        '
        Me.BunifuLabel29.AllowParentOverrides = False
        Me.BunifuLabel29.AutoEllipsis = False
        Me.BunifuLabel29.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel29.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel29.Font = New System.Drawing.Font("Cascadia Mono", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel29.ForeColor = System.Drawing.Color.White
        Me.BunifuLabel29.Location = New System.Drawing.Point(24, 22)
        Me.BunifuLabel29.Name = "BunifuLabel29"
        Me.BunifuLabel29.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel29.Size = New System.Drawing.Size(242, 25)
        Me.BunifuLabel29.TabIndex = 53
        Me.BunifuLabel29.Text = "Academic Year/Semester"
        Me.BunifuLabel29.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel29.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel30
        '
        Me.BunifuLabel30.AllowParentOverrides = False
        Me.BunifuLabel30.AutoEllipsis = False
        Me.BunifuLabel30.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel30.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel30.Font = New System.Drawing.Font("Cascadia Mono", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel30.Location = New System.Drawing.Point(20, 17)
        Me.BunifuLabel30.Name = "BunifuLabel30"
        Me.BunifuLabel30.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel30.Size = New System.Drawing.Size(45, 21)
        Me.BunifuLabel30.TabIndex = 42
        Me.BunifuLabel30.Text = "Title"
        Me.BunifuLabel30.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel30.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel28
        '
        Me.BunifuLabel28.AllowParentOverrides = False
        Me.BunifuLabel28.AutoEllipsis = False
        Me.BunifuLabel28.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel28.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel28.Font = New System.Drawing.Font("Cascadia Code", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel28.Location = New System.Drawing.Point(19, 14)
        Me.BunifuLabel28.Name = "BunifuLabel28"
        Me.BunifuLabel28.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel28.Size = New System.Drawing.Size(99, 25)
        Me.BunifuLabel28.TabIndex = 43
        Me.BunifuLabel28.Text = "Dashboard"
        Me.BunifuLabel28.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel28.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'tabStudent
        '
        Me.tabStudent.Controls.Add(Me.BunifuLabel2)
        Me.tabStudent.Controls.Add(Me.dgvStudent)
        Me.tabStudent.Controls.Add(Me.lblAddStudent)
        Me.tabStudent.Location = New System.Drawing.Point(4, 4)
        Me.tabStudent.Name = "tabStudent"
        Me.tabStudent.Padding = New System.Windows.Forms.Padding(3)
        Me.tabStudent.Size = New System.Drawing.Size(1352, 792)
        Me.tabStudent.TabIndex = 1
        Me.tabStudent.Text = "Student Entry"
        Me.tabStudent.UseVisualStyleBackColor = True
        '
        'BunifuLabel2
        '
        Me.BunifuLabel2.AllowParentOverrides = False
        Me.BunifuLabel2.AutoEllipsis = False
        Me.BunifuLabel2.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel2.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel2.Font = New System.Drawing.Font("Cascadia Code", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel2.Location = New System.Drawing.Point(19, 14)
        Me.BunifuLabel2.Name = "BunifuLabel2"
        Me.BunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel2.Size = New System.Drawing.Size(132, 25)
        Me.BunifuLabel2.TabIndex = 5
        Me.BunifuLabel2.Text = "Student List"
        Me.BunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'dgvStudent
        '
        Me.dgvStudent.AllowCustomTheming = False
        Me.dgvStudent.AllowUserToAddRows = False
        Me.dgvStudent.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black
        Me.dgvStudent.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvStudent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvStudent.BackgroundColor = System.Drawing.Color.White
        Me.dgvStudent.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvStudent.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvStudent.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvStudent.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvStudent.ColumnHeadersHeight = 40
        Me.dgvStudent.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.Column6, Me.colEditStudent, Me.colDeleteStudent})
        Me.dgvStudent.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvStudent.CurrentTheme.AlternatingRowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvStudent.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvStudent.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvStudent.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvStudent.CurrentTheme.BackColor = System.Drawing.Color.White
        Me.dgvStudent.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvStudent.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue
        Me.dgvStudent.CurrentTheme.HeaderStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        Me.dgvStudent.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgvStudent.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.dgvStudent.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White
        Me.dgvStudent.CurrentTheme.Name = Nothing
        Me.dgvStudent.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvStudent.CurrentTheme.RowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvStudent.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvStudent.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvStudent.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvStudent.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgvStudent.EnableHeadersVisualStyles = False
        Me.dgvStudent.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvStudent.HeaderBackColor = System.Drawing.Color.DodgerBlue
        Me.dgvStudent.HeaderBgColor = System.Drawing.Color.Empty
        Me.dgvStudent.HeaderForeColor = System.Drawing.Color.White
        Me.dgvStudent.Location = New System.Drawing.Point(19, 57)
        Me.dgvStudent.Name = "dgvStudent"
        Me.dgvStudent.ReadOnly = True
        Me.dgvStudent.RowHeadersVisible = False
        Me.dgvStudent.RowTemplate.Height = 40
        Me.dgvStudent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvStudent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvStudent.Size = New System.Drawing.Size(1325, 729)
        Me.dgvStudent.TabIndex = 2
        Me.dgvStudent.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn10.HeaderText = "#"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.Width = 42
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn11.HeaderText = "STUDENT NO"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.Width = 130
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn12.HeaderText = "LAST NAME"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        Me.DataGridViewTextBoxColumn12.Width = 120
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn13.HeaderText = "FIRST NAME"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn13.Width = 105
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn14.HeaderText = "MIDDLE NAME"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.Width = 141
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn15.HeaderText = "SECTION ID"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.Visible = False
        Me.DataGridViewTextBoxColumn15.Width = 118
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn16.HeaderText = "PROGRAM"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        Me.DataGridViewTextBoxColumn16.Width = 111
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn17.HeaderText = "SECTION"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Width = 98
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn18.HeaderText = "ADDRESS"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column6.HeaderText = "CONTACT NO"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Width = 133
        '
        'colEditStudent
        '
        Me.colEditStudent.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEditStudent.HeaderText = ""
        Me.colEditStudent.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.edit__1_
        Me.colEditStudent.Name = "colEditStudent"
        Me.colEditStudent.ReadOnly = True
        Me.colEditStudent.Width = 5
        '
        'colDeleteStudent
        '
        Me.colDeleteStudent.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDeleteStudent.HeaderText = ""
        Me.colDeleteStudent.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.delete
        Me.colDeleteStudent.Name = "colDeleteStudent"
        Me.colDeleteStudent.ReadOnly = True
        Me.colDeleteStudent.Width = 5
        '
        'lblAddStudent
        '
        Me.lblAddStudent.Font = New System.Drawing.Font("Cascadia Code", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddStudent.Image = CType(resources.GetObject("lblAddStudent.Image"), System.Drawing.Image)
        Me.lblAddStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblAddStudent.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.lblAddStudent.LinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblAddStudent.Location = New System.Drawing.Point(195, 16)
        Me.lblAddStudent.Name = "lblAddStudent"
        Me.lblAddStudent.Size = New System.Drawing.Size(130, 26)
        Me.lblAddStudent.TabIndex = 4
        Me.lblAddStudent.TabStop = True
        Me.lblAddStudent.Text = "    [ADD NEW]"
        Me.lblAddStudent.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        '
        'tabViolation
        '
        Me.tabViolation.Controls.Add(Me.txtSearch)
        Me.tabViolation.Controls.Add(Me.BunifuPanel1)
        Me.tabViolation.Controls.Add(Me.pnlPersonalInfo)
        Me.tabViolation.Controls.Add(Me.BunifuLabel3)
        Me.tabViolation.Controls.Add(Me.dgvViolation)
        Me.tabViolation.Location = New System.Drawing.Point(4, 4)
        Me.tabViolation.Name = "tabViolation"
        Me.tabViolation.Size = New System.Drawing.Size(1352, 792)
        Me.tabViolation.TabIndex = 2
        Me.tabViolation.Text = "Violation Entry"
        Me.tabViolation.UseVisualStyleBackColor = True
        '
        'txtSearch
        '
        Me.txtSearch.AcceptsReturn = False
        Me.txtSearch.AcceptsTab = False
        Me.txtSearch.AnimationSpeed = 200
        Me.txtSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtSearch.BackColor = System.Drawing.Color.White
        Me.txtSearch.BackgroundImage = CType(resources.GetObject("txtSearch.BackgroundImage"), System.Drawing.Image)
        Me.txtSearch.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtSearch.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtSearch.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSearch.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtSearch.BorderRadius = 25
        Me.txtSearch.BorderThickness = 1
        Me.txtSearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtSearch.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearch.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtSearch.DefaultText = ""
        Me.txtSearch.FillColor = System.Drawing.Color.White
        Me.txtSearch.HideSelection = True
        Me.txtSearch.IconLeft = Nothing
        Me.txtSearch.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearch.IconPadding = 10
        Me.txtSearch.IconRight = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_search_24
        Me.txtSearch.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSearch.Lines = New String(-1) {}
        Me.txtSearch.Location = New System.Drawing.Point(19, 60)
        Me.txtSearch.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSearch.MaxLength = 32767
        Me.txtSearch.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtSearch.Modified = False
        Me.txtSearch.Multiline = False
        Me.txtSearch.Name = "txtSearch"
        StateProperties1.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties1.FillColor = System.Drawing.Color.Empty
        StateProperties1.ForeColor = System.Drawing.Color.Empty
        StateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtSearch.OnActiveState = StateProperties1
        StateProperties2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties2.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtSearch.OnDisabledState = StateProperties2
        StateProperties3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties3.FillColor = System.Drawing.Color.Empty
        StateProperties3.ForeColor = System.Drawing.Color.Empty
        StateProperties3.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSearch.OnHoverState = StateProperties3
        StateProperties4.BorderColor = System.Drawing.Color.Silver
        StateProperties4.FillColor = System.Drawing.Color.White
        StateProperties4.ForeColor = System.Drawing.Color.Empty
        StateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtSearch.OnIdleState = StateProperties4
        Me.txtSearch.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSearch.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtSearch.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtSearch.PlaceholderText = "Search Student's Full Name..."
        Me.txtSearch.ReadOnly = False
        Me.txtSearch.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtSearch.SelectedText = ""
        Me.txtSearch.SelectionLength = 0
        Me.txtSearch.SelectionStart = 0
        Me.txtSearch.ShortcutsEnabled = True
        Me.txtSearch.Size = New System.Drawing.Size(306, 45)
        Me.txtSearch.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtSearch.TabIndex = 52
        Me.txtSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtSearch.TextMarginBottom = 0
        Me.txtSearch.TextMarginLeft = 3
        Me.txtSearch.TextMarginTop = 0
        Me.txtSearch.TextPlaceholder = "Search Student's Full Name..."
        Me.txtSearch.UseSystemPasswordChar = False
        Me.txtSearch.WordWrap = True
        '
        'BunifuPanel1
        '
        Me.BunifuPanel1.BackgroundColor = System.Drawing.Color.Transparent
        Me.BunifuPanel1.BackgroundImage = CType(resources.GetObject("BunifuPanel1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuPanel1.BorderColor = System.Drawing.Color.DarkGray
        Me.BunifuPanel1.BorderRadius = 25
        Me.BunifuPanel1.BorderThickness = 1
        Me.BunifuPanel1.Controls.Add(Me.txtSanction)
        Me.BunifuPanel1.Controls.Add(Me.BunifuLabel8)
        Me.BunifuPanel1.Controls.Add(Me.btnCancel)
        Me.BunifuPanel1.Controls.Add(Me.btnSave)
        Me.BunifuPanel1.Controls.Add(Me.cboTypeV)
        Me.BunifuPanel1.Controls.Add(Me.BunifuLabel9)
        Me.BunifuPanel1.Controls.Add(Me.BunifuLabel10)
        Me.BunifuPanel1.Controls.Add(Me.BunifuLabel11)
        Me.BunifuPanel1.Controls.Add(Me.txtViolation)
        Me.BunifuPanel1.Controls.Add(Me.txtAY)
        Me.BunifuPanel1.Controls.Add(Me.BunifuLabel12)
        Me.BunifuPanel1.Location = New System.Drawing.Point(806, 22)
        Me.BunifuPanel1.Name = "BunifuPanel1"
        Me.BunifuPanel1.ShowBorders = True
        Me.BunifuPanel1.Size = New System.Drawing.Size(538, 310)
        Me.BunifuPanel1.TabIndex = 51
        '
        'txtSanction
        '
        Me.txtSanction.AcceptsReturn = False
        Me.txtSanction.AcceptsTab = False
        Me.txtSanction.AnimationSpeed = 200
        Me.txtSanction.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtSanction.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtSanction.BackColor = System.Drawing.Color.White
        Me.txtSanction.BackgroundImage = CType(resources.GetObject("txtSanction.BackgroundImage"), System.Drawing.Image)
        Me.txtSanction.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtSanction.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtSanction.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSanction.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtSanction.BorderRadius = 1
        Me.txtSanction.BorderThickness = 1
        Me.txtSanction.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtSanction.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSanction.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtSanction.DefaultText = ""
        Me.txtSanction.FillColor = System.Drawing.Color.White
        Me.txtSanction.HideSelection = True
        Me.txtSanction.IconLeft = Nothing
        Me.txtSanction.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSanction.IconPadding = 10
        Me.txtSanction.IconRight = Nothing
        Me.txtSanction.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSanction.Lines = New String(-1) {}
        Me.txtSanction.Location = New System.Drawing.Point(102, 201)
        Me.txtSanction.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSanction.MaxLength = 32767
        Me.txtSanction.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtSanction.Modified = False
        Me.txtSanction.Multiline = False
        Me.txtSanction.Name = "txtSanction"
        StateProperties5.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties5.FillColor = System.Drawing.Color.Empty
        StateProperties5.ForeColor = System.Drawing.Color.Empty
        StateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtSanction.OnActiveState = StateProperties5
        StateProperties6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties6.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtSanction.OnDisabledState = StateProperties6
        StateProperties7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties7.FillColor = System.Drawing.Color.Empty
        StateProperties7.ForeColor = System.Drawing.Color.Empty
        StateProperties7.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSanction.OnHoverState = StateProperties7
        StateProperties8.BorderColor = System.Drawing.Color.Silver
        StateProperties8.FillColor = System.Drawing.Color.White
        StateProperties8.ForeColor = System.Drawing.Color.Empty
        StateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtSanction.OnIdleState = StateProperties8
        Me.txtSanction.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSanction.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtSanction.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtSanction.PlaceholderText = "Sanction"
        Me.txtSanction.ReadOnly = False
        Me.txtSanction.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtSanction.SelectedText = ""
        Me.txtSanction.SelectionLength = 0
        Me.txtSanction.SelectionStart = 0
        Me.txtSanction.ShortcutsEnabled = True
        Me.txtSanction.Size = New System.Drawing.Size(247, 45)
        Me.txtSanction.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtSanction.TabIndex = 54
        Me.txtSanction.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtSanction.TextMarginBottom = 0
        Me.txtSanction.TextMarginLeft = 3
        Me.txtSanction.TextMarginTop = 0
        Me.txtSanction.TextPlaceholder = "Sanction"
        Me.txtSanction.UseSystemPasswordChar = False
        Me.txtSanction.WordWrap = True
        '
        'BunifuLabel8
        '
        Me.BunifuLabel8.AllowParentOverrides = False
        Me.BunifuLabel8.AutoEllipsis = False
        Me.BunifuLabel8.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel8.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel8.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel8.Location = New System.Drawing.Point(27, 217)
        Me.BunifuLabel8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel8.Name = "BunifuLabel8"
        Me.BunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel8.Size = New System.Drawing.Size(60, 21)
        Me.BunifuLabel8.TabIndex = 53
        Me.BunifuLabel8.Text = "Sanction"
        Me.BunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'btnCancel
        '
        Me.btnCancel.AllowAnimations = True
        Me.btnCancel.AllowMouseEffects = True
        Me.btnCancel.AllowToggling = False
        Me.btnCancel.AnimationSpeed = 200
        Me.btnCancel.AutoGenerateColors = False
        Me.btnCancel.AutoRoundBorders = False
        Me.btnCancel.AutoSizeLeftIcon = True
        Me.btnCancel.AutoSizeRightIcon = True
        Me.btnCancel.BackColor = System.Drawing.Color.Transparent
        Me.btnCancel.BackColor1 = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.BackgroundImage = CType(resources.GetObject("btnCancel.BackgroundImage"), System.Drawing.Image)
        Me.btnCancel.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.ButtonText = "Cancel"
        Me.btnCancel.ButtonTextMarginLeft = 0
        Me.btnCancel.ColorContrastOnClick = 45
        Me.btnCancel.ColorContrastOnHover = 45
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges1.BottomLeft = True
        BorderEdges1.BottomRight = True
        BorderEdges1.TopLeft = True
        BorderEdges1.TopRight = True
        Me.btnCancel.CustomizableEdges = BorderEdges1
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnCancel.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnCancel.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnCancel.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnCancel.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnCancel.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnCancel.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnCancel.IconMarginLeft = 11
        Me.btnCancel.IconPadding = 10
        Me.btnCancel.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnCancel.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnCancel.IconSize = 25
        Me.btnCancel.IdleBorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.IdleBorderRadius = 18
        Me.btnCancel.IdleBorderThickness = 1
        Me.btnCancel.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.IdleIconLeftImage = Nothing
        Me.btnCancel.IdleIconRightImage = Nothing
        Me.btnCancel.IndicateFocus = False
        Me.btnCancel.Location = New System.Drawing.Point(410, 228)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnCancel.OnDisabledState.BorderRadius = 18
        Me.btnCancel.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnDisabledState.BorderThickness = 1
        Me.btnCancel.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnCancel.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnCancel.OnDisabledState.IconLeftImage = Nothing
        Me.btnCancel.OnDisabledState.IconRightImage = Nothing
        Me.btnCancel.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.btnCancel.onHoverState.BorderRadius = 18
        Me.btnCancel.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.onHoverState.BorderThickness = 1
        Me.btnCancel.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.btnCancel.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.onHoverState.IconLeftImage = Nothing
        Me.btnCancel.onHoverState.IconRightImage = Nothing
        Me.btnCancel.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnIdleState.BorderRadius = 18
        Me.btnCancel.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnIdleState.BorderThickness = 1
        Me.btnCancel.OnIdleState.FillColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.OnIdleState.IconLeftImage = Nothing
        Me.btnCancel.OnIdleState.IconRightImage = Nothing
        Me.btnCancel.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnPressedState.BorderRadius = 18
        Me.btnCancel.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnPressedState.BorderThickness = 1
        Me.btnCancel.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.OnPressedState.IconLeftImage = Nothing
        Me.btnCancel.OnPressedState.IconRightImage = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(78, 40)
        Me.btnCancel.TabIndex = 52
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnCancel.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnCancel.TextMarginLeft = 0
        Me.btnCancel.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnCancel.UseDefaultRadiusAndThickness = True
        '
        'btnSave
        '
        Me.btnSave.AllowAnimations = True
        Me.btnSave.AllowMouseEffects = True
        Me.btnSave.AllowToggling = False
        Me.btnSave.AnimationSpeed = 200
        Me.btnSave.AutoGenerateColors = False
        Me.btnSave.AutoRoundBorders = False
        Me.btnSave.AutoSizeLeftIcon = True
        Me.btnSave.AutoSizeRightIcon = True
        Me.btnSave.BackColor = System.Drawing.Color.Transparent
        Me.btnSave.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnSave.BackgroundImage = CType(resources.GetObject("btnSave.BackgroundImage"), System.Drawing.Image)
        Me.btnSave.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.ButtonText = "Save"
        Me.btnSave.ButtonTextMarginLeft = 0
        Me.btnSave.ColorContrastOnClick = 45
        Me.btnSave.ColorContrastOnHover = 45
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges2.BottomLeft = True
        BorderEdges2.BottomRight = True
        BorderEdges2.TopLeft = True
        BorderEdges2.TopRight = True
        Me.btnSave.CustomizableEdges = BorderEdges2
        Me.btnSave.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSave.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSave.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSave.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSave.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnSave.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnSave.IconMarginLeft = 11
        Me.btnSave.IconPadding = 10
        Me.btnSave.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSave.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnSave.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnSave.IconSize = 25
        Me.btnSave.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.IdleBorderRadius = 18
        Me.btnSave.IdleBorderThickness = 1
        Me.btnSave.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.IdleIconLeftImage = Nothing
        Me.btnSave.IdleIconRightImage = Nothing
        Me.btnSave.IndicateFocus = False
        Me.btnSave.Location = New System.Drawing.Point(410, 177)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSave.OnDisabledState.BorderRadius = 18
        Me.btnSave.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnDisabledState.BorderThickness = 1
        Me.btnSave.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSave.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSave.OnDisabledState.IconLeftImage = Nothing
        Me.btnSave.OnDisabledState.IconRightImage = Nothing
        Me.btnSave.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.onHoverState.BorderRadius = 18
        Me.btnSave.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.onHoverState.BorderThickness = 1
        Me.btnSave.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnSave.onHoverState.IconLeftImage = Nothing
        Me.btnSave.onHoverState.IconRightImage = Nothing
        Me.btnSave.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.OnIdleState.BorderRadius = 18
        Me.btnSave.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnIdleState.BorderThickness = 1
        Me.btnSave.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnSave.OnIdleState.IconLeftImage = Nothing
        Me.btnSave.OnIdleState.IconRightImage = Nothing
        Me.btnSave.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSave.OnPressedState.BorderRadius = 18
        Me.btnSave.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnPressedState.BorderThickness = 1
        Me.btnSave.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSave.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnSave.OnPressedState.IconLeftImage = Nothing
        Me.btnSave.OnPressedState.IconRightImage = Nothing
        Me.btnSave.Size = New System.Drawing.Size(78, 40)
        Me.btnSave.TabIndex = 51
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSave.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnSave.TextMarginLeft = 0
        Me.btnSave.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnSave.UseDefaultRadiusAndThickness = True
        '
        'cboTypeV
        '
        Me.cboTypeV.BackColor = System.Drawing.Color.Transparent
        Me.cboTypeV.BackgroundColor = System.Drawing.Color.White
        Me.cboTypeV.BorderColor = System.Drawing.Color.Silver
        Me.cboTypeV.BorderRadius = 17
        Me.cboTypeV.Color = System.Drawing.Color.Silver
        Me.cboTypeV.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down
        Me.cboTypeV.DisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboTypeV.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cboTypeV.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboTypeV.DisabledForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.cboTypeV.DisabledIndicatorColor = System.Drawing.Color.DarkGray
        Me.cboTypeV.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cboTypeV.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin
        Me.cboTypeV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTypeV.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboTypeV.FillDropDown = True
        Me.cboTypeV.FillIndicator = False
        Me.cboTypeV.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboTypeV.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cboTypeV.ForeColor = System.Drawing.Color.Black
        Me.cboTypeV.FormattingEnabled = True
        Me.cboTypeV.Icon = Nothing
        Me.cboTypeV.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboTypeV.IndicatorColor = System.Drawing.Color.Gray
        Me.cboTypeV.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboTypeV.ItemBackColor = System.Drawing.Color.White
        Me.cboTypeV.ItemBorderColor = System.Drawing.Color.Transparent
        Me.cboTypeV.ItemForeColor = System.Drawing.Color.Black
        Me.cboTypeV.ItemHeight = 26
        Me.cboTypeV.ItemHighLightColor = System.Drawing.Color.DodgerBlue
        Me.cboTypeV.ItemHighLightForeColor = System.Drawing.Color.White
        Me.cboTypeV.Items.AddRange(New Object() {"MINOR OFFENSE", "MAJOR OFFENSE"})
        Me.cboTypeV.ItemTopMargin = 3
        Me.cboTypeV.Location = New System.Drawing.Point(101, 264)
        Me.cboTypeV.Name = "cboTypeV"
        Me.cboTypeV.Size = New System.Drawing.Size(247, 32)
        Me.cboTypeV.TabIndex = 50
        Me.cboTypeV.Text = Nothing
        Me.cboTypeV.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboTypeV.TextLeftMargin = 5
        '
        'BunifuLabel9
        '
        Me.BunifuLabel9.AllowParentOverrides = False
        Me.BunifuLabel9.AutoEllipsis = False
        Me.BunifuLabel9.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel9.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel9.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel9.Location = New System.Drawing.Point(53, 268)
        Me.BunifuLabel9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel9.Name = "BunifuLabel9"
        Me.BunifuLabel9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel9.Size = New System.Drawing.Size(33, 21)
        Me.BunifuLabel9.TabIndex = 49
        Me.BunifuLabel9.Text = "Type"
        Me.BunifuLabel9.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel9.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel10
        '
        Me.BunifuLabel10.AllowParentOverrides = False
        Me.BunifuLabel10.AutoEllipsis = False
        Me.BunifuLabel10.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel10.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel10.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel10.Location = New System.Drawing.Point(25, 126)
        Me.BunifuLabel10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel10.Name = "BunifuLabel10"
        Me.BunifuLabel10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel10.Size = New System.Drawing.Size(62, 21)
        Me.BunifuLabel10.TabIndex = 47
        Me.BunifuLabel10.Text = "Violation"
        Me.BunifuLabel10.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel10.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel11
        '
        Me.BunifuLabel11.AllowParentOverrides = False
        Me.BunifuLabel11.AutoEllipsis = False
        Me.BunifuLabel11.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel11.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel11.Font = New System.Drawing.Font("Cascadia Mono", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel11.Location = New System.Drawing.Point(20, 17)
        Me.BunifuLabel11.Name = "BunifuLabel11"
        Me.BunifuLabel11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel11.Size = New System.Drawing.Size(153, 21)
        Me.BunifuLabel11.TabIndex = 42
        Me.BunifuLabel11.Text = "Violation Details"
        Me.BunifuLabel11.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel11.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtViolation
        '
        Me.txtViolation.AcceptsReturn = False
        Me.txtViolation.AcceptsTab = False
        Me.txtViolation.AnimationSpeed = 200
        Me.txtViolation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtViolation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtViolation.BackColor = System.Drawing.Color.White
        Me.txtViolation.BackgroundImage = CType(resources.GetObject("txtViolation.BackgroundImage"), System.Drawing.Image)
        Me.txtViolation.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtViolation.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtViolation.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtViolation.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtViolation.BorderRadius = 1
        Me.txtViolation.BorderThickness = 1
        Me.txtViolation.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtViolation.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtViolation.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtViolation.DefaultText = ""
        Me.txtViolation.FillColor = System.Drawing.Color.White
        Me.txtViolation.HideSelection = True
        Me.txtViolation.IconLeft = Nothing
        Me.txtViolation.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtViolation.IconPadding = 10
        Me.txtViolation.IconRight = Nothing
        Me.txtViolation.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtViolation.Lines = New String(-1) {}
        Me.txtViolation.Location = New System.Drawing.Point(102, 115)
        Me.txtViolation.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtViolation.MaxLength = 32767
        Me.txtViolation.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtViolation.Modified = False
        Me.txtViolation.Multiline = True
        Me.txtViolation.Name = "txtViolation"
        StateProperties9.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties9.FillColor = System.Drawing.Color.Empty
        StateProperties9.ForeColor = System.Drawing.Color.Empty
        StateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtViolation.OnActiveState = StateProperties9
        StateProperties10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties10.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtViolation.OnDisabledState = StateProperties10
        StateProperties11.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties11.FillColor = System.Drawing.Color.Empty
        StateProperties11.ForeColor = System.Drawing.Color.Empty
        StateProperties11.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtViolation.OnHoverState = StateProperties11
        StateProperties12.BorderColor = System.Drawing.Color.Silver
        StateProperties12.FillColor = System.Drawing.Color.White
        StateProperties12.ForeColor = System.Drawing.Color.Empty
        StateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtViolation.OnIdleState = StateProperties12
        Me.txtViolation.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtViolation.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtViolation.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtViolation.PlaceholderText = "Type the Violation"
        Me.txtViolation.ReadOnly = False
        Me.txtViolation.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtViolation.SelectedText = ""
        Me.txtViolation.SelectionLength = 0
        Me.txtViolation.SelectionStart = 0
        Me.txtViolation.ShortcutsEnabled = True
        Me.txtViolation.Size = New System.Drawing.Size(247, 79)
        Me.txtViolation.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtViolation.TabIndex = 46
        Me.txtViolation.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtViolation.TextMarginBottom = 0
        Me.txtViolation.TextMarginLeft = 3
        Me.txtViolation.TextMarginTop = 0
        Me.txtViolation.TextPlaceholder = "Type the Violation"
        Me.txtViolation.UseSystemPasswordChar = False
        Me.txtViolation.WordWrap = True
        '
        'txtAY
        '
        Me.txtAY.AcceptsReturn = False
        Me.txtAY.AcceptsTab = False
        Me.txtAY.AnimationSpeed = 200
        Me.txtAY.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtAY.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtAY.BackColor = System.Drawing.Color.White
        Me.txtAY.BackgroundImage = CType(resources.GetObject("txtAY.BackgroundImage"), System.Drawing.Image)
        Me.txtAY.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtAY.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtAY.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAY.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtAY.BorderRadius = 1
        Me.txtAY.BorderThickness = 1
        Me.txtAY.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtAY.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAY.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtAY.DefaultText = ""
        Me.txtAY.FillColor = System.Drawing.Color.White
        Me.txtAY.HideSelection = True
        Me.txtAY.IconLeft = Nothing
        Me.txtAY.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAY.IconPadding = 10
        Me.txtAY.IconRight = Nothing
        Me.txtAY.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAY.Lines = New String(-1) {}
        Me.txtAY.Location = New System.Drawing.Point(102, 56)
        Me.txtAY.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtAY.MaxLength = 32767
        Me.txtAY.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtAY.Modified = False
        Me.txtAY.Multiline = False
        Me.txtAY.Name = "txtAY"
        StateProperties13.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties13.FillColor = System.Drawing.Color.Empty
        StateProperties13.ForeColor = System.Drawing.Color.Empty
        StateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtAY.OnActiveState = StateProperties13
        StateProperties14.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties14.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtAY.OnDisabledState = StateProperties14
        StateProperties15.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties15.FillColor = System.Drawing.Color.Empty
        StateProperties15.ForeColor = System.Drawing.Color.Empty
        StateProperties15.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAY.OnHoverState = StateProperties15
        StateProperties16.BorderColor = System.Drawing.Color.Silver
        StateProperties16.FillColor = System.Drawing.Color.White
        StateProperties16.ForeColor = System.Drawing.Color.Empty
        StateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtAY.OnIdleState = StateProperties16
        Me.txtAY.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtAY.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtAY.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtAY.PlaceholderText = "Academic Year Code"
        Me.txtAY.ReadOnly = False
        Me.txtAY.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtAY.SelectedText = ""
        Me.txtAY.SelectionLength = 0
        Me.txtAY.SelectionStart = 0
        Me.txtAY.ShortcutsEnabled = True
        Me.txtAY.Size = New System.Drawing.Size(247, 45)
        Me.txtAY.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtAY.TabIndex = 43
        Me.txtAY.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAY.TextMarginBottom = 0
        Me.txtAY.TextMarginLeft = 3
        Me.txtAY.TextMarginTop = 0
        Me.txtAY.TextPlaceholder = "Academic Year Code"
        Me.txtAY.UseSystemPasswordChar = False
        Me.txtAY.WordWrap = True
        '
        'BunifuLabel12
        '
        Me.BunifuLabel12.AllowParentOverrides = False
        Me.BunifuLabel12.AutoEllipsis = False
        Me.BunifuLabel12.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel12.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel12.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel12.Location = New System.Drawing.Point(21, 69)
        Me.BunifuLabel12.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel12.Name = "BunifuLabel12"
        Me.BunifuLabel12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel12.Size = New System.Drawing.Size(65, 21)
        Me.BunifuLabel12.TabIndex = 44
        Me.BunifuLabel12.Text = "A.Y. Code"
        Me.BunifuLabel12.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel12.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'pnlPersonalInfo
        '
        Me.pnlPersonalInfo.BackgroundColor = System.Drawing.Color.Transparent
        Me.pnlPersonalInfo.BackgroundImage = CType(resources.GetObject("pnlPersonalInfo.BackgroundImage"), System.Drawing.Image)
        Me.pnlPersonalInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlPersonalInfo.BorderColor = System.Drawing.Color.DarkGray
        Me.pnlPersonalInfo.BorderRadius = 25
        Me.pnlPersonalInfo.BorderThickness = 1
        Me.pnlPersonalInfo.Controls.Add(Me.BunifuLabel7)
        Me.pnlPersonalInfo.Controls.Add(Me.txtSection)
        Me.pnlPersonalInfo.Controls.Add(Me.txtProgram)
        Me.pnlPersonalInfo.Controls.Add(Me.BunifuLabel4)
        Me.pnlPersonalInfo.Controls.Add(Me.BunifuLabel5)
        Me.pnlPersonalInfo.Controls.Add(Me.lblPersonalInfo)
        Me.pnlPersonalInfo.Controls.Add(Me.txtName)
        Me.pnlPersonalInfo.Controls.Add(Me.txtSno)
        Me.pnlPersonalInfo.Controls.Add(Me.BunifuLabel6)
        Me.pnlPersonalInfo.Location = New System.Drawing.Point(19, 127)
        Me.pnlPersonalInfo.Name = "pnlPersonalInfo"
        Me.pnlPersonalInfo.ShowBorders = True
        Me.pnlPersonalInfo.Size = New System.Drawing.Size(771, 205)
        Me.pnlPersonalInfo.TabIndex = 49
        '
        'BunifuLabel7
        '
        Me.BunifuLabel7.AllowParentOverrides = False
        Me.BunifuLabel7.AutoEllipsis = False
        Me.BunifuLabel7.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel7.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel7.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel7.Location = New System.Drawing.Point(436, 123)
        Me.BunifuLabel7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel7.Name = "BunifuLabel7"
        Me.BunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel7.Size = New System.Drawing.Size(51, 21)
        Me.BunifuLabel7.TabIndex = 51
        Me.BunifuLabel7.Text = "Section"
        Me.BunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel7.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtSection
        '
        Me.txtSection.AcceptsReturn = False
        Me.txtSection.AcceptsTab = False
        Me.txtSection.AnimationSpeed = 200
        Me.txtSection.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtSection.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtSection.BackColor = System.Drawing.Color.White
        Me.txtSection.BackgroundImage = CType(resources.GetObject("txtSection.BackgroundImage"), System.Drawing.Image)
        Me.txtSection.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtSection.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtSection.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSection.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtSection.BorderRadius = 1
        Me.txtSection.BorderThickness = 1
        Me.txtSection.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtSection.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSection.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtSection.DefaultText = ""
        Me.txtSection.FillColor = System.Drawing.Color.White
        Me.txtSection.HideSelection = True
        Me.txtSection.IconLeft = Nothing
        Me.txtSection.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSection.IconPadding = 10
        Me.txtSection.IconRight = Nothing
        Me.txtSection.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSection.Lines = New String(-1) {}
        Me.txtSection.Location = New System.Drawing.Point(503, 115)
        Me.txtSection.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSection.MaxLength = 32767
        Me.txtSection.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtSection.Modified = False
        Me.txtSection.Multiline = False
        Me.txtSection.Name = "txtSection"
        StateProperties17.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties17.FillColor = System.Drawing.Color.Empty
        StateProperties17.ForeColor = System.Drawing.Color.Empty
        StateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtSection.OnActiveState = StateProperties17
        StateProperties18.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties18.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties18.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtSection.OnDisabledState = StateProperties18
        StateProperties19.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties19.FillColor = System.Drawing.Color.Empty
        StateProperties19.ForeColor = System.Drawing.Color.Empty
        StateProperties19.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSection.OnHoverState = StateProperties19
        StateProperties20.BorderColor = System.Drawing.Color.Silver
        StateProperties20.FillColor = System.Drawing.Color.White
        StateProperties20.ForeColor = System.Drawing.Color.Empty
        StateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtSection.OnIdleState = StateProperties20
        Me.txtSection.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSection.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtSection.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtSection.PlaceholderText = "Section"
        Me.txtSection.ReadOnly = False
        Me.txtSection.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtSection.SelectedText = ""
        Me.txtSection.SelectionLength = 0
        Me.txtSection.SelectionStart = 0
        Me.txtSection.ShortcutsEnabled = True
        Me.txtSection.Size = New System.Drawing.Size(247, 45)
        Me.txtSection.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtSection.TabIndex = 50
        Me.txtSection.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtSection.TextMarginBottom = 0
        Me.txtSection.TextMarginLeft = 3
        Me.txtSection.TextMarginTop = 0
        Me.txtSection.TextPlaceholder = "Section"
        Me.txtSection.UseSystemPasswordChar = False
        Me.txtSection.WordWrap = True
        '
        'txtProgram
        '
        Me.txtProgram.AcceptsReturn = False
        Me.txtProgram.AcceptsTab = False
        Me.txtProgram.AnimationSpeed = 200
        Me.txtProgram.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtProgram.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtProgram.BackColor = System.Drawing.Color.White
        Me.txtProgram.BackgroundImage = CType(resources.GetObject("txtProgram.BackgroundImage"), System.Drawing.Image)
        Me.txtProgram.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtProgram.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtProgram.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtProgram.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtProgram.BorderRadius = 1
        Me.txtProgram.BorderThickness = 1
        Me.txtProgram.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtProgram.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProgram.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtProgram.DefaultText = ""
        Me.txtProgram.FillColor = System.Drawing.Color.White
        Me.txtProgram.HideSelection = True
        Me.txtProgram.IconLeft = Nothing
        Me.txtProgram.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProgram.IconPadding = 10
        Me.txtProgram.IconRight = Nothing
        Me.txtProgram.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtProgram.Lines = New String(-1) {}
        Me.txtProgram.Location = New System.Drawing.Point(502, 60)
        Me.txtProgram.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtProgram.MaxLength = 32767
        Me.txtProgram.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtProgram.Modified = False
        Me.txtProgram.Multiline = False
        Me.txtProgram.Name = "txtProgram"
        StateProperties21.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties21.FillColor = System.Drawing.Color.Empty
        StateProperties21.ForeColor = System.Drawing.Color.Empty
        StateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtProgram.OnActiveState = StateProperties21
        StateProperties22.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties22.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties22.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties22.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtProgram.OnDisabledState = StateProperties22
        StateProperties23.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties23.FillColor = System.Drawing.Color.Empty
        StateProperties23.ForeColor = System.Drawing.Color.Empty
        StateProperties23.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtProgram.OnHoverState = StateProperties23
        StateProperties24.BorderColor = System.Drawing.Color.Silver
        StateProperties24.FillColor = System.Drawing.Color.White
        StateProperties24.ForeColor = System.Drawing.Color.Empty
        StateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtProgram.OnIdleState = StateProperties24
        Me.txtProgram.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtProgram.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtProgram.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtProgram.PlaceholderText = "Program"
        Me.txtProgram.ReadOnly = False
        Me.txtProgram.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtProgram.SelectedText = ""
        Me.txtProgram.SelectionLength = 0
        Me.txtProgram.SelectionStart = 0
        Me.txtProgram.ShortcutsEnabled = True
        Me.txtProgram.Size = New System.Drawing.Size(247, 45)
        Me.txtProgram.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtProgram.TabIndex = 48
        Me.txtProgram.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtProgram.TextMarginBottom = 0
        Me.txtProgram.TextMarginLeft = 3
        Me.txtProgram.TextMarginTop = 0
        Me.txtProgram.TextPlaceholder = "Program"
        Me.txtProgram.UseSystemPasswordChar = False
        Me.txtProgram.WordWrap = True
        '
        'BunifuLabel4
        '
        Me.BunifuLabel4.AllowParentOverrides = False
        Me.BunifuLabel4.AutoEllipsis = False
        Me.BunifuLabel4.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel4.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel4.Location = New System.Drawing.Point(426, 72)
        Me.BunifuLabel4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel4.Name = "BunifuLabel4"
        Me.BunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel4.Size = New System.Drawing.Size(61, 21)
        Me.BunifuLabel4.TabIndex = 49
        Me.BunifuLabel4.Text = "Program"
        Me.BunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel5
        '
        Me.BunifuLabel5.AllowParentOverrides = False
        Me.BunifuLabel5.AutoEllipsis = False
        Me.BunifuLabel5.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel5.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel5.Location = New System.Drawing.Point(76, 123)
        Me.BunifuLabel5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel5.Name = "BunifuLabel5"
        Me.BunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel5.Size = New System.Drawing.Size(42, 21)
        Me.BunifuLabel5.TabIndex = 47
        Me.BunifuLabel5.Text = "Name"
        Me.BunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'lblPersonalInfo
        '
        Me.lblPersonalInfo.AllowParentOverrides = False
        Me.lblPersonalInfo.AutoEllipsis = False
        Me.lblPersonalInfo.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPersonalInfo.CursorType = System.Windows.Forms.Cursors.Default
        Me.lblPersonalInfo.Font = New System.Drawing.Font("Cascadia Mono", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPersonalInfo.Location = New System.Drawing.Point(20, 17)
        Me.lblPersonalInfo.Name = "lblPersonalInfo"
        Me.lblPersonalInfo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPersonalInfo.Size = New System.Drawing.Size(108, 21)
        Me.lblPersonalInfo.TabIndex = 42
        Me.lblPersonalInfo.Text = "Student Info"
        Me.lblPersonalInfo.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblPersonalInfo.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtName
        '
        Me.txtName.AcceptsReturn = False
        Me.txtName.AcceptsTab = False
        Me.txtName.AnimationSpeed = 200
        Me.txtName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtName.BackColor = System.Drawing.Color.White
        Me.txtName.BackgroundImage = CType(resources.GetObject("txtName.BackgroundImage"), System.Drawing.Image)
        Me.txtName.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtName.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtName.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtName.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtName.BorderRadius = 1
        Me.txtName.BorderThickness = 1
        Me.txtName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtName.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtName.DefaultText = ""
        Me.txtName.FillColor = System.Drawing.Color.White
        Me.txtName.HideSelection = True
        Me.txtName.IconLeft = Nothing
        Me.txtName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtName.IconPadding = 10
        Me.txtName.IconRight = Nothing
        Me.txtName.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtName.Lines = New String(-1) {}
        Me.txtName.Location = New System.Drawing.Point(134, 115)
        Me.txtName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtName.MaxLength = 32767
        Me.txtName.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtName.Modified = False
        Me.txtName.Multiline = False
        Me.txtName.Name = "txtName"
        StateProperties25.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties25.FillColor = System.Drawing.Color.Empty
        StateProperties25.ForeColor = System.Drawing.Color.Empty
        StateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtName.OnActiveState = StateProperties25
        StateProperties26.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties26.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties26.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties26.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtName.OnDisabledState = StateProperties26
        StateProperties27.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties27.FillColor = System.Drawing.Color.Empty
        StateProperties27.ForeColor = System.Drawing.Color.Empty
        StateProperties27.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtName.OnHoverState = StateProperties27
        StateProperties28.BorderColor = System.Drawing.Color.Silver
        StateProperties28.FillColor = System.Drawing.Color.White
        StateProperties28.ForeColor = System.Drawing.Color.Empty
        StateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtName.OnIdleState = StateProperties28
        Me.txtName.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtName.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtName.PlaceholderText = "Name"
        Me.txtName.ReadOnly = False
        Me.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtName.SelectedText = ""
        Me.txtName.SelectionLength = 0
        Me.txtName.SelectionStart = 0
        Me.txtName.ShortcutsEnabled = True
        Me.txtName.Size = New System.Drawing.Size(247, 45)
        Me.txtName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtName.TabIndex = 46
        Me.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtName.TextMarginBottom = 0
        Me.txtName.TextMarginLeft = 3
        Me.txtName.TextMarginTop = 0
        Me.txtName.TextPlaceholder = "Name"
        Me.txtName.UseSystemPasswordChar = False
        Me.txtName.WordWrap = True
        '
        'txtSno
        '
        Me.txtSno.AcceptsReturn = False
        Me.txtSno.AcceptsTab = False
        Me.txtSno.AnimationSpeed = 200
        Me.txtSno.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtSno.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtSno.BackColor = System.Drawing.Color.White
        Me.txtSno.BackgroundImage = CType(resources.GetObject("txtSno.BackgroundImage"), System.Drawing.Image)
        Me.txtSno.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtSno.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtSno.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSno.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtSno.BorderRadius = 1
        Me.txtSno.BorderThickness = 1
        Me.txtSno.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtSno.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSno.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtSno.DefaultText = ""
        Me.txtSno.FillColor = System.Drawing.Color.White
        Me.txtSno.HideSelection = True
        Me.txtSno.IconLeft = Nothing
        Me.txtSno.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSno.IconPadding = 10
        Me.txtSno.IconRight = Nothing
        Me.txtSno.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSno.Lines = New String(-1) {}
        Me.txtSno.Location = New System.Drawing.Point(134, 60)
        Me.txtSno.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSno.MaxLength = 32767
        Me.txtSno.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtSno.Modified = False
        Me.txtSno.Multiline = False
        Me.txtSno.Name = "txtSno"
        StateProperties29.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties29.FillColor = System.Drawing.Color.Empty
        StateProperties29.ForeColor = System.Drawing.Color.Empty
        StateProperties29.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtSno.OnActiveState = StateProperties29
        StateProperties30.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties30.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties30.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties30.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtSno.OnDisabledState = StateProperties30
        StateProperties31.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties31.FillColor = System.Drawing.Color.Empty
        StateProperties31.ForeColor = System.Drawing.Color.Empty
        StateProperties31.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtSno.OnHoverState = StateProperties31
        StateProperties32.BorderColor = System.Drawing.Color.Silver
        StateProperties32.FillColor = System.Drawing.Color.White
        StateProperties32.ForeColor = System.Drawing.Color.Empty
        StateProperties32.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtSno.OnIdleState = StateProperties32
        Me.txtSno.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtSno.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtSno.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtSno.PlaceholderText = "Student Number"
        Me.txtSno.ReadOnly = False
        Me.txtSno.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtSno.SelectedText = ""
        Me.txtSno.SelectionLength = 0
        Me.txtSno.SelectionStart = 0
        Me.txtSno.ShortcutsEnabled = True
        Me.txtSno.Size = New System.Drawing.Size(247, 45)
        Me.txtSno.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtSno.TabIndex = 43
        Me.txtSno.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtSno.TextMarginBottom = 0
        Me.txtSno.TextMarginLeft = 3
        Me.txtSno.TextMarginTop = 0
        Me.txtSno.TextPlaceholder = "Student Number"
        Me.txtSno.UseSystemPasswordChar = False
        Me.txtSno.WordWrap = True
        '
        'BunifuLabel6
        '
        Me.BunifuLabel6.AllowParentOverrides = False
        Me.BunifuLabel6.AutoEllipsis = False
        Me.BunifuLabel6.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel6.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel6.Location = New System.Drawing.Point(36, 72)
        Me.BunifuLabel6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel6.Name = "BunifuLabel6"
        Me.BunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel6.Size = New System.Drawing.Size(82, 21)
        Me.BunifuLabel6.TabIndex = 44
        Me.BunifuLabel6.Text = "Student No."
        Me.BunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel3
        '
        Me.BunifuLabel3.AllowParentOverrides = False
        Me.BunifuLabel3.AutoEllipsis = False
        Me.BunifuLabel3.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel3.Font = New System.Drawing.Font("Cascadia Code", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel3.Location = New System.Drawing.Point(19, 14)
        Me.BunifuLabel3.Name = "BunifuLabel3"
        Me.BunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel3.Size = New System.Drawing.Size(154, 25)
        Me.BunifuLabel3.TabIndex = 7
        Me.BunifuLabel3.Text = "Violation List"
        Me.BunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'dgvViolation
        '
        Me.dgvViolation.AllowCustomTheming = False
        Me.dgvViolation.AllowUserToAddRows = False
        Me.dgvViolation.AllowUserToDeleteRows = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black
        Me.dgvViolation.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvViolation.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvViolation.BackgroundColor = System.Drawing.Color.White
        Me.dgvViolation.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvViolation.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvViolation.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.DodgerBlue
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvViolation.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgvViolation.ColumnHeadersHeight = 40
        Me.dgvViolation.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column9, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.Column1, Me.Column2, Me.Column3, Me.Column7, Me.Column4, Me.Column5})
        Me.dgvViolation.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvViolation.CurrentTheme.AlternatingRowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvViolation.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvViolation.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvViolation.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvViolation.CurrentTheme.BackColor = System.Drawing.Color.White
        Me.dgvViolation.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvViolation.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue
        Me.dgvViolation.CurrentTheme.HeaderStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        Me.dgvViolation.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgvViolation.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.dgvViolation.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White
        Me.dgvViolation.CurrentTheme.Name = Nothing
        Me.dgvViolation.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvViolation.CurrentTheme.RowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvViolation.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvViolation.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvViolation.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvViolation.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgvViolation.EnableHeadersVisualStyles = False
        Me.dgvViolation.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvViolation.HeaderBackColor = System.Drawing.Color.DodgerBlue
        Me.dgvViolation.HeaderBgColor = System.Drawing.Color.Empty
        Me.dgvViolation.HeaderForeColor = System.Drawing.Color.White
        Me.dgvViolation.Location = New System.Drawing.Point(19, 338)
        Me.dgvViolation.Name = "dgvViolation"
        Me.dgvViolation.ReadOnly = True
        Me.dgvViolation.RowHeadersVisible = False
        Me.dgvViolation.RowTemplate.Height = 40
        Me.dgvViolation.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvViolation.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvViolation.Size = New System.Drawing.Size(1325, 451)
        Me.dgvViolation.TabIndex = 1
        Me.dgvViolation.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light
        '
        'tabRecords
        '
        Me.tabRecords.Controls.Add(Me.dgvDisplay)
        Me.tabRecords.Controls.Add(Me.dgvRecords1)
        Me.tabRecords.Controls.Add(Me.cboAYCode)
        Me.tabRecords.Controls.Add(Me.BunifuLabel14)
        Me.tabRecords.Controls.Add(Me.BunifuLabel13)
        Me.tabRecords.Location = New System.Drawing.Point(4, 4)
        Me.tabRecords.Name = "tabRecords"
        Me.tabRecords.Size = New System.Drawing.Size(1352, 792)
        Me.tabRecords.TabIndex = 3
        Me.tabRecords.Text = "Records"
        Me.tabRecords.UseVisualStyleBackColor = True
        '
        'dgvDisplay
        '
        Me.dgvDisplay.AllowCustomTheming = False
        Me.dgvDisplay.AllowUserToAddRows = False
        Me.dgvDisplay.AllowUserToDeleteRows = False
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black
        Me.dgvDisplay.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle7
        Me.dgvDisplay.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvDisplay.BackgroundColor = System.Drawing.Color.White
        Me.dgvDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvDisplay.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvDisplay.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.DodgerBlue
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvDisplay.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.dgvDisplay.ColumnHeadersHeight = 40
        Me.dgvDisplay.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn26, Me.DataGridViewTextBoxColumn30, Me.DataGridViewTextBoxColumn31, Me.DataGridViewTextBoxColumn32, Me.DataGridViewTextBoxColumn33, Me.DataGridViewTextBoxColumn34})
        Me.dgvDisplay.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvDisplay.CurrentTheme.AlternatingRowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvDisplay.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvDisplay.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvDisplay.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvDisplay.CurrentTheme.BackColor = System.Drawing.Color.White
        Me.dgvDisplay.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvDisplay.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue
        Me.dgvDisplay.CurrentTheme.HeaderStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        Me.dgvDisplay.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgvDisplay.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.dgvDisplay.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White
        Me.dgvDisplay.CurrentTheme.Name = Nothing
        Me.dgvDisplay.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvDisplay.CurrentTheme.RowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvDisplay.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvDisplay.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvDisplay.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvDisplay.DefaultCellStyle = DataGridViewCellStyle9
        Me.dgvDisplay.EnableHeadersVisualStyles = False
        Me.dgvDisplay.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvDisplay.HeaderBackColor = System.Drawing.Color.DodgerBlue
        Me.dgvDisplay.HeaderBgColor = System.Drawing.Color.Empty
        Me.dgvDisplay.HeaderForeColor = System.Drawing.Color.White
        Me.dgvDisplay.Location = New System.Drawing.Point(24, 573)
        Me.dgvDisplay.Name = "dgvDisplay"
        Me.dgvDisplay.ReadOnly = True
        Me.dgvDisplay.RowHeadersVisible = False
        Me.dgvDisplay.RowTemplate.Height = 40
        Me.dgvDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvDisplay.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvDisplay.Size = New System.Drawing.Size(1325, 197)
        Me.dgvDisplay.TabIndex = 53
        Me.dgvDisplay.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light
        '
        'DataGridViewTextBoxColumn26
        '
        Me.DataGridViewTextBoxColumn26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn26.HeaderText = "#"
        Me.DataGridViewTextBoxColumn26.Name = "DataGridViewTextBoxColumn26"
        Me.DataGridViewTextBoxColumn26.ReadOnly = True
        Me.DataGridViewTextBoxColumn26.Width = 42
        '
        'DataGridViewTextBoxColumn30
        '
        Me.DataGridViewTextBoxColumn30.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn30.HeaderText = "DATE"
        Me.DataGridViewTextBoxColumn30.Name = "DataGridViewTextBoxColumn30"
        Me.DataGridViewTextBoxColumn30.ReadOnly = True
        Me.DataGridViewTextBoxColumn30.Width = 71
        '
        'DataGridViewTextBoxColumn31
        '
        Me.DataGridViewTextBoxColumn31.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn31.HeaderText = "VIOLATION"
        Me.DataGridViewTextBoxColumn31.Name = "DataGridViewTextBoxColumn31"
        Me.DataGridViewTextBoxColumn31.ReadOnly = True
        Me.DataGridViewTextBoxColumn31.Width = 116
        '
        'DataGridViewTextBoxColumn32
        '
        Me.DataGridViewTextBoxColumn32.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn32.HeaderText = "SANCTION"
        Me.DataGridViewTextBoxColumn32.Name = "DataGridViewTextBoxColumn32"
        Me.DataGridViewTextBoxColumn32.ReadOnly = True
        Me.DataGridViewTextBoxColumn32.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn32.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn32.Width = 94
        '
        'DataGridViewTextBoxColumn33
        '
        Me.DataGridViewTextBoxColumn33.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn33.HeaderText = "TYPE"
        Me.DataGridViewTextBoxColumn33.Name = "DataGridViewTextBoxColumn33"
        Me.DataGridViewTextBoxColumn33.ReadOnly = True
        Me.DataGridViewTextBoxColumn33.Width = 68
        '
        'DataGridViewTextBoxColumn34
        '
        Me.DataGridViewTextBoxColumn34.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn34.HeaderText = "USER"
        Me.DataGridViewTextBoxColumn34.Name = "DataGridViewTextBoxColumn34"
        Me.DataGridViewTextBoxColumn34.ReadOnly = True
        Me.DataGridViewTextBoxColumn34.Width = 71
        '
        'dgvRecords1
        '
        Me.dgvRecords1.AllowCustomTheming = False
        Me.dgvRecords1.AllowUserToAddRows = False
        Me.dgvRecords1.AllowUserToDeleteRows = False
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black
        Me.dgvRecords1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle10
        Me.dgvRecords1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvRecords1.BackgroundColor = System.Drawing.Color.White
        Me.dgvRecords1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvRecords1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvRecords1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.DodgerBlue
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle11.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvRecords1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.dgvRecords1.ColumnHeadersHeight = 40
        Me.dgvRecords1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23, Me.Column8, Me.DataGridViewTextBoxColumn28, Me.DataGridViewTextBoxColumn29, Me.colDisplay})
        Me.dgvRecords1.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvRecords1.CurrentTheme.AlternatingRowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvRecords1.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvRecords1.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvRecords1.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvRecords1.CurrentTheme.BackColor = System.Drawing.Color.White
        Me.dgvRecords1.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvRecords1.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue
        Me.dgvRecords1.CurrentTheme.HeaderStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        Me.dgvRecords1.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgvRecords1.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.dgvRecords1.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White
        Me.dgvRecords1.CurrentTheme.Name = Nothing
        Me.dgvRecords1.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvRecords1.CurrentTheme.RowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvRecords1.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvRecords1.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvRecords1.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvRecords1.DefaultCellStyle = DataGridViewCellStyle12
        Me.dgvRecords1.EnableHeadersVisualStyles = False
        Me.dgvRecords1.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvRecords1.HeaderBackColor = System.Drawing.Color.DodgerBlue
        Me.dgvRecords1.HeaderBgColor = System.Drawing.Color.Empty
        Me.dgvRecords1.HeaderForeColor = System.Drawing.Color.White
        Me.dgvRecords1.Location = New System.Drawing.Point(19, 102)
        Me.dgvRecords1.Name = "dgvRecords1"
        Me.dgvRecords1.ReadOnly = True
        Me.dgvRecords1.RowHeadersVisible = False
        Me.dgvRecords1.RowTemplate.Height = 40
        Me.dgvRecords1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvRecords1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvRecords1.Size = New System.Drawing.Size(1325, 454)
        Me.dgvRecords1.TabIndex = 52
        Me.dgvRecords1.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn21.HeaderText = "#"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.ReadOnly = True
        Me.DataGridViewTextBoxColumn21.Width = 42
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn22.HeaderText = "STUDENT NO"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        Me.DataGridViewTextBoxColumn22.Width = 130
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn23.HeaderText = "FULL NAME"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        Me.DataGridViewTextBoxColumn23.Width = 118
        '
        'Column8
        '
        Me.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column8.HeaderText = "PROGRAM"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        Me.Column8.Width = 111
        '
        'DataGridViewTextBoxColumn28
        '
        Me.DataGridViewTextBoxColumn28.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn28.HeaderText = "SECTION"
        Me.DataGridViewTextBoxColumn28.Name = "DataGridViewTextBoxColumn28"
        Me.DataGridViewTextBoxColumn28.ReadOnly = True
        Me.DataGridViewTextBoxColumn28.Width = 98
        '
        'DataGridViewTextBoxColumn29
        '
        Me.DataGridViewTextBoxColumn29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn29.HeaderText = "VIOLATION (S)"
        Me.DataGridViewTextBoxColumn29.Name = "DataGridViewTextBoxColumn29"
        Me.DataGridViewTextBoxColumn29.ReadOnly = True
        Me.DataGridViewTextBoxColumn29.Width = 139
        '
        'colDisplay
        '
        Me.colDisplay.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDisplay.HeaderText = ""
        Me.colDisplay.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.frame
        Me.colDisplay.Name = "colDisplay"
        Me.colDisplay.ReadOnly = True
        Me.colDisplay.Width = 5
        '
        'cboAYCode
        '
        Me.cboAYCode.BackColor = System.Drawing.Color.Transparent
        Me.cboAYCode.BackgroundColor = System.Drawing.Color.White
        Me.cboAYCode.BorderColor = System.Drawing.Color.Silver
        Me.cboAYCode.BorderRadius = 17
        Me.cboAYCode.Color = System.Drawing.Color.Silver
        Me.cboAYCode.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down
        Me.cboAYCode.DisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboAYCode.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cboAYCode.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboAYCode.DisabledForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.cboAYCode.DisabledIndicatorColor = System.Drawing.Color.DarkGray
        Me.cboAYCode.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cboAYCode.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin
        Me.cboAYCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAYCode.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboAYCode.FillDropDown = True
        Me.cboAYCode.FillIndicator = False
        Me.cboAYCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboAYCode.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cboAYCode.ForeColor = System.Drawing.Color.Black
        Me.cboAYCode.FormattingEnabled = True
        Me.cboAYCode.Icon = Nothing
        Me.cboAYCode.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboAYCode.IndicatorColor = System.Drawing.Color.Gray
        Me.cboAYCode.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboAYCode.ItemBackColor = System.Drawing.Color.White
        Me.cboAYCode.ItemBorderColor = System.Drawing.Color.Transparent
        Me.cboAYCode.ItemForeColor = System.Drawing.Color.Black
        Me.cboAYCode.ItemHeight = 26
        Me.cboAYCode.ItemHighLightColor = System.Drawing.Color.DodgerBlue
        Me.cboAYCode.ItemHighLightForeColor = System.Drawing.Color.White
        Me.cboAYCode.Items.AddRange(New Object() {"MINOR OFFENSE", "MAJOR OFFENSE"})
        Me.cboAYCode.ItemTopMargin = 3
        Me.cboAYCode.Location = New System.Drawing.Point(172, 64)
        Me.cboAYCode.Name = "cboAYCode"
        Me.cboAYCode.Size = New System.Drawing.Size(251, 32)
        Me.cboAYCode.TabIndex = 51
        Me.cboAYCode.Text = Nothing
        Me.cboAYCode.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboAYCode.TextLeftMargin = 5
        '
        'BunifuLabel14
        '
        Me.BunifuLabel14.AllowParentOverrides = False
        Me.BunifuLabel14.AutoEllipsis = False
        Me.BunifuLabel14.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel14.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel14.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel14.Location = New System.Drawing.Point(19, 70)
        Me.BunifuLabel14.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel14.Name = "BunifuLabel14"
        Me.BunifuLabel14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel14.Size = New System.Drawing.Size(125, 21)
        Me.BunifuLabel14.TabIndex = 45
        Me.BunifuLabel14.Text = "Filter by A.Y. Code"
        Me.BunifuLabel14.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel14.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel13
        '
        Me.BunifuLabel13.AllowParentOverrides = False
        Me.BunifuLabel13.AutoEllipsis = False
        Me.BunifuLabel13.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel13.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel13.Font = New System.Drawing.Font("Cascadia Code", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel13.Location = New System.Drawing.Point(19, 14)
        Me.BunifuLabel13.Name = "BunifuLabel13"
        Me.BunifuLabel13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel13.Size = New System.Drawing.Size(77, 25)
        Me.BunifuLabel13.TabIndex = 4
        Me.BunifuLabel13.Text = "Records"
        Me.BunifuLabel13.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel13.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'tabProgram
        '
        Me.tabProgram.BackColor = System.Drawing.Color.White
        Me.tabProgram.Controls.Add(Me.lblTitle)
        Me.tabProgram.Controls.Add(Me.dgvProgram)
        Me.tabProgram.Controls.Add(Me.linkLblAddNew)
        Me.tabProgram.Location = New System.Drawing.Point(4, 4)
        Me.tabProgram.Name = "tabProgram"
        Me.tabProgram.Size = New System.Drawing.Size(1352, 792)
        Me.tabProgram.TabIndex = 4
        Me.tabProgram.Text = "Program"
        '
        'lblTitle
        '
        Me.lblTitle.AllowParentOverrides = False
        Me.lblTitle.AutoEllipsis = False
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.CursorType = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Cascadia Code", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(19, 14)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(132, 25)
        Me.lblTitle.TabIndex = 3
        Me.lblTitle.Text = "Program List"
        Me.lblTitle.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblTitle.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'dgvProgram
        '
        Me.dgvProgram.AllowCustomTheming = False
        Me.dgvProgram.AllowUserToAddRows = False
        Me.dgvProgram.AllowUserToDeleteRows = False
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle13.ForeColor = System.Drawing.Color.Black
        Me.dgvProgram.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle13
        Me.dgvProgram.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvProgram.BackgroundColor = System.Drawing.Color.White
        Me.dgvProgram.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvProgram.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvProgram.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.DodgerBlue
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle14.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvProgram.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.dgvProgram.ColumnHeadersHeight = 40
        Me.dgvProgram.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumbering, Me.PCODE, Me.colDescription, Me.cboType, Me.colEdit, Me.colDelete})
        Me.dgvProgram.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvProgram.CurrentTheme.AlternatingRowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvProgram.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvProgram.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvProgram.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvProgram.CurrentTheme.BackColor = System.Drawing.Color.White
        Me.dgvProgram.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvProgram.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue
        Me.dgvProgram.CurrentTheme.HeaderStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        Me.dgvProgram.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgvProgram.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.dgvProgram.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White
        Me.dgvProgram.CurrentTheme.Name = Nothing
        Me.dgvProgram.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvProgram.CurrentTheme.RowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvProgram.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvProgram.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvProgram.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvProgram.DefaultCellStyle = DataGridViewCellStyle15
        Me.dgvProgram.EnableHeadersVisualStyles = False
        Me.dgvProgram.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvProgram.HeaderBackColor = System.Drawing.Color.DodgerBlue
        Me.dgvProgram.HeaderBgColor = System.Drawing.Color.Empty
        Me.dgvProgram.HeaderForeColor = System.Drawing.Color.White
        Me.dgvProgram.Location = New System.Drawing.Point(19, 57)
        Me.dgvProgram.Name = "dgvProgram"
        Me.dgvProgram.ReadOnly = True
        Me.dgvProgram.RowHeadersVisible = False
        Me.dgvProgram.RowTemplate.Height = 40
        Me.dgvProgram.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvProgram.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvProgram.Size = New System.Drawing.Size(1325, 729)
        Me.dgvProgram.TabIndex = 0
        Me.dgvProgram.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light
        '
        'colNumbering
        '
        Me.colNumbering.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumbering.HeaderText = "#"
        Me.colNumbering.Name = "colNumbering"
        Me.colNumbering.ReadOnly = True
        Me.colNumbering.Width = 42
        '
        'PCODE
        '
        Me.PCODE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.PCODE.HeaderText = "Program Code"
        Me.PCODE.Name = "PCODE"
        Me.PCODE.ReadOnly = True
        Me.PCODE.Width = 139
        '
        'colDescription
        '
        Me.colDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDescription.HeaderText = "Description"
        Me.colDescription.Name = "colDescription"
        Me.colDescription.ReadOnly = True
        '
        'cboType
        '
        Me.cboType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.cboType.HeaderText = "Type"
        Me.cboType.Name = "cboType"
        Me.cboType.ReadOnly = True
        Me.cboType.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.cboType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.cboType.Width = 49
        '
        'colEdit
        '
        Me.colEdit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEdit.HeaderText = ""
        Me.colEdit.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.edit__1_
        Me.colEdit.Name = "colEdit"
        Me.colEdit.ReadOnly = True
        Me.colEdit.Width = 5
        '
        'colDelete
        '
        Me.colDelete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDelete.HeaderText = ""
        Me.colDelete.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.delete
        Me.colDelete.Name = "colDelete"
        Me.colDelete.ReadOnly = True
        Me.colDelete.Width = 5
        '
        'linkLblAddNew
        '
        Me.linkLblAddNew.Font = New System.Drawing.Font("Cascadia Code", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.linkLblAddNew.Image = CType(resources.GetObject("linkLblAddNew.Image"), System.Drawing.Image)
        Me.linkLblAddNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.linkLblAddNew.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.linkLblAddNew.LinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.linkLblAddNew.Location = New System.Drawing.Point(195, 16)
        Me.linkLblAddNew.Name = "linkLblAddNew"
        Me.linkLblAddNew.Size = New System.Drawing.Size(130, 26)
        Me.linkLblAddNew.TabIndex = 2
        Me.linkLblAddNew.TabStop = True
        Me.linkLblAddNew.Text = "    [ADD NEW]"
        Me.linkLblAddNew.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        '
        'tabSection
        '
        Me.tabSection.Controls.Add(Me.BunifuLabel1)
        Me.tabSection.Controls.Add(Me.dgvSection)
        Me.tabSection.Controls.Add(Me.lblAddsection)
        Me.tabSection.Location = New System.Drawing.Point(4, 4)
        Me.tabSection.Name = "tabSection"
        Me.tabSection.Size = New System.Drawing.Size(1352, 792)
        Me.tabSection.TabIndex = 5
        Me.tabSection.Text = "Section"
        Me.tabSection.UseVisualStyleBackColor = True
        '
        'BunifuLabel1
        '
        Me.BunifuLabel1.AllowParentOverrides = False
        Me.BunifuLabel1.AutoEllipsis = False
        Me.BunifuLabel1.CursorType = Nothing
        Me.BunifuLabel1.Font = New System.Drawing.Font("Cascadia Code", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel1.Location = New System.Drawing.Point(19, 14)
        Me.BunifuLabel1.Name = "BunifuLabel1"
        Me.BunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel1.Size = New System.Drawing.Size(132, 25)
        Me.BunifuLabel1.TabIndex = 5
        Me.BunifuLabel1.Text = "Section List"
        Me.BunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'dgvSection
        '
        Me.dgvSection.AllowCustomTheming = False
        Me.dgvSection.AllowUserToAddRows = False
        Me.dgvSection.AllowUserToDeleteRows = False
        DataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black
        Me.dgvSection.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle16
        Me.dgvSection.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvSection.BackgroundColor = System.Drawing.Color.White
        Me.dgvSection.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvSection.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvSection.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.Color.DodgerBlue
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle17.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSection.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle17
        Me.dgvSection.ColumnHeadersHeight = 40
        Me.dgvSection.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn9, Me.colSectionID, Me.colSection, Me.colPcode, Me.colEditSection, Me.colDeleteSection})
        Me.dgvSection.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvSection.CurrentTheme.AlternatingRowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvSection.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvSection.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvSection.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvSection.CurrentTheme.BackColor = System.Drawing.Color.White
        Me.dgvSection.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvSection.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue
        Me.dgvSection.CurrentTheme.HeaderStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        Me.dgvSection.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgvSection.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.dgvSection.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White
        Me.dgvSection.CurrentTheme.Name = Nothing
        Me.dgvSection.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvSection.CurrentTheme.RowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvSection.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvSection.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvSection.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSection.DefaultCellStyle = DataGridViewCellStyle18
        Me.dgvSection.EnableHeadersVisualStyles = False
        Me.dgvSection.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvSection.HeaderBackColor = System.Drawing.Color.DodgerBlue
        Me.dgvSection.HeaderBgColor = System.Drawing.Color.Empty
        Me.dgvSection.HeaderForeColor = System.Drawing.Color.White
        Me.dgvSection.Location = New System.Drawing.Point(19, 57)
        Me.dgvSection.Name = "dgvSection"
        Me.dgvSection.ReadOnly = True
        Me.dgvSection.RowHeadersVisible = False
        Me.dgvSection.RowTemplate.Height = 40
        Me.dgvSection.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvSection.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSection.Size = New System.Drawing.Size(1325, 729)
        Me.dgvSection.TabIndex = 3
        Me.dgvSection.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn9.HeaderText = "#"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Width = 42
        '
        'colSectionID
        '
        Me.colSectionID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSectionID.HeaderText = "Section ID"
        Me.colSectionID.Name = "colSectionID"
        Me.colSectionID.ReadOnly = True
        Me.colSectionID.Width = 108
        '
        'colSection
        '
        Me.colSection.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colSection.HeaderText = "Section"
        Me.colSection.Name = "colSection"
        Me.colSection.ReadOnly = True
        '
        'colPcode
        '
        Me.colPcode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPcode.HeaderText = "Program Code"
        Me.colPcode.Name = "colPcode"
        Me.colPcode.ReadOnly = True
        Me.colPcode.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colPcode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPcode.Width = 120
        '
        'colEditSection
        '
        Me.colEditSection.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEditSection.HeaderText = ""
        Me.colEditSection.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.edit__1_
        Me.colEditSection.Name = "colEditSection"
        Me.colEditSection.ReadOnly = True
        Me.colEditSection.Width = 5
        '
        'colDeleteSection
        '
        Me.colDeleteSection.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDeleteSection.HeaderText = ""
        Me.colDeleteSection.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.delete
        Me.colDeleteSection.Name = "colDeleteSection"
        Me.colDeleteSection.ReadOnly = True
        Me.colDeleteSection.Width = 5
        '
        'lblAddsection
        '
        Me.lblAddsection.Font = New System.Drawing.Font("Cascadia Code", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddsection.Image = CType(resources.GetObject("lblAddsection.Image"), System.Drawing.Image)
        Me.lblAddsection.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblAddsection.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.lblAddsection.LinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblAddsection.Location = New System.Drawing.Point(195, 16)
        Me.lblAddsection.Name = "lblAddsection"
        Me.lblAddsection.Size = New System.Drawing.Size(130, 26)
        Me.lblAddsection.TabIndex = 4
        Me.lblAddsection.TabStop = True
        Me.lblAddsection.Text = "    [ADD NEW]"
        Me.lblAddsection.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        '
        'tabAcademic
        '
        Me.tabAcademic.Controls.Add(Me.llblAYList)
        Me.tabAcademic.Controls.Add(Me.dgvAY)
        Me.tabAcademic.Controls.Add(Me.lblAddAY)
        Me.tabAcademic.Location = New System.Drawing.Point(4, 4)
        Me.tabAcademic.Name = "tabAcademic"
        Me.tabAcademic.Size = New System.Drawing.Size(1352, 792)
        Me.tabAcademic.TabIndex = 6
        Me.tabAcademic.Text = "Academic Year"
        Me.tabAcademic.UseVisualStyleBackColor = True
        '
        'llblAYList
        '
        Me.llblAYList.AllowParentOverrides = False
        Me.llblAYList.AutoEllipsis = False
        Me.llblAYList.Cursor = System.Windows.Forms.Cursors.Default
        Me.llblAYList.CursorType = System.Windows.Forms.Cursors.Default
        Me.llblAYList.Font = New System.Drawing.Font("Cascadia Code", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblAYList.Location = New System.Drawing.Point(20, 10)
        Me.llblAYList.Name = "llblAYList"
        Me.llblAYList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.llblAYList.Size = New System.Drawing.Size(198, 25)
        Me.llblAYList.TabIndex = 8
        Me.llblAYList.Text = "Academic Year List"
        Me.llblAYList.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.llblAYList.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'dgvAY
        '
        Me.dgvAY.AllowCustomTheming = False
        Me.dgvAY.AllowUserToAddRows = False
        Me.dgvAY.AllowUserToDeleteRows = False
        DataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black
        Me.dgvAY.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle19
        Me.dgvAY.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvAY.BackgroundColor = System.Drawing.Color.White
        Me.dgvAY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvAY.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        Me.dgvAY.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle20.BackColor = System.Drawing.Color.DodgerBlue
        DataGridViewCellStyle20.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle20.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        DataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvAY.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle20
        Me.dgvAY.ColumnHeadersHeight = 40
        Me.dgvAY.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.colOpen, Me.colClose})
        Me.dgvAY.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvAY.CurrentTheme.AlternatingRowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvAY.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvAY.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvAY.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvAY.CurrentTheme.BackColor = System.Drawing.Color.White
        Me.dgvAY.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvAY.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue
        Me.dgvAY.CurrentTheme.HeaderStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 11.75!, System.Drawing.FontStyle.Bold)
        Me.dgvAY.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White
        Me.dgvAY.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(115, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.dgvAY.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White
        Me.dgvAY.CurrentTheme.Name = Nothing
        Me.dgvAY.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White
        Me.dgvAY.CurrentTheme.RowsStyle.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.dgvAY.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black
        Me.dgvAY.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvAY.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle21.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle21.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle21.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(232, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvAY.DefaultCellStyle = DataGridViewCellStyle21
        Me.dgvAY.EnableHeadersVisualStyles = False
        Me.dgvAY.GridColor = System.Drawing.Color.FromArgb(CType(CType(221, Byte), Integer), CType(CType(238, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.dgvAY.HeaderBackColor = System.Drawing.Color.DodgerBlue
        Me.dgvAY.HeaderBgColor = System.Drawing.Color.Empty
        Me.dgvAY.HeaderForeColor = System.Drawing.Color.White
        Me.dgvAY.Location = New System.Drawing.Point(20, 53)
        Me.dgvAY.Name = "dgvAY"
        Me.dgvAY.ReadOnly = True
        Me.dgvAY.RowHeadersVisible = False
        Me.dgvAY.RowTemplate.Height = 40
        Me.dgvAY.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvAY.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvAY.Size = New System.Drawing.Size(1325, 729)
        Me.dgvAY.TabIndex = 6
        Me.dgvAY.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn5.HeaderText = "#"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 42
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn6.HeaderText = "A.Y. CODE"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn7.HeaderText = "YEAR FROM"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 120
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn8.HeaderText = "YEAR TO"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn8.Width = 76
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn19.HeaderText = "SEMESTER"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        Me.DataGridViewTextBoxColumn19.Width = 109
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn20.HeaderText = "STATUS"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        Me.DataGridViewTextBoxColumn20.Width = 89
        '
        'colOpen
        '
        Me.colOpen.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colOpen.HeaderText = ""
        Me.colOpen.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.open_folder
        Me.colOpen.Name = "colOpen"
        Me.colOpen.ReadOnly = True
        Me.colOpen.Width = 5
        '
        'colClose
        '
        Me.colClose.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClose.HeaderText = ""
        Me.colClose.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.lock
        Me.colClose.Name = "colClose"
        Me.colClose.ReadOnly = True
        Me.colClose.Width = 5
        '
        'lblAddAY
        '
        Me.lblAddAY.Font = New System.Drawing.Font("Cascadia Code", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddAY.Image = CType(resources.GetObject("lblAddAY.Image"), System.Drawing.Image)
        Me.lblAddAY.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblAddAY.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.lblAddAY.LinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblAddAY.Location = New System.Drawing.Point(244, 11)
        Me.lblAddAY.Name = "lblAddAY"
        Me.lblAddAY.Size = New System.Drawing.Size(130, 26)
        Me.lblAddAY.TabIndex = 7
        Me.lblAddAY.TabStop = True
        Me.lblAddAY.Text = "    [ADD NEW]"
        Me.lblAddAY.VisitedLinkColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        '
        'tabUserAcc
        '
        Me.tabUserAcc.Controls.Add(Me.BunifuPanel3)
        Me.tabUserAcc.Controls.Add(Me.BunifuLabel15)
        Me.tabUserAcc.Controls.Add(Me.BunifuPanel2)
        Me.tabUserAcc.Location = New System.Drawing.Point(4, 4)
        Me.tabUserAcc.Name = "tabUserAcc"
        Me.tabUserAcc.Size = New System.Drawing.Size(1352, 792)
        Me.tabUserAcc.TabIndex = 7
        Me.tabUserAcc.Text = "User Account"
        Me.tabUserAcc.UseVisualStyleBackColor = True
        '
        'BunifuPanel3
        '
        Me.BunifuPanel3.BackgroundColor = System.Drawing.Color.Transparent
        Me.BunifuPanel3.BackgroundImage = CType(resources.GetObject("BunifuPanel3.BackgroundImage"), System.Drawing.Image)
        Me.BunifuPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuPanel3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(213, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuPanel3.BorderRadius = 25
        Me.BunifuPanel3.BorderThickness = 1
        Me.BunifuPanel3.Controls.Add(Me.BunifuLabel22)
        Me.BunifuPanel3.Controls.Add(Me.BunifuLabel23)
        Me.BunifuPanel3.Controls.Add(Me.BunifuLabel24)
        Me.BunifuPanel3.Controls.Add(Me.txtCPUsername)
        Me.BunifuPanel3.Controls.Add(Me.BunifuLabel25)
        Me.BunifuPanel3.Controls.Add(Me.txtCPOldPass)
        Me.BunifuPanel3.Controls.Add(Me.BunifuLabel26)
        Me.BunifuPanel3.Controls.Add(Me.txtCPNewPass)
        Me.BunifuPanel3.Controls.Add(Me.BunifuLabel27)
        Me.BunifuPanel3.Controls.Add(Me.txtCPConfirmPass)
        Me.BunifuPanel3.Controls.Add(Me.btnUpdate)
        Me.BunifuPanel3.Location = New System.Drawing.Point(701, 94)
        Me.BunifuPanel3.Name = "BunifuPanel3"
        Me.BunifuPanel3.ShowBorders = True
        Me.BunifuPanel3.Size = New System.Drawing.Size(397, 604)
        Me.BunifuPanel3.TabIndex = 70
        '
        'BunifuLabel22
        '
        Me.BunifuLabel22.AllowParentOverrides = False
        Me.BunifuLabel22.AutoEllipsis = False
        Me.BunifuLabel22.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel22.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel22.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel22.Location = New System.Drawing.Point(35, 430)
        Me.BunifuLabel22.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel22.Name = "BunifuLabel22"
        Me.BunifuLabel22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel22.Size = New System.Drawing.Size(164, 21)
        Me.BunifuLabel22.TabIndex = 67
        Me.BunifuLabel22.Text = "Confirm New Password"
        Me.BunifuLabel22.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel22.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel23
        '
        Me.BunifuLabel23.AllowParentOverrides = False
        Me.BunifuLabel23.AutoEllipsis = False
        Me.BunifuLabel23.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel23.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel23.Font = New System.Drawing.Font("Cascadia Mono", 12.0!)
        Me.BunifuLabel23.Location = New System.Drawing.Point(35, 49)
        Me.BunifuLabel23.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel23.Name = "BunifuLabel23"
        Me.BunifuLabel23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel23.Size = New System.Drawing.Size(135, 21)
        Me.BunifuLabel23.TabIndex = 60
        Me.BunifuLabel23.Text = "Change Password"
        Me.BunifuLabel23.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel23.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel24
        '
        Me.BunifuLabel24.AllowParentOverrides = False
        Me.BunifuLabel24.AutoEllipsis = False
        Me.BunifuLabel24.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel24.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel24.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel24.Location = New System.Drawing.Point(35, 332)
        Me.BunifuLabel24.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel24.Name = "BunifuLabel24"
        Me.BunifuLabel24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel24.Size = New System.Drawing.Size(103, 21)
        Me.BunifuLabel24.TabIndex = 66
        Me.BunifuLabel24.Text = "New Password"
        Me.BunifuLabel24.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel24.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtCPUsername
        '
        Me.txtCPUsername.AcceptsReturn = False
        Me.txtCPUsername.AcceptsTab = False
        Me.txtCPUsername.AnimationSpeed = 200
        Me.txtCPUsername.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtCPUsername.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtCPUsername.BackColor = System.Drawing.Color.White
        Me.txtCPUsername.BackgroundImage = CType(resources.GetObject("txtCPUsername.BackgroundImage"), System.Drawing.Image)
        Me.txtCPUsername.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtCPUsername.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtCPUsername.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCPUsername.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtCPUsername.BorderRadius = 15
        Me.txtCPUsername.BorderThickness = 1
        Me.txtCPUsername.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtCPUsername.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPUsername.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtCPUsername.DefaultText = ""
        Me.txtCPUsername.FillColor = System.Drawing.Color.White
        Me.txtCPUsername.HideSelection = True
        Me.txtCPUsername.IconLeft = Nothing
        Me.txtCPUsername.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPUsername.IconPadding = 10
        Me.txtCPUsername.IconRight = Nothing
        Me.txtCPUsername.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPUsername.Lines = New String(-1) {}
        Me.txtCPUsername.Location = New System.Drawing.Point(35, 173)
        Me.txtCPUsername.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCPUsername.MaxLength = 32767
        Me.txtCPUsername.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtCPUsername.Modified = False
        Me.txtCPUsername.Multiline = False
        Me.txtCPUsername.Name = "txtCPUsername"
        StateProperties33.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties33.FillColor = System.Drawing.Color.Empty
        StateProperties33.ForeColor = System.Drawing.Color.Empty
        StateProperties33.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCPUsername.OnActiveState = StateProperties33
        StateProperties34.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties34.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties34.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties34.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCPUsername.OnDisabledState = StateProperties34
        StateProperties35.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties35.FillColor = System.Drawing.Color.Empty
        StateProperties35.ForeColor = System.Drawing.Color.Empty
        StateProperties35.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCPUsername.OnHoverState = StateProperties35
        StateProperties36.BorderColor = System.Drawing.Color.Silver
        StateProperties36.FillColor = System.Drawing.Color.White
        StateProperties36.ForeColor = System.Drawing.Color.Empty
        StateProperties36.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCPUsername.OnIdleState = StateProperties36
        Me.txtCPUsername.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCPUsername.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtCPUsername.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCPUsername.PlaceholderText = "Username"
        Me.txtCPUsername.ReadOnly = False
        Me.txtCPUsername.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtCPUsername.SelectedText = ""
        Me.txtCPUsername.SelectionLength = 0
        Me.txtCPUsername.SelectionStart = 0
        Me.txtCPUsername.ShortcutsEnabled = True
        Me.txtCPUsername.Size = New System.Drawing.Size(327, 45)
        Me.txtCPUsername.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtCPUsername.TabIndex = 56
        Me.txtCPUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtCPUsername.TextMarginBottom = 0
        Me.txtCPUsername.TextMarginLeft = 3
        Me.txtCPUsername.TextMarginTop = 0
        Me.txtCPUsername.TextPlaceholder = "Username"
        Me.txtCPUsername.UseSystemPasswordChar = False
        Me.txtCPUsername.WordWrap = True
        '
        'BunifuLabel25
        '
        Me.BunifuLabel25.AllowParentOverrides = False
        Me.BunifuLabel25.AutoEllipsis = False
        Me.BunifuLabel25.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel25.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel25.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel25.Location = New System.Drawing.Point(35, 234)
        Me.BunifuLabel25.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel25.Name = "BunifuLabel25"
        Me.BunifuLabel25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel25.Size = New System.Drawing.Size(96, 21)
        Me.BunifuLabel25.TabIndex = 65
        Me.BunifuLabel25.Text = "Old Password"
        Me.BunifuLabel25.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel25.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtCPOldPass
        '
        Me.txtCPOldPass.AcceptsReturn = False
        Me.txtCPOldPass.AcceptsTab = False
        Me.txtCPOldPass.AnimationSpeed = 200
        Me.txtCPOldPass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtCPOldPass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtCPOldPass.BackColor = System.Drawing.Color.White
        Me.txtCPOldPass.BackgroundImage = CType(resources.GetObject("txtCPOldPass.BackgroundImage"), System.Drawing.Image)
        Me.txtCPOldPass.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtCPOldPass.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtCPOldPass.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCPOldPass.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtCPOldPass.BorderRadius = 15
        Me.txtCPOldPass.BorderThickness = 1
        Me.txtCPOldPass.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtCPOldPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPOldPass.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtCPOldPass.DefaultText = ""
        Me.txtCPOldPass.FillColor = System.Drawing.Color.White
        Me.txtCPOldPass.HideSelection = True
        Me.txtCPOldPass.IconLeft = Nothing
        Me.txtCPOldPass.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPOldPass.IconPadding = 10
        Me.txtCPOldPass.IconRight = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.show
        Me.txtCPOldPass.IconRightCursor = System.Windows.Forms.Cursors.Hand
        Me.txtCPOldPass.Lines = New String(-1) {}
        Me.txtCPOldPass.Location = New System.Drawing.Point(35, 271)
        Me.txtCPOldPass.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCPOldPass.MaxLength = 32767
        Me.txtCPOldPass.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtCPOldPass.Modified = False
        Me.txtCPOldPass.Multiline = False
        Me.txtCPOldPass.Name = "txtCPOldPass"
        StateProperties37.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties37.FillColor = System.Drawing.Color.Empty
        StateProperties37.ForeColor = System.Drawing.Color.Empty
        StateProperties37.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCPOldPass.OnActiveState = StateProperties37
        StateProperties38.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties38.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties38.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties38.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCPOldPass.OnDisabledState = StateProperties38
        StateProperties39.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties39.FillColor = System.Drawing.Color.Empty
        StateProperties39.ForeColor = System.Drawing.Color.Empty
        StateProperties39.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCPOldPass.OnHoverState = StateProperties39
        StateProperties40.BorderColor = System.Drawing.Color.Silver
        StateProperties40.FillColor = System.Drawing.Color.White
        StateProperties40.ForeColor = System.Drawing.Color.Empty
        StateProperties40.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCPOldPass.OnIdleState = StateProperties40
        Me.txtCPOldPass.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCPOldPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtCPOldPass.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCPOldPass.PlaceholderText = "Type your previous password"
        Me.txtCPOldPass.ReadOnly = False
        Me.txtCPOldPass.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtCPOldPass.SelectedText = ""
        Me.txtCPOldPass.SelectionLength = 0
        Me.txtCPOldPass.SelectionStart = 0
        Me.txtCPOldPass.ShortcutsEnabled = True
        Me.txtCPOldPass.Size = New System.Drawing.Size(327, 45)
        Me.txtCPOldPass.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtCPOldPass.TabIndex = 57
        Me.txtCPOldPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtCPOldPass.TextMarginBottom = 0
        Me.txtCPOldPass.TextMarginLeft = 3
        Me.txtCPOldPass.TextMarginTop = 0
        Me.txtCPOldPass.TextPlaceholder = "Type your previous password"
        Me.txtCPOldPass.UseSystemPasswordChar = False
        Me.txtCPOldPass.WordWrap = True
        '
        'BunifuLabel26
        '
        Me.BunifuLabel26.AllowParentOverrides = False
        Me.BunifuLabel26.AutoEllipsis = False
        Me.BunifuLabel26.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel26.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel26.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel26.Location = New System.Drawing.Point(35, 136)
        Me.BunifuLabel26.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel26.Name = "BunifuLabel26"
        Me.BunifuLabel26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel26.Size = New System.Drawing.Size(71, 21)
        Me.BunifuLabel26.TabIndex = 64
        Me.BunifuLabel26.Text = "Username"
        Me.BunifuLabel26.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel26.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtCPNewPass
        '
        Me.txtCPNewPass.AcceptsReturn = False
        Me.txtCPNewPass.AcceptsTab = False
        Me.txtCPNewPass.AnimationSpeed = 200
        Me.txtCPNewPass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtCPNewPass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtCPNewPass.BackColor = System.Drawing.Color.White
        Me.txtCPNewPass.BackgroundImage = CType(resources.GetObject("txtCPNewPass.BackgroundImage"), System.Drawing.Image)
        Me.txtCPNewPass.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtCPNewPass.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtCPNewPass.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCPNewPass.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtCPNewPass.BorderRadius = 15
        Me.txtCPNewPass.BorderThickness = 1
        Me.txtCPNewPass.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtCPNewPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPNewPass.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtCPNewPass.DefaultText = ""
        Me.txtCPNewPass.FillColor = System.Drawing.Color.White
        Me.txtCPNewPass.HideSelection = True
        Me.txtCPNewPass.IconLeft = Nothing
        Me.txtCPNewPass.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPNewPass.IconPadding = 10
        Me.txtCPNewPass.IconRight = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.show
        Me.txtCPNewPass.IconRightCursor = System.Windows.Forms.Cursors.Hand
        Me.txtCPNewPass.Lines = New String(-1) {}
        Me.txtCPNewPass.Location = New System.Drawing.Point(35, 369)
        Me.txtCPNewPass.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCPNewPass.MaxLength = 32767
        Me.txtCPNewPass.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtCPNewPass.Modified = False
        Me.txtCPNewPass.Multiline = False
        Me.txtCPNewPass.Name = "txtCPNewPass"
        StateProperties41.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties41.FillColor = System.Drawing.Color.Empty
        StateProperties41.ForeColor = System.Drawing.Color.Empty
        StateProperties41.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCPNewPass.OnActiveState = StateProperties41
        StateProperties42.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties42.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties42.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties42.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCPNewPass.OnDisabledState = StateProperties42
        StateProperties43.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties43.FillColor = System.Drawing.Color.Empty
        StateProperties43.ForeColor = System.Drawing.Color.Empty
        StateProperties43.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCPNewPass.OnHoverState = StateProperties43
        StateProperties44.BorderColor = System.Drawing.Color.Silver
        StateProperties44.FillColor = System.Drawing.Color.White
        StateProperties44.ForeColor = System.Drawing.Color.Empty
        StateProperties44.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCPNewPass.OnIdleState = StateProperties44
        Me.txtCPNewPass.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCPNewPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtCPNewPass.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCPNewPass.PlaceholderText = "Enter a secure new password" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.txtCPNewPass.ReadOnly = False
        Me.txtCPNewPass.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtCPNewPass.SelectedText = ""
        Me.txtCPNewPass.SelectionLength = 0
        Me.txtCPNewPass.SelectionStart = 0
        Me.txtCPNewPass.ShortcutsEnabled = True
        Me.txtCPNewPass.Size = New System.Drawing.Size(327, 45)
        Me.txtCPNewPass.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtCPNewPass.TabIndex = 58
        Me.txtCPNewPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtCPNewPass.TextMarginBottom = 0
        Me.txtCPNewPass.TextMarginLeft = 3
        Me.txtCPNewPass.TextMarginTop = 0
        Me.txtCPNewPass.TextPlaceholder = "Enter a secure new password" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.txtCPNewPass.UseSystemPasswordChar = False
        Me.txtCPNewPass.WordWrap = True
        '
        'BunifuLabel27
        '
        Me.BunifuLabel27.AllowParentOverrides = False
        Me.BunifuLabel27.AutoEllipsis = False
        Me.BunifuLabel27.AutoSize = False
        Me.BunifuLabel27.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel27.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel27.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel27.Location = New System.Drawing.Point(35, 78)
        Me.BunifuLabel27.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel27.Name = "BunifuLabel27"
        Me.BunifuLabel27.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel27.Size = New System.Drawing.Size(327, 50)
        Me.BunifuLabel27.TabIndex = 63
        Me.BunifuLabel27.Text = "Strengthen account security by updating your password for added protection."
        Me.BunifuLabel27.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel27.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtCPConfirmPass
        '
        Me.txtCPConfirmPass.AcceptsReturn = False
        Me.txtCPConfirmPass.AcceptsTab = False
        Me.txtCPConfirmPass.AnimationSpeed = 200
        Me.txtCPConfirmPass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtCPConfirmPass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtCPConfirmPass.BackColor = System.Drawing.Color.White
        Me.txtCPConfirmPass.BackgroundImage = CType(resources.GetObject("txtCPConfirmPass.BackgroundImage"), System.Drawing.Image)
        Me.txtCPConfirmPass.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtCPConfirmPass.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtCPConfirmPass.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCPConfirmPass.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtCPConfirmPass.BorderRadius = 15
        Me.txtCPConfirmPass.BorderThickness = 1
        Me.txtCPConfirmPass.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtCPConfirmPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPConfirmPass.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtCPConfirmPass.DefaultText = ""
        Me.txtCPConfirmPass.FillColor = System.Drawing.Color.White
        Me.txtCPConfirmPass.HideSelection = True
        Me.txtCPConfirmPass.IconLeft = Nothing
        Me.txtCPConfirmPass.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPConfirmPass.IconPadding = 10
        Me.txtCPConfirmPass.IconRight = Nothing
        Me.txtCPConfirmPass.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCPConfirmPass.Lines = New String(-1) {}
        Me.txtCPConfirmPass.Location = New System.Drawing.Point(35, 467)
        Me.txtCPConfirmPass.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCPConfirmPass.MaxLength = 32767
        Me.txtCPConfirmPass.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtCPConfirmPass.Modified = False
        Me.txtCPConfirmPass.Multiline = False
        Me.txtCPConfirmPass.Name = "txtCPConfirmPass"
        StateProperties45.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties45.FillColor = System.Drawing.Color.Empty
        StateProperties45.ForeColor = System.Drawing.Color.Empty
        StateProperties45.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCPConfirmPass.OnActiveState = StateProperties45
        StateProperties46.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties46.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties46.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties46.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCPConfirmPass.OnDisabledState = StateProperties46
        StateProperties47.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties47.FillColor = System.Drawing.Color.Empty
        StateProperties47.ForeColor = System.Drawing.Color.Empty
        StateProperties47.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCPConfirmPass.OnHoverState = StateProperties47
        StateProperties48.BorderColor = System.Drawing.Color.Silver
        StateProperties48.FillColor = System.Drawing.Color.White
        StateProperties48.ForeColor = System.Drawing.Color.Empty
        StateProperties48.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCPConfirmPass.OnIdleState = StateProperties48
        Me.txtCPConfirmPass.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCPConfirmPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtCPConfirmPass.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCPConfirmPass.PlaceholderText = "Re-enter your new password"
        Me.txtCPConfirmPass.ReadOnly = False
        Me.txtCPConfirmPass.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtCPConfirmPass.SelectedText = ""
        Me.txtCPConfirmPass.SelectionLength = 0
        Me.txtCPConfirmPass.SelectionStart = 0
        Me.txtCPConfirmPass.ShortcutsEnabled = True
        Me.txtCPConfirmPass.Size = New System.Drawing.Size(327, 45)
        Me.txtCPConfirmPass.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtCPConfirmPass.TabIndex = 59
        Me.txtCPConfirmPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtCPConfirmPass.TextMarginBottom = 0
        Me.txtCPConfirmPass.TextMarginLeft = 3
        Me.txtCPConfirmPass.TextMarginTop = 0
        Me.txtCPConfirmPass.TextPlaceholder = "Re-enter your new password"
        Me.txtCPConfirmPass.UseSystemPasswordChar = False
        Me.txtCPConfirmPass.WordWrap = True
        '
        'btnUpdate
        '
        Me.btnUpdate.AllowAnimations = True
        Me.btnUpdate.AllowMouseEffects = True
        Me.btnUpdate.AllowToggling = False
        Me.btnUpdate.AnimationSpeed = 200
        Me.btnUpdate.AutoGenerateColors = False
        Me.btnUpdate.AutoRoundBorders = False
        Me.btnUpdate.AutoSizeLeftIcon = True
        Me.btnUpdate.AutoSizeRightIcon = True
        Me.btnUpdate.BackColor = System.Drawing.Color.Transparent
        Me.btnUpdate.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.BackgroundImage = CType(resources.GetObject("btnUpdate.BackgroundImage"), System.Drawing.Image)
        Me.btnUpdate.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.ButtonText = "Update"
        Me.btnUpdate.ButtonTextMarginLeft = 0
        Me.btnUpdate.ColorContrastOnClick = 45
        Me.btnUpdate.ColorContrastOnHover = 45
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges3.BottomLeft = True
        BorderEdges3.BottomRight = True
        BorderEdges3.TopLeft = True
        BorderEdges3.TopRight = True
        Me.btnUpdate.CustomizableEdges = BorderEdges3
        Me.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUpdate.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnUpdate.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUpdate.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUpdate.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUpdate.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnUpdate.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnUpdate.IconMarginLeft = 11
        Me.btnUpdate.IconPadding = 10
        Me.btnUpdate.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnUpdate.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnUpdate.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnUpdate.IconSize = 25
        Me.btnUpdate.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.IdleBorderRadius = 15
        Me.btnUpdate.IdleBorderThickness = 1
        Me.btnUpdate.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.IdleIconLeftImage = Nothing
        Me.btnUpdate.IdleIconRightImage = Nothing
        Me.btnUpdate.IndicateFocus = False
        Me.btnUpdate.Location = New System.Drawing.Point(284, 529)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnUpdate.OnDisabledState.BorderRadius = 15
        Me.btnUpdate.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnDisabledState.BorderThickness = 1
        Me.btnUpdate.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUpdate.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUpdate.OnDisabledState.IconLeftImage = Nothing
        Me.btnUpdate.OnDisabledState.IconRightImage = Nothing
        Me.btnUpdate.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUpdate.onHoverState.BorderRadius = 15
        Me.btnUpdate.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.onHoverState.BorderThickness = 1
        Me.btnUpdate.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUpdate.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.onHoverState.IconLeftImage = Nothing
        Me.btnUpdate.onHoverState.IconRightImage = Nothing
        Me.btnUpdate.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.OnIdleState.BorderRadius = 15
        Me.btnUpdate.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnIdleState.BorderThickness = 1
        Me.btnUpdate.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.OnIdleState.IconLeftImage = Nothing
        Me.btnUpdate.OnIdleState.IconRightImage = Nothing
        Me.btnUpdate.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnUpdate.OnPressedState.BorderRadius = 15
        Me.btnUpdate.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnPressedState.BorderThickness = 1
        Me.btnUpdate.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnUpdate.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.OnPressedState.IconLeftImage = Nothing
        Me.btnUpdate.OnPressedState.IconRightImage = Nothing
        Me.btnUpdate.Size = New System.Drawing.Size(78, 40)
        Me.btnUpdate.TabIndex = 61
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnUpdate.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnUpdate.TextMarginLeft = 0
        Me.btnUpdate.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnUpdate.UseDefaultRadiusAndThickness = True
        '
        'BunifuLabel15
        '
        Me.BunifuLabel15.AllowParentOverrides = False
        Me.BunifuLabel15.AutoEllipsis = False
        Me.BunifuLabel15.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel15.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel15.Font = New System.Drawing.Font("Cascadia Code", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel15.Location = New System.Drawing.Point(19, 14)
        Me.BunifuLabel15.Name = "BunifuLabel15"
        Me.BunifuLabel15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel15.Size = New System.Drawing.Size(132, 25)
        Me.BunifuLabel15.TabIndex = 5
        Me.BunifuLabel15.Text = "User Account"
        Me.BunifuLabel15.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel15.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuPanel2
        '
        Me.BunifuPanel2.BackgroundColor = System.Drawing.Color.Transparent
        Me.BunifuPanel2.BackgroundImage = CType(resources.GetObject("BunifuPanel2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuPanel2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(213, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BunifuPanel2.BorderRadius = 25
        Me.BunifuPanel2.BorderThickness = 1
        Me.BunifuPanel2.Controls.Add(Me.BunifuLabel21)
        Me.BunifuPanel2.Controls.Add(Me.BunifuLabel16)
        Me.BunifuPanel2.Controls.Add(Me.BunifuLabel20)
        Me.BunifuPanel2.Controls.Add(Me.txtUsername)
        Me.BunifuPanel2.Controls.Add(Me.BunifuLabel19)
        Me.BunifuPanel2.Controls.Add(Me.txtPassword)
        Me.BunifuPanel2.Controls.Add(Me.BunifuLabel18)
        Me.BunifuPanel2.Controls.Add(Me.txtConfirmPass)
        Me.BunifuPanel2.Controls.Add(Me.BunifuLabel17)
        Me.BunifuPanel2.Controls.Add(Me.txtNameUA)
        Me.BunifuPanel2.Controls.Add(Me.btnSaveUA)
        Me.BunifuPanel2.Location = New System.Drawing.Point(255, 94)
        Me.BunifuPanel2.Name = "BunifuPanel2"
        Me.BunifuPanel2.ShowBorders = True
        Me.BunifuPanel2.Size = New System.Drawing.Size(397, 604)
        Me.BunifuPanel2.TabIndex = 69
        '
        'BunifuLabel21
        '
        Me.BunifuLabel21.AllowParentOverrides = False
        Me.BunifuLabel21.AutoEllipsis = False
        Me.BunifuLabel21.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel21.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel21.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel21.Location = New System.Drawing.Point(35, 430)
        Me.BunifuLabel21.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel21.Name = "BunifuLabel21"
        Me.BunifuLabel21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel21.Size = New System.Drawing.Size(118, 21)
        Me.BunifuLabel21.TabIndex = 67
        Me.BunifuLabel21.Text = "User's Full Name"
        Me.BunifuLabel21.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel21.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel16
        '
        Me.BunifuLabel16.AllowParentOverrides = False
        Me.BunifuLabel16.AutoEllipsis = False
        Me.BunifuLabel16.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel16.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel16.Font = New System.Drawing.Font("Cascadia Mono", 12.0!)
        Me.BunifuLabel16.Location = New System.Drawing.Point(35, 49)
        Me.BunifuLabel16.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel16.Name = "BunifuLabel16"
        Me.BunifuLabel16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel16.Size = New System.Drawing.Size(171, 21)
        Me.BunifuLabel16.TabIndex = 60
        Me.BunifuLabel16.Text = "Create User Account"
        Me.BunifuLabel16.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel16.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel20
        '
        Me.BunifuLabel20.AllowParentOverrides = False
        Me.BunifuLabel20.AutoEllipsis = False
        Me.BunifuLabel20.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel20.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel20.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel20.Location = New System.Drawing.Point(35, 332)
        Me.BunifuLabel20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel20.Name = "BunifuLabel20"
        Me.BunifuLabel20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel20.Size = New System.Drawing.Size(128, 21)
        Me.BunifuLabel20.TabIndex = 66
        Me.BunifuLabel20.Text = "Confirm Password"
        Me.BunifuLabel20.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel20.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtUsername
        '
        Me.txtUsername.AcceptsReturn = False
        Me.txtUsername.AcceptsTab = False
        Me.txtUsername.AnimationSpeed = 200
        Me.txtUsername.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtUsername.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtUsername.BackColor = System.Drawing.Color.White
        Me.txtUsername.BackgroundImage = CType(resources.GetObject("txtUsername.BackgroundImage"), System.Drawing.Image)
        Me.txtUsername.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtUsername.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtUsername.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtUsername.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtUsername.BorderRadius = 15
        Me.txtUsername.BorderThickness = 1
        Me.txtUsername.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtUsername.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUsername.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtUsername.DefaultText = ""
        Me.txtUsername.FillColor = System.Drawing.Color.White
        Me.txtUsername.HideSelection = True
        Me.txtUsername.IconLeft = Nothing
        Me.txtUsername.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUsername.IconPadding = 10
        Me.txtUsername.IconRight = Nothing
        Me.txtUsername.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUsername.Lines = New String(-1) {}
        Me.txtUsername.Location = New System.Drawing.Point(35, 173)
        Me.txtUsername.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtUsername.MaxLength = 32767
        Me.txtUsername.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtUsername.Modified = False
        Me.txtUsername.Multiline = False
        Me.txtUsername.Name = "txtUsername"
        StateProperties49.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties49.FillColor = System.Drawing.Color.Empty
        StateProperties49.ForeColor = System.Drawing.Color.Empty
        StateProperties49.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtUsername.OnActiveState = StateProperties49
        StateProperties50.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties50.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties50.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties50.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtUsername.OnDisabledState = StateProperties50
        StateProperties51.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties51.FillColor = System.Drawing.Color.Empty
        StateProperties51.ForeColor = System.Drawing.Color.Empty
        StateProperties51.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtUsername.OnHoverState = StateProperties51
        StateProperties52.BorderColor = System.Drawing.Color.Silver
        StateProperties52.FillColor = System.Drawing.Color.White
        StateProperties52.ForeColor = System.Drawing.Color.Empty
        StateProperties52.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtUsername.OnIdleState = StateProperties52
        Me.txtUsername.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtUsername.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtUsername.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtUsername.PlaceholderText = "Username"
        Me.txtUsername.ReadOnly = False
        Me.txtUsername.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtUsername.SelectedText = ""
        Me.txtUsername.SelectionLength = 0
        Me.txtUsername.SelectionStart = 0
        Me.txtUsername.ShortcutsEnabled = True
        Me.txtUsername.Size = New System.Drawing.Size(327, 45)
        Me.txtUsername.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtUsername.TabIndex = 56
        Me.txtUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtUsername.TextMarginBottom = 0
        Me.txtUsername.TextMarginLeft = 3
        Me.txtUsername.TextMarginTop = 0
        Me.txtUsername.TextPlaceholder = "Username"
        Me.txtUsername.UseSystemPasswordChar = False
        Me.txtUsername.WordWrap = True
        '
        'BunifuLabel19
        '
        Me.BunifuLabel19.AllowParentOverrides = False
        Me.BunifuLabel19.AutoEllipsis = False
        Me.BunifuLabel19.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel19.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel19.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel19.Location = New System.Drawing.Point(35, 234)
        Me.BunifuLabel19.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel19.Name = "BunifuLabel19"
        Me.BunifuLabel19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel19.Size = New System.Drawing.Size(67, 21)
        Me.BunifuLabel19.TabIndex = 65
        Me.BunifuLabel19.Text = "Password"
        Me.BunifuLabel19.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel19.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtPassword
        '
        Me.txtPassword.AcceptsReturn = False
        Me.txtPassword.AcceptsTab = False
        Me.txtPassword.AnimationSpeed = 200
        Me.txtPassword.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtPassword.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtPassword.BackColor = System.Drawing.Color.White
        Me.txtPassword.BackgroundImage = CType(resources.GetObject("txtPassword.BackgroundImage"), System.Drawing.Image)
        Me.txtPassword.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtPassword.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtPassword.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPassword.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtPassword.BorderRadius = 15
        Me.txtPassword.BorderThickness = 1
        Me.txtPassword.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPassword.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtPassword.DefaultText = ""
        Me.txtPassword.FillColor = System.Drawing.Color.White
        Me.txtPassword.HideSelection = True
        Me.txtPassword.IconLeft = Nothing
        Me.txtPassword.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPassword.IconPadding = 10
        Me.txtPassword.IconRight = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.show
        Me.txtPassword.IconRightCursor = System.Windows.Forms.Cursors.Hand
        Me.txtPassword.Lines = New String(-1) {}
        Me.txtPassword.Location = New System.Drawing.Point(35, 271)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPassword.MaxLength = 32767
        Me.txtPassword.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtPassword.Modified = False
        Me.txtPassword.Multiline = False
        Me.txtPassword.Name = "txtPassword"
        StateProperties53.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties53.FillColor = System.Drawing.Color.Empty
        StateProperties53.ForeColor = System.Drawing.Color.Empty
        StateProperties53.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtPassword.OnActiveState = StateProperties53
        StateProperties54.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties54.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties54.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties54.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtPassword.OnDisabledState = StateProperties54
        StateProperties55.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties55.FillColor = System.Drawing.Color.Empty
        StateProperties55.ForeColor = System.Drawing.Color.Empty
        StateProperties55.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPassword.OnHoverState = StateProperties55
        StateProperties56.BorderColor = System.Drawing.Color.Silver
        StateProperties56.FillColor = System.Drawing.Color.White
        StateProperties56.ForeColor = System.Drawing.Color.Empty
        StateProperties56.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtPassword.OnIdleState = StateProperties56
        Me.txtPassword.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtPassword.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtPassword.PlaceholderText = "Create a strong password"
        Me.txtPassword.ReadOnly = False
        Me.txtPassword.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtPassword.SelectedText = ""
        Me.txtPassword.SelectionLength = 0
        Me.txtPassword.SelectionStart = 0
        Me.txtPassword.ShortcutsEnabled = True
        Me.txtPassword.Size = New System.Drawing.Size(327, 45)
        Me.txtPassword.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtPassword.TabIndex = 57
        Me.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtPassword.TextMarginBottom = 0
        Me.txtPassword.TextMarginLeft = 3
        Me.txtPassword.TextMarginTop = 0
        Me.txtPassword.TextPlaceholder = "Create a strong password"
        Me.txtPassword.UseSystemPasswordChar = False
        Me.txtPassword.WordWrap = True
        '
        'BunifuLabel18
        '
        Me.BunifuLabel18.AllowParentOverrides = False
        Me.BunifuLabel18.AutoEllipsis = False
        Me.BunifuLabel18.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel18.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel18.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel18.Location = New System.Drawing.Point(35, 136)
        Me.BunifuLabel18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel18.Name = "BunifuLabel18"
        Me.BunifuLabel18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel18.Size = New System.Drawing.Size(71, 21)
        Me.BunifuLabel18.TabIndex = 64
        Me.BunifuLabel18.Text = "Username"
        Me.BunifuLabel18.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel18.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtConfirmPass
        '
        Me.txtConfirmPass.AcceptsReturn = False
        Me.txtConfirmPass.AcceptsTab = False
        Me.txtConfirmPass.AnimationSpeed = 200
        Me.txtConfirmPass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtConfirmPass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtConfirmPass.BackColor = System.Drawing.Color.White
        Me.txtConfirmPass.BackgroundImage = CType(resources.GetObject("txtConfirmPass.BackgroundImage"), System.Drawing.Image)
        Me.txtConfirmPass.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtConfirmPass.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtConfirmPass.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtConfirmPass.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtConfirmPass.BorderRadius = 15
        Me.txtConfirmPass.BorderThickness = 1
        Me.txtConfirmPass.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtConfirmPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtConfirmPass.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtConfirmPass.DefaultText = ""
        Me.txtConfirmPass.FillColor = System.Drawing.Color.White
        Me.txtConfirmPass.HideSelection = True
        Me.txtConfirmPass.IconLeft = Nothing
        Me.txtConfirmPass.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtConfirmPass.IconPadding = 10
        Me.txtConfirmPass.IconRight = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.show
        Me.txtConfirmPass.IconRightCursor = System.Windows.Forms.Cursors.Hand
        Me.txtConfirmPass.Lines = New String(-1) {}
        Me.txtConfirmPass.Location = New System.Drawing.Point(35, 369)
        Me.txtConfirmPass.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtConfirmPass.MaxLength = 32767
        Me.txtConfirmPass.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtConfirmPass.Modified = False
        Me.txtConfirmPass.Multiline = False
        Me.txtConfirmPass.Name = "txtConfirmPass"
        StateProperties57.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties57.FillColor = System.Drawing.Color.Empty
        StateProperties57.ForeColor = System.Drawing.Color.Empty
        StateProperties57.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtConfirmPass.OnActiveState = StateProperties57
        StateProperties58.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties58.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties58.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties58.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtConfirmPass.OnDisabledState = StateProperties58
        StateProperties59.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties59.FillColor = System.Drawing.Color.Empty
        StateProperties59.ForeColor = System.Drawing.Color.Empty
        StateProperties59.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtConfirmPass.OnHoverState = StateProperties59
        StateProperties60.BorderColor = System.Drawing.Color.Silver
        StateProperties60.FillColor = System.Drawing.Color.White
        StateProperties60.ForeColor = System.Drawing.Color.Empty
        StateProperties60.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtConfirmPass.OnIdleState = StateProperties60
        Me.txtConfirmPass.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtConfirmPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtConfirmPass.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtConfirmPass.PlaceholderText = "Re-enter your password for verification"
        Me.txtConfirmPass.ReadOnly = False
        Me.txtConfirmPass.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtConfirmPass.SelectedText = ""
        Me.txtConfirmPass.SelectionLength = 0
        Me.txtConfirmPass.SelectionStart = 0
        Me.txtConfirmPass.ShortcutsEnabled = True
        Me.txtConfirmPass.Size = New System.Drawing.Size(327, 45)
        Me.txtConfirmPass.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtConfirmPass.TabIndex = 58
        Me.txtConfirmPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtConfirmPass.TextMarginBottom = 0
        Me.txtConfirmPass.TextMarginLeft = 3
        Me.txtConfirmPass.TextMarginTop = 0
        Me.txtConfirmPass.TextPlaceholder = "Re-enter your password for verification"
        Me.txtConfirmPass.UseSystemPasswordChar = False
        Me.txtConfirmPass.WordWrap = True
        '
        'BunifuLabel17
        '
        Me.BunifuLabel17.AllowParentOverrides = False
        Me.BunifuLabel17.AutoEllipsis = False
        Me.BunifuLabel17.AutoSize = False
        Me.BunifuLabel17.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel17.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel17.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel17.Location = New System.Drawing.Point(35, 78)
        Me.BunifuLabel17.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel17.Name = "BunifuLabel17"
        Me.BunifuLabel17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel17.Size = New System.Drawing.Size(327, 50)
        Me.BunifuLabel17.TabIndex = 63
        Me.BunifuLabel17.Text = "Set up an employee account by providing essential details and a secure password."
        Me.BunifuLabel17.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel17.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtNameUA
        '
        Me.txtNameUA.AcceptsReturn = False
        Me.txtNameUA.AcceptsTab = False
        Me.txtNameUA.AnimationSpeed = 200
        Me.txtNameUA.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtNameUA.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtNameUA.BackColor = System.Drawing.Color.White
        Me.txtNameUA.BackgroundImage = CType(resources.GetObject("txtNameUA.BackgroundImage"), System.Drawing.Image)
        Me.txtNameUA.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtNameUA.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtNameUA.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtNameUA.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtNameUA.BorderRadius = 15
        Me.txtNameUA.BorderThickness = 1
        Me.txtNameUA.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtNameUA.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNameUA.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtNameUA.DefaultText = ""
        Me.txtNameUA.FillColor = System.Drawing.Color.White
        Me.txtNameUA.HideSelection = True
        Me.txtNameUA.IconLeft = Nothing
        Me.txtNameUA.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNameUA.IconPadding = 10
        Me.txtNameUA.IconRight = Nothing
        Me.txtNameUA.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtNameUA.Lines = New String(-1) {}
        Me.txtNameUA.Location = New System.Drawing.Point(35, 467)
        Me.txtNameUA.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtNameUA.MaxLength = 32767
        Me.txtNameUA.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtNameUA.Modified = False
        Me.txtNameUA.Multiline = False
        Me.txtNameUA.Name = "txtNameUA"
        StateProperties61.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties61.FillColor = System.Drawing.Color.Empty
        StateProperties61.ForeColor = System.Drawing.Color.Empty
        StateProperties61.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtNameUA.OnActiveState = StateProperties61
        StateProperties62.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties62.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties62.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties62.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtNameUA.OnDisabledState = StateProperties62
        StateProperties63.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties63.FillColor = System.Drawing.Color.Empty
        StateProperties63.ForeColor = System.Drawing.Color.Empty
        StateProperties63.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtNameUA.OnHoverState = StateProperties63
        StateProperties64.BorderColor = System.Drawing.Color.Silver
        StateProperties64.FillColor = System.Drawing.Color.White
        StateProperties64.ForeColor = System.Drawing.Color.Empty
        StateProperties64.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtNameUA.OnIdleState = StateProperties64
        Me.txtNameUA.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtNameUA.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtNameUA.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtNameUA.PlaceholderText = "Last Name, First Name M.I."
        Me.txtNameUA.ReadOnly = False
        Me.txtNameUA.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtNameUA.SelectedText = ""
        Me.txtNameUA.SelectionLength = 0
        Me.txtNameUA.SelectionStart = 0
        Me.txtNameUA.ShortcutsEnabled = True
        Me.txtNameUA.Size = New System.Drawing.Size(327, 45)
        Me.txtNameUA.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu
        Me.txtNameUA.TabIndex = 59
        Me.txtNameUA.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtNameUA.TextMarginBottom = 0
        Me.txtNameUA.TextMarginLeft = 3
        Me.txtNameUA.TextMarginTop = 0
        Me.txtNameUA.TextPlaceholder = "Last Name, First Name M.I."
        Me.txtNameUA.UseSystemPasswordChar = False
        Me.txtNameUA.WordWrap = True
        '
        'btnSaveUA
        '
        Me.btnSaveUA.AllowAnimations = True
        Me.btnSaveUA.AllowMouseEffects = True
        Me.btnSaveUA.AllowToggling = False
        Me.btnSaveUA.AnimationSpeed = 200
        Me.btnSaveUA.AutoGenerateColors = False
        Me.btnSaveUA.AutoRoundBorders = False
        Me.btnSaveUA.AutoSizeLeftIcon = True
        Me.btnSaveUA.AutoSizeRightIcon = True
        Me.btnSaveUA.BackColor = System.Drawing.Color.Transparent
        Me.btnSaveUA.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnSaveUA.BackgroundImage = CType(resources.GetObject("btnSaveUA.BackgroundImage"), System.Drawing.Image)
        Me.btnSaveUA.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSaveUA.ButtonText = "Save"
        Me.btnSaveUA.ButtonTextMarginLeft = 0
        Me.btnSaveUA.ColorContrastOnClick = 45
        Me.btnSaveUA.ColorContrastOnHover = 45
        Me.btnSaveUA.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges4.BottomLeft = True
        BorderEdges4.BottomRight = True
        BorderEdges4.TopLeft = True
        BorderEdges4.TopRight = True
        Me.btnSaveUA.CustomizableEdges = BorderEdges4
        Me.btnSaveUA.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSaveUA.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSaveUA.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSaveUA.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSaveUA.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnSaveUA.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveUA.ForeColor = System.Drawing.Color.White
        Me.btnSaveUA.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSaveUA.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnSaveUA.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnSaveUA.IconMarginLeft = 11
        Me.btnSaveUA.IconPadding = 10
        Me.btnSaveUA.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSaveUA.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnSaveUA.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnSaveUA.IconSize = 25
        Me.btnSaveUA.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSaveUA.IdleBorderRadius = 15
        Me.btnSaveUA.IdleBorderThickness = 1
        Me.btnSaveUA.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnSaveUA.IdleIconLeftImage = Nothing
        Me.btnSaveUA.IdleIconRightImage = Nothing
        Me.btnSaveUA.IndicateFocus = False
        Me.btnSaveUA.Location = New System.Drawing.Point(284, 529)
        Me.btnSaveUA.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSaveUA.Name = "btnSaveUA"
        Me.btnSaveUA.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSaveUA.OnDisabledState.BorderRadius = 15
        Me.btnSaveUA.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSaveUA.OnDisabledState.BorderThickness = 1
        Me.btnSaveUA.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSaveUA.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSaveUA.OnDisabledState.IconLeftImage = Nothing
        Me.btnSaveUA.OnDisabledState.IconRightImage = Nothing
        Me.btnSaveUA.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSaveUA.onHoverState.BorderRadius = 15
        Me.btnSaveUA.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSaveUA.onHoverState.BorderThickness = 1
        Me.btnSaveUA.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSaveUA.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnSaveUA.onHoverState.IconLeftImage = Nothing
        Me.btnSaveUA.onHoverState.IconRightImage = Nothing
        Me.btnSaveUA.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSaveUA.OnIdleState.BorderRadius = 15
        Me.btnSaveUA.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSaveUA.OnIdleState.BorderThickness = 1
        Me.btnSaveUA.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnSaveUA.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnSaveUA.OnIdleState.IconLeftImage = Nothing
        Me.btnSaveUA.OnIdleState.IconRightImage = Nothing
        Me.btnSaveUA.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSaveUA.OnPressedState.BorderRadius = 15
        Me.btnSaveUA.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSaveUA.OnPressedState.BorderThickness = 1
        Me.btnSaveUA.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSaveUA.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnSaveUA.OnPressedState.IconLeftImage = Nothing
        Me.btnSaveUA.OnPressedState.IconRightImage = Nothing
        Me.btnSaveUA.Size = New System.Drawing.Size(78, 40)
        Me.btnSaveUA.TabIndex = 61
        Me.btnSaveUA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSaveUA.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnSaveUA.TextMarginLeft = 0
        Me.btnSaveUA.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnSaveUA.UseDefaultRadiusAndThickness = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblSystemTitle)
        Me.Panel1.Controls.Add(Me.lblCurrentUser)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(240, 167)
        Me.Panel1.TabIndex = 2
        '
        'lblSystemTitle
        '
        Me.lblSystemTitle.Font = New System.Drawing.Font("Cascadia Code SemiBold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSystemTitle.ForeColor = System.Drawing.Color.White
        Me.lblSystemTitle.Location = New System.Drawing.Point(20, 88)
        Me.lblSystemTitle.Name = "lblSystemTitle"
        Me.lblSystemTitle.Size = New System.Drawing.Size(200, 40)
        Me.lblSystemTitle.TabIndex = 4
        Me.lblSystemTitle.Text = "OSA Violation Records Management System"
        Me.lblSystemTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCurrentUser
        '
        Me.lblCurrentUser.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentUser.ForeColor = System.Drawing.Color.White
        Me.lblCurrentUser.Location = New System.Drawing.Point(20, 136)
        Me.lblCurrentUser.Name = "lblCurrentUser"
        Me.lblCurrentUser.Size = New System.Drawing.Size(200, 27)
        Me.lblCurrentUser.TabIndex = 3
        Me.lblCurrentUser.Text = "Name"
        Me.lblCurrentUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.LOA_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(81, 11)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(85, 74)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'fpnlSidebar
        '
        Me.fpnlSidebar.BackColor = System.Drawing.Color.DodgerBlue
        Me.fpnlSidebar.Controls.Add(Me.Panel1)
        Me.fpnlSidebar.Controls.Add(Me.pnlButtons)
        Me.fpnlSidebar.Dock = System.Windows.Forms.DockStyle.Left
        Me.fpnlSidebar.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.fpnlSidebar.Location = New System.Drawing.Point(0, 32)
        Me.fpnlSidebar.Name = "fpnlSidebar"
        Me.fpnlSidebar.Size = New System.Drawing.Size(240, 818)
        Me.fpnlSidebar.TabIndex = 12
        '
        'pnlButtons
        '
        Me.pnlButtons.Controls.Add(Me.pnlIndicator)
        Me.pnlButtons.Controls.Add(Me.btnUserAccount)
        Me.pnlButtons.Controls.Add(Me.btnAcademic)
        Me.pnlButtons.Controls.Add(Me.btnSection)
        Me.pnlButtons.Controls.Add(Me.btnProgram)
        Me.pnlButtons.Controls.Add(Me.btnRecords)
        Me.pnlButtons.Controls.Add(Me.btnViolation)
        Me.pnlButtons.Controls.Add(Me.btnStudent)
        Me.pnlButtons.Controls.Add(Me.btnDashboard)
        Me.pnlButtons.Controls.Add(Me.btnLogout)
        Me.pnlButtons.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlButtons.Location = New System.Drawing.Point(3, 176)
        Me.pnlButtons.Name = "pnlButtons"
        Me.pnlButtons.Size = New System.Drawing.Size(240, 639)
        Me.pnlButtons.TabIndex = 3
        '
        'pnlIndicator
        '
        Me.pnlIndicator.AllowAnimations = False
        Me.pnlIndicator.AllowBorderColorChanges = False
        Me.pnlIndicator.AllowMouseEffects = False
        Me.pnlIndicator.AnimationSpeed = 200
        Me.pnlIndicator.BackColor = System.Drawing.Color.Transparent
        Me.pnlIndicator.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.pnlIndicator.BorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.pnlIndicator.BorderRadius = 15
        Me.pnlIndicator.BorderStyle = Bunifu.UI.WinForms.BunifuUserControl.BorderStyles.Solid
        Me.pnlIndicator.BorderThickness = 1
        Me.pnlIndicator.ColorContrastOnClick = 30
        Me.pnlIndicator.ColorContrastOnHover = 30
        Me.pnlIndicator.Cursor = System.Windows.Forms.Cursors.Default
        Me.pnlIndicator.Image = Nothing
        Me.pnlIndicator.ImageMargin = New System.Windows.Forms.Padding(0)
        Me.pnlIndicator.Location = New System.Drawing.Point(0, 0)
        Me.pnlIndicator.Name = "pnlIndicator"
        Me.pnlIndicator.ShowBorders = True
        Me.pnlIndicator.Size = New System.Drawing.Size(16, 44)
        Me.pnlIndicator.Style = Bunifu.UI.WinForms.BunifuUserControl.UserControlStyles.Flat
        Me.pnlIndicator.TabIndex = 71
        '
        'btnUserAccount
        '
        Me.btnUserAccount.AllowAnimations = True
        Me.btnUserAccount.AllowMouseEffects = True
        Me.btnUserAccount.AllowToggling = False
        Me.btnUserAccount.AnimationSpeed = 200
        Me.btnUserAccount.AutoGenerateColors = False
        Me.btnUserAccount.AutoRoundBorders = False
        Me.btnUserAccount.AutoSizeLeftIcon = True
        Me.btnUserAccount.AutoSizeRightIcon = True
        Me.btnUserAccount.BackColor = System.Drawing.Color.Transparent
        Me.btnUserAccount.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnUserAccount.BackgroundImage = CType(resources.GetObject("btnUserAccount.BackgroundImage"), System.Drawing.Image)
        Me.btnUserAccount.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUserAccount.ButtonText = "User Account"
        Me.btnUserAccount.ButtonTextMarginLeft = 0
        Me.btnUserAccount.ColorContrastOnClick = 45
        Me.btnUserAccount.ColorContrastOnHover = 45
        Me.btnUserAccount.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges5.BottomLeft = True
        BorderEdges5.BottomRight = True
        BorderEdges5.TopLeft = True
        BorderEdges5.TopRight = True
        Me.btnUserAccount.CustomizableEdges = BorderEdges5
        Me.btnUserAccount.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUserAccount.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnUserAccount.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnUserAccount.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUserAccount.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnUserAccount.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnUserAccount.ForeColor = System.Drawing.Color.White
        Me.btnUserAccount.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUserAccount.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnUserAccount.IconLeftPadding = New System.Windows.Forms.Padding(25, 3, 3, 3)
        Me.btnUserAccount.IconMarginLeft = 11
        Me.btnUserAccount.IconPadding = 10
        Me.btnUserAccount.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnUserAccount.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnUserAccount.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnUserAccount.IconSize = 25
        Me.btnUserAccount.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUserAccount.IdleBorderRadius = 1
        Me.btnUserAccount.IdleBorderThickness = 1
        Me.btnUserAccount.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnUserAccount.IdleIconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_user_35
        Me.btnUserAccount.IdleIconRightImage = Nothing
        Me.btnUserAccount.IndicateFocus = False
        Me.btnUserAccount.Location = New System.Drawing.Point(0, 308)
        Me.btnUserAccount.Name = "btnUserAccount"
        Me.btnUserAccount.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnUserAccount.OnDisabledState.BorderRadius = 1
        Me.btnUserAccount.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUserAccount.OnDisabledState.BorderThickness = 1
        Me.btnUserAccount.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnUserAccount.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUserAccount.OnDisabledState.IconLeftImage = Nothing
        Me.btnUserAccount.OnDisabledState.IconRightImage = Nothing
        Me.btnUserAccount.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnUserAccount.onHoverState.BorderRadius = 1
        Me.btnUserAccount.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUserAccount.onHoverState.BorderThickness = 1
        Me.btnUserAccount.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnUserAccount.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnUserAccount.onHoverState.IconLeftImage = Nothing
        Me.btnUserAccount.onHoverState.IconRightImage = Nothing
        Me.btnUserAccount.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUserAccount.OnIdleState.BorderRadius = 1
        Me.btnUserAccount.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUserAccount.OnIdleState.BorderThickness = 1
        Me.btnUserAccount.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnUserAccount.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnUserAccount.OnIdleState.IconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_user_35
        Me.btnUserAccount.OnIdleState.IconRightImage = Nothing
        Me.btnUserAccount.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUserAccount.OnPressedState.BorderRadius = 1
        Me.btnUserAccount.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUserAccount.OnPressedState.BorderThickness = 1
        Me.btnUserAccount.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUserAccount.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnUserAccount.OnPressedState.IconLeftImage = Nothing
        Me.btnUserAccount.OnPressedState.IconRightImage = Nothing
        Me.btnUserAccount.Size = New System.Drawing.Size(240, 44)
        Me.btnUserAccount.TabIndex = 10
        Me.btnUserAccount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnUserAccount.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnUserAccount.TextMarginLeft = 0
        Me.btnUserAccount.TextPadding = New System.Windows.Forms.Padding(13, 0, 0, 0)
        Me.btnUserAccount.UseDefaultRadiusAndThickness = True
        '
        'btnAcademic
        '
        Me.btnAcademic.AllowAnimations = True
        Me.btnAcademic.AllowMouseEffects = True
        Me.btnAcademic.AllowToggling = False
        Me.btnAcademic.AnimationSpeed = 200
        Me.btnAcademic.AutoGenerateColors = False
        Me.btnAcademic.AutoRoundBorders = False
        Me.btnAcademic.AutoSizeLeftIcon = True
        Me.btnAcademic.AutoSizeRightIcon = True
        Me.btnAcademic.BackColor = System.Drawing.Color.Transparent
        Me.btnAcademic.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnAcademic.BackgroundImage = CType(resources.GetObject("btnAcademic.BackgroundImage"), System.Drawing.Image)
        Me.btnAcademic.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnAcademic.ButtonText = "Academic Year"
        Me.btnAcademic.ButtonTextMarginLeft = 0
        Me.btnAcademic.ColorContrastOnClick = 45
        Me.btnAcademic.ColorContrastOnHover = 45
        Me.btnAcademic.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges6.BottomLeft = True
        BorderEdges6.BottomRight = True
        BorderEdges6.TopLeft = True
        BorderEdges6.TopRight = True
        Me.btnAcademic.CustomizableEdges = BorderEdges6
        Me.btnAcademic.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnAcademic.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAcademic.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAcademic.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnAcademic.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnAcademic.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnAcademic.ForeColor = System.Drawing.Color.White
        Me.btnAcademic.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAcademic.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnAcademic.IconLeftPadding = New System.Windows.Forms.Padding(25, 3, 3, 3)
        Me.btnAcademic.IconMarginLeft = 11
        Me.btnAcademic.IconPadding = 10
        Me.btnAcademic.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnAcademic.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnAcademic.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnAcademic.IconSize = 25
        Me.btnAcademic.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnAcademic.IdleBorderRadius = 1
        Me.btnAcademic.IdleBorderThickness = 1
        Me.btnAcademic.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnAcademic.IdleIconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_calendar_32__2_
        Me.btnAcademic.IdleIconRightImage = Nothing
        Me.btnAcademic.IndicateFocus = False
        Me.btnAcademic.Location = New System.Drawing.Point(0, 264)
        Me.btnAcademic.Name = "btnAcademic"
        Me.btnAcademic.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAcademic.OnDisabledState.BorderRadius = 1
        Me.btnAcademic.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnAcademic.OnDisabledState.BorderThickness = 1
        Me.btnAcademic.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnAcademic.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnAcademic.OnDisabledState.IconLeftImage = Nothing
        Me.btnAcademic.OnDisabledState.IconRightImage = Nothing
        Me.btnAcademic.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnAcademic.onHoverState.BorderRadius = 1
        Me.btnAcademic.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnAcademic.onHoverState.BorderThickness = 1
        Me.btnAcademic.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnAcademic.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnAcademic.onHoverState.IconLeftImage = Nothing
        Me.btnAcademic.onHoverState.IconRightImage = Nothing
        Me.btnAcademic.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnAcademic.OnIdleState.BorderRadius = 1
        Me.btnAcademic.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnAcademic.OnIdleState.BorderThickness = 1
        Me.btnAcademic.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnAcademic.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnAcademic.OnIdleState.IconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_calendar_32__2_
        Me.btnAcademic.OnIdleState.IconRightImage = Nothing
        Me.btnAcademic.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAcademic.OnPressedState.BorderRadius = 1
        Me.btnAcademic.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnAcademic.OnPressedState.BorderThickness = 1
        Me.btnAcademic.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAcademic.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnAcademic.OnPressedState.IconLeftImage = Nothing
        Me.btnAcademic.OnPressedState.IconRightImage = Nothing
        Me.btnAcademic.Size = New System.Drawing.Size(240, 44)
        Me.btnAcademic.TabIndex = 9
        Me.btnAcademic.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnAcademic.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnAcademic.TextMarginLeft = 0
        Me.btnAcademic.TextPadding = New System.Windows.Forms.Padding(18, 0, 0, 0)
        Me.btnAcademic.UseDefaultRadiusAndThickness = True
        '
        'btnSection
        '
        Me.btnSection.AllowAnimations = True
        Me.btnSection.AllowMouseEffects = True
        Me.btnSection.AllowToggling = False
        Me.btnSection.AnimationSpeed = 200
        Me.btnSection.AutoGenerateColors = False
        Me.btnSection.AutoRoundBorders = False
        Me.btnSection.AutoSizeLeftIcon = True
        Me.btnSection.AutoSizeRightIcon = True
        Me.btnSection.BackColor = System.Drawing.Color.Transparent
        Me.btnSection.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnSection.BackgroundImage = CType(resources.GetObject("btnSection.BackgroundImage"), System.Drawing.Image)
        Me.btnSection.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSection.ButtonText = "Section"
        Me.btnSection.ButtonTextMarginLeft = 0
        Me.btnSection.ColorContrastOnClick = 45
        Me.btnSection.ColorContrastOnHover = 45
        Me.btnSection.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges7.BottomLeft = True
        BorderEdges7.BottomRight = True
        BorderEdges7.TopLeft = True
        BorderEdges7.TopRight = True
        Me.btnSection.CustomizableEdges = BorderEdges7
        Me.btnSection.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSection.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSection.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSection.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSection.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnSection.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnSection.ForeColor = System.Drawing.Color.White
        Me.btnSection.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSection.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnSection.IconLeftPadding = New System.Windows.Forms.Padding(25, 3, 3, 3)
        Me.btnSection.IconMarginLeft = 11
        Me.btnSection.IconPadding = 10
        Me.btnSection.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSection.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnSection.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnSection.IconSize = 25
        Me.btnSection.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSection.IdleBorderRadius = 1
        Me.btnSection.IdleBorderThickness = 1
        Me.btnSection.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnSection.IdleIconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_folder_32__1_
        Me.btnSection.IdleIconRightImage = Nothing
        Me.btnSection.IndicateFocus = False
        Me.btnSection.Location = New System.Drawing.Point(0, 220)
        Me.btnSection.Name = "btnSection"
        Me.btnSection.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSection.OnDisabledState.BorderRadius = 1
        Me.btnSection.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSection.OnDisabledState.BorderThickness = 1
        Me.btnSection.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnSection.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSection.OnDisabledState.IconLeftImage = Nothing
        Me.btnSection.OnDisabledState.IconRightImage = Nothing
        Me.btnSection.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnSection.onHoverState.BorderRadius = 1
        Me.btnSection.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSection.onHoverState.BorderThickness = 1
        Me.btnSection.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnSection.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnSection.onHoverState.IconLeftImage = Nothing
        Me.btnSection.onHoverState.IconRightImage = Nothing
        Me.btnSection.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSection.OnIdleState.BorderRadius = 1
        Me.btnSection.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSection.OnIdleState.BorderThickness = 1
        Me.btnSection.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnSection.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnSection.OnIdleState.IconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_folder_32__1_
        Me.btnSection.OnIdleState.IconRightImage = Nothing
        Me.btnSection.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSection.OnPressedState.BorderRadius = 1
        Me.btnSection.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSection.OnPressedState.BorderThickness = 1
        Me.btnSection.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSection.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnSection.OnPressedState.IconLeftImage = Nothing
        Me.btnSection.OnPressedState.IconRightImage = Nothing
        Me.btnSection.Size = New System.Drawing.Size(240, 44)
        Me.btnSection.TabIndex = 8
        Me.btnSection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSection.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnSection.TextMarginLeft = 0
        Me.btnSection.TextPadding = New System.Windows.Forms.Padding(-9, 0, 0, 0)
        Me.btnSection.UseDefaultRadiusAndThickness = True
        '
        'btnProgram
        '
        Me.btnProgram.AllowAnimations = True
        Me.btnProgram.AllowMouseEffects = True
        Me.btnProgram.AllowToggling = False
        Me.btnProgram.AnimationSpeed = 200
        Me.btnProgram.AutoGenerateColors = False
        Me.btnProgram.AutoRoundBorders = False
        Me.btnProgram.AutoSizeLeftIcon = True
        Me.btnProgram.AutoSizeRightIcon = True
        Me.btnProgram.BackColor = System.Drawing.Color.Transparent
        Me.btnProgram.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnProgram.BackgroundImage = CType(resources.GetObject("btnProgram.BackgroundImage"), System.Drawing.Image)
        Me.btnProgram.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnProgram.ButtonText = "Program"
        Me.btnProgram.ButtonTextMarginLeft = 0
        Me.btnProgram.ColorContrastOnClick = 45
        Me.btnProgram.ColorContrastOnHover = 45
        Me.btnProgram.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges8.BottomLeft = True
        BorderEdges8.BottomRight = True
        BorderEdges8.TopLeft = True
        BorderEdges8.TopRight = True
        Me.btnProgram.CustomizableEdges = BorderEdges8
        Me.btnProgram.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnProgram.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnProgram.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnProgram.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnProgram.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnProgram.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnProgram.ForeColor = System.Drawing.Color.White
        Me.btnProgram.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnProgram.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnProgram.IconLeftPadding = New System.Windows.Forms.Padding(25, 3, 3, 3)
        Me.btnProgram.IconMarginLeft = 11
        Me.btnProgram.IconPadding = 10
        Me.btnProgram.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnProgram.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnProgram.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnProgram.IconSize = 25
        Me.btnProgram.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnProgram.IdleBorderRadius = 1
        Me.btnProgram.IdleBorderThickness = 1
        Me.btnProgram.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnProgram.IdleIconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_folder_32__1_
        Me.btnProgram.IdleIconRightImage = Nothing
        Me.btnProgram.IndicateFocus = False
        Me.btnProgram.Location = New System.Drawing.Point(0, 176)
        Me.btnProgram.Name = "btnProgram"
        Me.btnProgram.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnProgram.OnDisabledState.BorderRadius = 1
        Me.btnProgram.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnProgram.OnDisabledState.BorderThickness = 1
        Me.btnProgram.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnProgram.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnProgram.OnDisabledState.IconLeftImage = Nothing
        Me.btnProgram.OnDisabledState.IconRightImage = Nothing
        Me.btnProgram.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnProgram.onHoverState.BorderRadius = 1
        Me.btnProgram.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnProgram.onHoverState.BorderThickness = 1
        Me.btnProgram.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnProgram.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnProgram.onHoverState.IconLeftImage = Nothing
        Me.btnProgram.onHoverState.IconRightImage = Nothing
        Me.btnProgram.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnProgram.OnIdleState.BorderRadius = 1
        Me.btnProgram.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnProgram.OnIdleState.BorderThickness = 1
        Me.btnProgram.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnProgram.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnProgram.OnIdleState.IconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_folder_32__1_
        Me.btnProgram.OnIdleState.IconRightImage = Nothing
        Me.btnProgram.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnProgram.OnPressedState.BorderRadius = 1
        Me.btnProgram.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnProgram.OnPressedState.BorderThickness = 1
        Me.btnProgram.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnProgram.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnProgram.OnPressedState.IconLeftImage = Nothing
        Me.btnProgram.OnPressedState.IconRightImage = Nothing
        Me.btnProgram.Size = New System.Drawing.Size(240, 44)
        Me.btnProgram.TabIndex = 7
        Me.btnProgram.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnProgram.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnProgram.TextMarginLeft = 0
        Me.btnProgram.TextPadding = New System.Windows.Forms.Padding(-9, 0, 0, 0)
        Me.btnProgram.UseDefaultRadiusAndThickness = True
        '
        'btnRecords
        '
        Me.btnRecords.AllowAnimations = True
        Me.btnRecords.AllowMouseEffects = True
        Me.btnRecords.AllowToggling = False
        Me.btnRecords.AnimationSpeed = 200
        Me.btnRecords.AutoGenerateColors = False
        Me.btnRecords.AutoRoundBorders = False
        Me.btnRecords.AutoSizeLeftIcon = True
        Me.btnRecords.AutoSizeRightIcon = True
        Me.btnRecords.BackColor = System.Drawing.Color.Transparent
        Me.btnRecords.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnRecords.BackgroundImage = CType(resources.GetObject("btnRecords.BackgroundImage"), System.Drawing.Image)
        Me.btnRecords.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnRecords.ButtonText = "Records"
        Me.btnRecords.ButtonTextMarginLeft = 0
        Me.btnRecords.ColorContrastOnClick = 45
        Me.btnRecords.ColorContrastOnHover = 45
        Me.btnRecords.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges9.BottomLeft = True
        BorderEdges9.BottomRight = True
        BorderEdges9.TopLeft = True
        BorderEdges9.TopRight = True
        Me.btnRecords.CustomizableEdges = BorderEdges9
        Me.btnRecords.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnRecords.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnRecords.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnRecords.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnRecords.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnRecords.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnRecords.ForeColor = System.Drawing.Color.White
        Me.btnRecords.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRecords.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnRecords.IconLeftPadding = New System.Windows.Forms.Padding(25, 3, 3, 3)
        Me.btnRecords.IconMarginLeft = 11
        Me.btnRecords.IconPadding = 10
        Me.btnRecords.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnRecords.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnRecords.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnRecords.IconSize = 25
        Me.btnRecords.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnRecords.IdleBorderRadius = 1
        Me.btnRecords.IdleBorderThickness = 1
        Me.btnRecords.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnRecords.IdleIconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_database_32__1_
        Me.btnRecords.IdleIconRightImage = Nothing
        Me.btnRecords.IndicateFocus = False
        Me.btnRecords.Location = New System.Drawing.Point(0, 132)
        Me.btnRecords.Name = "btnRecords"
        Me.btnRecords.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnRecords.OnDisabledState.BorderRadius = 1
        Me.btnRecords.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnRecords.OnDisabledState.BorderThickness = 1
        Me.btnRecords.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnRecords.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnRecords.OnDisabledState.IconLeftImage = Nothing
        Me.btnRecords.OnDisabledState.IconRightImage = Nothing
        Me.btnRecords.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnRecords.onHoverState.BorderRadius = 1
        Me.btnRecords.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnRecords.onHoverState.BorderThickness = 1
        Me.btnRecords.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnRecords.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnRecords.onHoverState.IconLeftImage = Nothing
        Me.btnRecords.onHoverState.IconRightImage = Nothing
        Me.btnRecords.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnRecords.OnIdleState.BorderRadius = 1
        Me.btnRecords.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnRecords.OnIdleState.BorderThickness = 1
        Me.btnRecords.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnRecords.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnRecords.OnIdleState.IconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_database_32__1_
        Me.btnRecords.OnIdleState.IconRightImage = Nothing
        Me.btnRecords.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnRecords.OnPressedState.BorderRadius = 1
        Me.btnRecords.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnRecords.OnPressedState.BorderThickness = 1
        Me.btnRecords.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnRecords.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnRecords.OnPressedState.IconLeftImage = Nothing
        Me.btnRecords.OnPressedState.IconRightImage = Nothing
        Me.btnRecords.Size = New System.Drawing.Size(240, 44)
        Me.btnRecords.TabIndex = 6
        Me.btnRecords.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnRecords.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnRecords.TextMarginLeft = 0
        Me.btnRecords.TextPadding = New System.Windows.Forms.Padding(-9, 0, 0, 0)
        Me.btnRecords.UseDefaultRadiusAndThickness = True
        '
        'btnViolation
        '
        Me.btnViolation.AllowAnimations = True
        Me.btnViolation.AllowMouseEffects = True
        Me.btnViolation.AllowToggling = False
        Me.btnViolation.AnimationSpeed = 200
        Me.btnViolation.AutoGenerateColors = False
        Me.btnViolation.AutoRoundBorders = False
        Me.btnViolation.AutoSizeLeftIcon = True
        Me.btnViolation.AutoSizeRightIcon = True
        Me.btnViolation.BackColor = System.Drawing.Color.Transparent
        Me.btnViolation.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnViolation.BackgroundImage = CType(resources.GetObject("btnViolation.BackgroundImage"), System.Drawing.Image)
        Me.btnViolation.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnViolation.ButtonText = "Violation Entry"
        Me.btnViolation.ButtonTextMarginLeft = 0
        Me.btnViolation.ColorContrastOnClick = 45
        Me.btnViolation.ColorContrastOnHover = 45
        Me.btnViolation.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges10.BottomLeft = True
        BorderEdges10.BottomRight = True
        BorderEdges10.TopLeft = True
        BorderEdges10.TopRight = True
        Me.btnViolation.CustomizableEdges = BorderEdges10
        Me.btnViolation.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnViolation.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnViolation.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnViolation.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnViolation.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnViolation.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnViolation.ForeColor = System.Drawing.Color.White
        Me.btnViolation.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnViolation.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnViolation.IconLeftPadding = New System.Windows.Forms.Padding(25, 3, 3, 3)
        Me.btnViolation.IconMarginLeft = 11
        Me.btnViolation.IconPadding = 10
        Me.btnViolation.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnViolation.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnViolation.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnViolation.IconSize = 25
        Me.btnViolation.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnViolation.IdleBorderRadius = 1
        Me.btnViolation.IdleBorderThickness = 1
        Me.btnViolation.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnViolation.IdleIconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_book_32__1_
        Me.btnViolation.IdleIconRightImage = Nothing
        Me.btnViolation.IndicateFocus = False
        Me.btnViolation.Location = New System.Drawing.Point(0, 88)
        Me.btnViolation.Name = "btnViolation"
        Me.btnViolation.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnViolation.OnDisabledState.BorderRadius = 1
        Me.btnViolation.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnViolation.OnDisabledState.BorderThickness = 1
        Me.btnViolation.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnViolation.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnViolation.OnDisabledState.IconLeftImage = Nothing
        Me.btnViolation.OnDisabledState.IconRightImage = Nothing
        Me.btnViolation.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnViolation.onHoverState.BorderRadius = 1
        Me.btnViolation.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnViolation.onHoverState.BorderThickness = 1
        Me.btnViolation.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnViolation.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnViolation.onHoverState.IconLeftImage = Nothing
        Me.btnViolation.onHoverState.IconRightImage = Nothing
        Me.btnViolation.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnViolation.OnIdleState.BorderRadius = 1
        Me.btnViolation.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnViolation.OnIdleState.BorderThickness = 1
        Me.btnViolation.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnViolation.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnViolation.OnIdleState.IconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_book_32__1_
        Me.btnViolation.OnIdleState.IconRightImage = Nothing
        Me.btnViolation.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnViolation.OnPressedState.BorderRadius = 1
        Me.btnViolation.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnViolation.OnPressedState.BorderThickness = 1
        Me.btnViolation.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnViolation.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnViolation.OnPressedState.IconLeftImage = Nothing
        Me.btnViolation.OnPressedState.IconRightImage = Nothing
        Me.btnViolation.Size = New System.Drawing.Size(240, 44)
        Me.btnViolation.TabIndex = 5
        Me.btnViolation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnViolation.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnViolation.TextMarginLeft = 0
        Me.btnViolation.TextPadding = New System.Windows.Forms.Padding(26, 0, 0, 0)
        Me.btnViolation.UseDefaultRadiusAndThickness = True
        '
        'btnStudent
        '
        Me.btnStudent.AllowAnimations = True
        Me.btnStudent.AllowMouseEffects = True
        Me.btnStudent.AllowToggling = False
        Me.btnStudent.AnimationSpeed = 200
        Me.btnStudent.AutoGenerateColors = False
        Me.btnStudent.AutoRoundBorders = False
        Me.btnStudent.AutoSizeLeftIcon = True
        Me.btnStudent.AutoSizeRightIcon = True
        Me.btnStudent.BackColor = System.Drawing.Color.Transparent
        Me.btnStudent.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnStudent.BackgroundImage = CType(resources.GetObject("btnStudent.BackgroundImage"), System.Drawing.Image)
        Me.btnStudent.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnStudent.ButtonText = "Student Entry"
        Me.btnStudent.ButtonTextMarginLeft = 0
        Me.btnStudent.ColorContrastOnClick = 45
        Me.btnStudent.ColorContrastOnHover = 45
        Me.btnStudent.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges11.BottomLeft = True
        BorderEdges11.BottomRight = True
        BorderEdges11.TopLeft = True
        BorderEdges11.TopRight = True
        Me.btnStudent.CustomizableEdges = BorderEdges11
        Me.btnStudent.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnStudent.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnStudent.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnStudent.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnStudent.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnStudent.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnStudent.ForeColor = System.Drawing.Color.White
        Me.btnStudent.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnStudent.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnStudent.IconLeftPadding = New System.Windows.Forms.Padding(25, 3, 3, 3)
        Me.btnStudent.IconMarginLeft = 11
        Me.btnStudent.IconPadding = 10
        Me.btnStudent.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnStudent.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnStudent.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnStudent.IconSize = 25
        Me.btnStudent.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnStudent.IdleBorderRadius = 1
        Me.btnStudent.IdleBorderThickness = 1
        Me.btnStudent.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnStudent.IdleIconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_student_32__1_
        Me.btnStudent.IdleIconRightImage = Nothing
        Me.btnStudent.IndicateFocus = False
        Me.btnStudent.Location = New System.Drawing.Point(0, 44)
        Me.btnStudent.Name = "btnStudent"
        Me.btnStudent.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnStudent.OnDisabledState.BorderRadius = 1
        Me.btnStudent.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnStudent.OnDisabledState.BorderThickness = 1
        Me.btnStudent.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnStudent.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnStudent.OnDisabledState.IconLeftImage = Nothing
        Me.btnStudent.OnDisabledState.IconRightImage = Nothing
        Me.btnStudent.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnStudent.onHoverState.BorderRadius = 1
        Me.btnStudent.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnStudent.onHoverState.BorderThickness = 1
        Me.btnStudent.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnStudent.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnStudent.onHoverState.IconLeftImage = Nothing
        Me.btnStudent.onHoverState.IconRightImage = Nothing
        Me.btnStudent.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnStudent.OnIdleState.BorderRadius = 1
        Me.btnStudent.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnStudent.OnIdleState.BorderThickness = 1
        Me.btnStudent.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnStudent.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnStudent.OnIdleState.IconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_student_32__1_
        Me.btnStudent.OnIdleState.IconRightImage = Nothing
        Me.btnStudent.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnStudent.OnPressedState.BorderRadius = 1
        Me.btnStudent.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnStudent.OnPressedState.BorderThickness = 1
        Me.btnStudent.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnStudent.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnStudent.OnPressedState.IconLeftImage = Nothing
        Me.btnStudent.OnPressedState.IconRightImage = Nothing
        Me.btnStudent.Size = New System.Drawing.Size(240, 44)
        Me.btnStudent.TabIndex = 4
        Me.btnStudent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnStudent.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnStudent.TextMarginLeft = 0
        Me.btnStudent.TextPadding = New System.Windows.Forms.Padding(17, 0, 0, 0)
        Me.btnStudent.UseDefaultRadiusAndThickness = True
        '
        'btnDashboard
        '
        Me.btnDashboard.AllowAnimations = True
        Me.btnDashboard.AllowMouseEffects = True
        Me.btnDashboard.AllowToggling = False
        Me.btnDashboard.AnimationSpeed = 200
        Me.btnDashboard.AutoGenerateColors = False
        Me.btnDashboard.AutoRoundBorders = False
        Me.btnDashboard.AutoSizeLeftIcon = True
        Me.btnDashboard.AutoSizeRightIcon = True
        Me.btnDashboard.BackColor = System.Drawing.Color.Transparent
        Me.btnDashboard.BackColor1 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnDashboard.BackgroundImage = CType(resources.GetObject("btnDashboard.BackgroundImage"), System.Drawing.Image)
        Me.btnDashboard.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnDashboard.ButtonText = "Dashboard"
        Me.btnDashboard.ButtonTextMarginLeft = 0
        Me.btnDashboard.ColorContrastOnClick = 45
        Me.btnDashboard.ColorContrastOnHover = 45
        Me.btnDashboard.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges12.BottomLeft = True
        BorderEdges12.BottomRight = True
        BorderEdges12.TopLeft = True
        BorderEdges12.TopRight = True
        Me.btnDashboard.CustomizableEdges = BorderEdges12
        Me.btnDashboard.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnDashboard.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDashboard.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDashboard.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnDashboard.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnDashboard.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnDashboard.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnDashboard.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDashboard.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnDashboard.IconLeftPadding = New System.Windows.Forms.Padding(25, 3, 3, 3)
        Me.btnDashboard.IconMarginLeft = 11
        Me.btnDashboard.IconPadding = 10
        Me.btnDashboard.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnDashboard.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnDashboard.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnDashboard.IconSize = 25
        Me.btnDashboard.IdleBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnDashboard.IdleBorderRadius = 1
        Me.btnDashboard.IdleBorderThickness = 1
        Me.btnDashboard.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnDashboard.IdleIconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.dashboard__2_
        Me.btnDashboard.IdleIconRightImage = Nothing
        Me.btnDashboard.IndicateFocus = False
        Me.btnDashboard.Location = New System.Drawing.Point(0, 0)
        Me.btnDashboard.Name = "btnDashboard"
        Me.btnDashboard.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDashboard.OnDisabledState.BorderRadius = 1
        Me.btnDashboard.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnDashboard.OnDisabledState.BorderThickness = 1
        Me.btnDashboard.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnDashboard.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnDashboard.OnDisabledState.IconLeftImage = Nothing
        Me.btnDashboard.OnDisabledState.IconRightImage = Nothing
        Me.btnDashboard.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnDashboard.onHoverState.BorderRadius = 1
        Me.btnDashboard.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnDashboard.onHoverState.BorderThickness = 1
        Me.btnDashboard.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnDashboard.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnDashboard.onHoverState.IconLeftImage = Nothing
        Me.btnDashboard.onHoverState.IconRightImage = Nothing
        Me.btnDashboard.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnDashboard.OnIdleState.BorderRadius = 1
        Me.btnDashboard.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnDashboard.OnIdleState.BorderThickness = 1
        Me.btnDashboard.OnIdleState.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnDashboard.OnIdleState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnDashboard.OnIdleState.IconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.dashboard__2_
        Me.btnDashboard.OnIdleState.IconRightImage = Nothing
        Me.btnDashboard.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnDashboard.OnPressedState.BorderRadius = 1
        Me.btnDashboard.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnDashboard.OnPressedState.BorderThickness = 1
        Me.btnDashboard.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnDashboard.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnDashboard.OnPressedState.IconLeftImage = Nothing
        Me.btnDashboard.OnPressedState.IconRightImage = Nothing
        Me.btnDashboard.Size = New System.Drawing.Size(240, 44)
        Me.btnDashboard.TabIndex = 3
        Me.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnDashboard.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnDashboard.TextMarginLeft = 0
        Me.btnDashboard.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnDashboard.UseDefaultRadiusAndThickness = True
        '
        'btnLogout
        '
        Me.btnLogout.AllowAnimations = True
        Me.btnLogout.AllowMouseEffects = True
        Me.btnLogout.AllowToggling = False
        Me.btnLogout.AnimationSpeed = 200
        Me.btnLogout.AutoGenerateColors = False
        Me.btnLogout.AutoRoundBorders = False
        Me.btnLogout.AutoSizeLeftIcon = True
        Me.btnLogout.AutoSizeRightIcon = True
        Me.btnLogout.BackColor = System.Drawing.Color.Transparent
        Me.btnLogout.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnLogout.BackgroundImage = CType(resources.GetObject("btnLogout.BackgroundImage"), System.Drawing.Image)
        Me.btnLogout.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogout.ButtonText = "Logout"
        Me.btnLogout.ButtonTextMarginLeft = 0
        Me.btnLogout.ColorContrastOnClick = 45
        Me.btnLogout.ColorContrastOnHover = 45
        Me.btnLogout.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges13.BottomLeft = True
        BorderEdges13.BottomRight = True
        BorderEdges13.TopLeft = True
        BorderEdges13.TopRight = True
        Me.btnLogout.CustomizableEdges = BorderEdges13
        Me.btnLogout.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnLogout.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnLogout.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnLogout.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnLogout.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnLogout.Font = New System.Drawing.Font("Cascadia Code SemiBold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogout.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnLogout.IconLeftPadding = New System.Windows.Forms.Padding(25, 3, 3, 3)
        Me.btnLogout.IconMarginLeft = 11
        Me.btnLogout.IconPadding = 10
        Me.btnLogout.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnLogout.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnLogout.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnLogout.IconSize = 25
        Me.btnLogout.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnLogout.IdleBorderRadius = 1
        Me.btnLogout.IdleBorderThickness = 1
        Me.btnLogout.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnLogout.IdleIconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_logout_25
        Me.btnLogout.IdleIconRightImage = Nothing
        Me.btnLogout.IndicateFocus = False
        Me.btnLogout.Location = New System.Drawing.Point(0, 595)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnLogout.OnDisabledState.BorderRadius = 1
        Me.btnLogout.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogout.OnDisabledState.BorderThickness = 1
        Me.btnLogout.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnLogout.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnLogout.OnDisabledState.IconLeftImage = Nothing
        Me.btnLogout.OnDisabledState.IconRightImage = Nothing
        Me.btnLogout.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnLogout.onHoverState.BorderRadius = 1
        Me.btnLogout.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogout.onHoverState.BorderThickness = 1
        Me.btnLogout.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLogout.onHoverState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(163, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.btnLogout.onHoverState.IconLeftImage = Nothing
        Me.btnLogout.onHoverState.IconRightImage = Nothing
        Me.btnLogout.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnLogout.OnIdleState.BorderRadius = 1
        Me.btnLogout.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogout.OnIdleState.BorderThickness = 1
        Me.btnLogout.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnLogout.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnLogout.OnIdleState.IconLeftImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_logout_25
        Me.btnLogout.OnIdleState.IconRightImage = Nothing
        Me.btnLogout.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLogout.OnPressedState.BorderRadius = 1
        Me.btnLogout.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogout.OnPressedState.BorderThickness = 1
        Me.btnLogout.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLogout.OnPressedState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLogout.OnPressedState.IconLeftImage = Nothing
        Me.btnLogout.OnPressedState.IconRightImage = Nothing
        Me.btnLogout.Size = New System.Drawing.Size(240, 44)
        Me.btnLogout.TabIndex = 11
        Me.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnLogout.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnLogout.TextMarginLeft = 0
        Me.btnLogout.TextPadding = New System.Windows.Forms.Padding(-12, 0, 0, 0)
        Me.btnLogout.UseDefaultRadiusAndThickness = True
        '
        'ElipseFrmMain
        '
        Me.ElipseFrmMain.ElipseRadius = 23
        Me.ElipseFrmMain.TargetControl = Me
        '
        'SnbInformation
        '
        Me.SnbInformation.AllowDragging = False
        Me.SnbInformation.AllowMultipleViews = True
        Me.SnbInformation.ClickToClose = True
        Me.SnbInformation.DoubleClickToClose = True
        Me.SnbInformation.DurationAfterIdle = 3000
        Me.SnbInformation.ErrorOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SnbInformation.ErrorOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SnbInformation.ErrorOptions.ActionBorderRadius = 1
        Me.SnbInformation.ErrorOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.SnbInformation.ErrorOptions.ActionForeColor = System.Drawing.Color.Black
        Me.SnbInformation.ErrorOptions.BackColor = System.Drawing.Color.White
        Me.SnbInformation.ErrorOptions.BorderColor = System.Drawing.Color.White
        Me.SnbInformation.ErrorOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.SnbInformation.ErrorOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.SnbInformation.ErrorOptions.ForeColor = System.Drawing.Color.Black
        Me.SnbInformation.ErrorOptions.Icon = CType(resources.GetObject("resource.Icon"), System.Drawing.Image)
        Me.SnbInformation.ErrorOptions.IconLeftMargin = 12
        Me.SnbInformation.FadeCloseIcon = False
        Me.SnbInformation.Host = Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner
        Me.SnbInformation.InformationOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SnbInformation.InformationOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SnbInformation.InformationOptions.ActionBorderRadius = 1
        Me.SnbInformation.InformationOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.SnbInformation.InformationOptions.ActionForeColor = System.Drawing.Color.Black
        Me.SnbInformation.InformationOptions.BackColor = System.Drawing.Color.White
        Me.SnbInformation.InformationOptions.BorderColor = System.Drawing.Color.White
        Me.SnbInformation.InformationOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(213, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SnbInformation.InformationOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.SnbInformation.InformationOptions.ForeColor = System.Drawing.Color.Black
        Me.SnbInformation.InformationOptions.Icon = CType(resources.GetObject("resource.Icon1"), System.Drawing.Image)
        Me.SnbInformation.InformationOptions.IconLeftMargin = 12
        Me.SnbInformation.Margin = 10
        Me.SnbInformation.MaximumSize = New System.Drawing.Size(0, 0)
        Me.SnbInformation.MaximumViews = 7
        Me.SnbInformation.MessageRightMargin = 15
        Me.SnbInformation.MinimumSize = New System.Drawing.Size(0, 0)
        Me.SnbInformation.ShowBorders = False
        Me.SnbInformation.ShowCloseIcon = True
        Me.SnbInformation.ShowIcon = True
        Me.SnbInformation.ShowShadows = True
        Me.SnbInformation.SuccessOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SnbInformation.SuccessOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SnbInformation.SuccessOptions.ActionBorderRadius = 1
        Me.SnbInformation.SuccessOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.SnbInformation.SuccessOptions.ActionForeColor = System.Drawing.Color.Black
        Me.SnbInformation.SuccessOptions.BackColor = System.Drawing.Color.White
        Me.SnbInformation.SuccessOptions.BorderColor = System.Drawing.Color.White
        Me.SnbInformation.SuccessOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.SnbInformation.SuccessOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.SnbInformation.SuccessOptions.ForeColor = System.Drawing.Color.Black
        Me.SnbInformation.SuccessOptions.Icon = CType(resources.GetObject("resource.Icon2"), System.Drawing.Image)
        Me.SnbInformation.SuccessOptions.IconLeftMargin = 12
        Me.SnbInformation.ViewsMargin = 7
        Me.SnbInformation.WarningOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SnbInformation.WarningOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SnbInformation.WarningOptions.ActionBorderRadius = 1
        Me.SnbInformation.WarningOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.SnbInformation.WarningOptions.ActionForeColor = System.Drawing.Color.Black
        Me.SnbInformation.WarningOptions.BackColor = System.Drawing.Color.White
        Me.SnbInformation.WarningOptions.BorderColor = System.Drawing.Color.White
        Me.SnbInformation.WarningOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.SnbInformation.WarningOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.SnbInformation.WarningOptions.ForeColor = System.Drawing.Color.Black
        Me.SnbInformation.WarningOptions.Icon = CType(resources.GetObject("resource.Icon3"), System.Drawing.Image)
        Me.SnbInformation.WarningOptions.IconLeftMargin = 12
        Me.SnbInformation.ZoomCloseIcon = True
        '
        'DataGridViewImageColumn1
        '
        Me.DataGridViewImageColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn1.HeaderText = ""
        Me.DataGridViewImageColumn1.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.edit__1_
        Me.DataGridViewImageColumn1.Name = "DataGridViewImageColumn1"
        Me.DataGridViewImageColumn1.ReadOnly = True
        '
        'DataGridViewImageColumn2
        '
        Me.DataGridViewImageColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn2.HeaderText = ""
        Me.DataGridViewImageColumn2.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.delete
        Me.DataGridViewImageColumn2.Name = "DataGridViewImageColumn2"
        Me.DataGridViewImageColumn2.ReadOnly = True
        '
        'DataGridViewImageColumn3
        '
        Me.DataGridViewImageColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn3.HeaderText = ""
        Me.DataGridViewImageColumn3.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.edit__1_
        Me.DataGridViewImageColumn3.Name = "DataGridViewImageColumn3"
        Me.DataGridViewImageColumn3.ReadOnly = True
        '
        'DataGridViewImageColumn4
        '
        Me.DataGridViewImageColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn4.HeaderText = ""
        Me.DataGridViewImageColumn4.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.delete
        Me.DataGridViewImageColumn4.Name = "DataGridViewImageColumn4"
        Me.DataGridViewImageColumn4.ReadOnly = True
        '
        'DataGridViewImageColumn5
        '
        Me.DataGridViewImageColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn5.HeaderText = ""
        Me.DataGridViewImageColumn5.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.edit__1_
        Me.DataGridViewImageColumn5.Name = "DataGridViewImageColumn5"
        Me.DataGridViewImageColumn5.ReadOnly = True
        '
        'DataGridViewImageColumn6
        '
        Me.DataGridViewImageColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn6.HeaderText = ""
        Me.DataGridViewImageColumn6.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.delete
        Me.DataGridViewImageColumn6.Name = "DataGridViewImageColumn6"
        Me.DataGridViewImageColumn6.ReadOnly = True
        '
        'DataGridViewImageColumn7
        '
        Me.DataGridViewImageColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn7.HeaderText = ""
        Me.DataGridViewImageColumn7.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.open_folder
        Me.DataGridViewImageColumn7.Name = "DataGridViewImageColumn7"
        Me.DataGridViewImageColumn7.ReadOnly = True
        '
        'DataGridViewImageColumn8
        '
        Me.DataGridViewImageColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn8.HeaderText = ""
        Me.DataGridViewImageColumn8.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.lock
        Me.DataGridViewImageColumn8.Name = "DataGridViewImageColumn8"
        Me.DataGridViewImageColumn8.ReadOnly = True
        '
        'DataGridViewImageColumn9
        '
        Me.DataGridViewImageColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewImageColumn9.HeaderText = ""
        Me.DataGridViewImageColumn9.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.lock
        Me.DataGridViewImageColumn9.Name = "DataGridViewImageColumn9"
        Me.DataGridViewImageColumn9.ReadOnly = True
        '
        'Column9
        '
        Me.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column9.HeaderText = "id"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        Me.Column9.Width = 47
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn2.HeaderText = "STUDENT NO"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 130
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn3.HeaderText = "NAME"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 79
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column1.HeaderText = "SECTION"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 98
        '
        'Column2
        '
        Me.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column2.HeaderText = "A.Y. CODE"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 104
        '
        'Column3
        '
        Me.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column3.HeaderText = "VIOLATION"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column7.HeaderText = "SANCTION"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Width = 113
        '
        'Column4
        '
        Me.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column4.HeaderText = "TYPE"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 68
        '
        'Column5
        '
        Me.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column5.HeaderText = "USER"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 71
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1600, 850)
        Me.ControlBox = False
        Me.Controls.Add(Me.fpnlSidebar)
        Me.Controls.Add(Me.pnlMainPage)
        Me.Controls.Add(Me.pnlTopBar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MainForm"
        Me.pnlTopBar.ResumeLayout(False)
        CType(Me.pcbMinimize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlMainPage.ResumeLayout(False)
        Me.pages.ResumeLayout(False)
        Me.tabDashboard.ResumeLayout(False)
        Me.tabDashboard.PerformLayout()
        Me.BunifuPanel4.ResumeLayout(False)
        Me.BunifuPanel4.PerformLayout()
        Me.BunifuPanel7.ResumeLayout(False)
        Me.BunifuPanel7.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuPanel5.ResumeLayout(False)
        Me.BunifuPanel5.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuPanel6.ResumeLayout(False)
        Me.BunifuPanel6.PerformLayout()
        Me.tabStudent.ResumeLayout(False)
        Me.tabStudent.PerformLayout()
        CType(Me.dgvStudent, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabViolation.ResumeLayout(False)
        Me.tabViolation.PerformLayout()
        Me.BunifuPanel1.ResumeLayout(False)
        Me.BunifuPanel1.PerformLayout()
        Me.pnlPersonalInfo.ResumeLayout(False)
        Me.pnlPersonalInfo.PerformLayout()
        CType(Me.dgvViolation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabRecords.ResumeLayout(False)
        Me.tabRecords.PerformLayout()
        CType(Me.dgvDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvRecords1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabProgram.ResumeLayout(False)
        Me.tabProgram.PerformLayout()
        CType(Me.dgvProgram, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabSection.ResumeLayout(False)
        Me.tabSection.PerformLayout()
        CType(Me.dgvSection, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabAcademic.ResumeLayout(False)
        Me.tabAcademic.PerformLayout()
        CType(Me.dgvAY, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabUserAcc.ResumeLayout(False)
        Me.tabUserAcc.PerformLayout()
        Me.BunifuPanel3.ResumeLayout(False)
        Me.BunifuPanel3.PerformLayout()
        Me.BunifuPanel2.ResumeLayout(False)
        Me.BunifuPanel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.fpnlSidebar.ResumeLayout(False)
        Me.pnlButtons.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlTopBar As Panel
    Friend WithEvents pnlMainPage As Panel
    Friend WithEvents pcbMinimize As PictureBox
    Friend WithEvents pcbClose As PictureBox
    Friend WithEvents pages As Bunifu.UI.WinForms.BunifuPages
    Friend WithEvents tabDashboard As TabPage
    Friend WithEvents tabStudent As TabPage
    Friend WithEvents tabViolation As TabPage
    Friend WithEvents tabRecords As TabPage
    Friend WithEvents tabProgram As TabPage
    Friend WithEvents linkLblAddNew As LinkLabel
    Friend WithEvents dgvProgram As Bunifu.UI.WinForms.BunifuDataGridView
    Friend WithEvents tabSection As TabPage
    Friend WithEvents tabAcademic As TabPage
    Friend WithEvents tabUserAcc As TabPage
    Friend WithEvents Panel1 As Panel
    Friend WithEvents lblCurrentUser As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents fpnlSidebar As FlowLayoutPanel
    Friend WithEvents pnlButtons As Panel
    Friend WithEvents btnUserAccount As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents btnAcademic As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents btnSection As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents btnProgram As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents btnRecords As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents btnViolation As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents btnStudent As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents btnDashboard As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents DataGridViewImageColumn1 As DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn2 As DataGridViewImageColumn
    Friend WithEvents dgvViolation As Bunifu.UI.WinForms.BunifuDataGridView
    Friend WithEvents btnLogout As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents colNumbering As DataGridViewTextBoxColumn
    Friend WithEvents PCODE As DataGridViewTextBoxColumn
    Friend WithEvents colDescription As DataGridViewTextBoxColumn
    Friend WithEvents cboType As DataGridViewTextBoxColumn
    Friend WithEvents colEdit As DataGridViewImageColumn
    Friend WithEvents colDelete As DataGridViewImageColumn
    Friend WithEvents dgvSection As Bunifu.UI.WinForms.BunifuDataGridView
    Friend WithEvents lblAddsection As LinkLabel
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents colSectionID As DataGridViewTextBoxColumn
    Friend WithEvents colSection As DataGridViewTextBoxColumn
    Friend WithEvents colPcode As DataGridViewTextBoxColumn
    Friend WithEvents colEditSection As DataGridViewImageColumn
    Friend WithEvents colDeleteSection As DataGridViewImageColumn
    Friend WithEvents dgvStudent As Bunifu.UI.WinForms.BunifuDataGridView
    Friend WithEvents lblTitle As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel1 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel2 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents lblAddStudent As LinkLabel
    Friend WithEvents DataGridViewImageColumn3 As DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn4 As DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents colEditStudent As DataGridViewImageColumn
    Friend WithEvents colDeleteStudent As DataGridViewImageColumn
    Friend WithEvents ElipseFrmMain As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents llblAYList As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents lblAddAY As LinkLabel
    Friend WithEvents dgvAY As Bunifu.UI.WinForms.BunifuDataGridView
    Friend WithEvents DataGridViewImageColumn5 As DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn6 As DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn7 As DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn8 As DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents colOpen As DataGridViewImageColumn
    Friend WithEvents colClose As DataGridViewImageColumn
    Friend WithEvents BunifuLabel3 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents pnlPersonalInfo As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents txtProgram As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel4 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel5 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents lblPersonalInfo As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtName As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents txtSno As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel6 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel7 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtSection As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuPanel1 As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents BunifuLabel9 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel10 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel11 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtViolation As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents txtAY As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel12 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents cboTypeV As Bunifu.UI.WinForms.BunifuDropdown
    Public WithEvents btnCancel As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Public WithEvents btnSave As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents txtSearch As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents txtSanction As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel8 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents cboAYCode As Bunifu.UI.WinForms.BunifuDropdown
    Friend WithEvents BunifuLabel14 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel13 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents dgvRecords1 As Bunifu.UI.WinForms.BunifuDataGridView
    Friend WithEvents dgvDisplay As Bunifu.UI.WinForms.BunifuDataGridView
    Friend WithEvents DataGridViewTextBoxColumn26 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn30 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn31 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn32 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn33 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn34 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn28 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn29 As DataGridViewTextBoxColumn
    Friend WithEvents colDisplay As DataGridViewImageColumn
    Friend WithEvents BunifuLabel15 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents DataGridViewImageColumn9 As DataGridViewImageColumn
    Public WithEvents btnSaveUA As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents BunifuLabel16 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtNameUA As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents txtConfirmPass As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents txtPassword As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents txtUsername As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents lblSystemTitle As Label
    Friend WithEvents BunifuLabel21 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel20 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel19 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel18 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel17 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents pnlIndicator As Bunifu.UI.WinForms.BunifuUserControl
    Friend WithEvents BunifuPanel2 As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents BunifuPanel3 As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents BunifuLabel22 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel23 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel24 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtCPUsername As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel25 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtCPOldPass As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel26 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtCPNewPass As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel27 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtCPConfirmPass As Bunifu.UI.WinForms.BunifuTextBox
    Public WithEvents btnUpdate As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents SnbInformation As Bunifu.UI.WinForms.BunifuSnackbar
    Friend WithEvents BunifuPanel4 As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents BunifuPanel7 As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents lblViolation As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel32 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuPanel5 As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents lblStudent As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel31 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuPanel6 As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents lblAY As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel29 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel30 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel28 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
End Class
