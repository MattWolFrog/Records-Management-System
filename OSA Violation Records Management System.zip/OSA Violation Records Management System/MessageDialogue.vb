﻿Public Class frmMessageDialogue

    Private Sub pcbClose_Click(sender As Object, e As EventArgs) Handles pcbClose.Click
        Dim customMessageBox As New frmMessageDialogue("Exit Application", "Do you want to exit?", "Yes", "No")
        customMessageBox.ShowDialog()

        If customMessageBox.UserChoice = DialogResult.Yes Then
            Application.ExitThread()
        End If
    End Sub

    Private Sub pcbMinimize_Click(sender As Object, e As EventArgs) Handles pcbMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Public Property UserChoice As DialogResult = DialogResult.None

    Private Sub btnYes_Click(sender As Object, e As EventArgs) Handles btnYes.Click
        UserChoice = DialogResult.Yes
        Me.Close()
    End Sub

    Private Sub btnNo_Click(sender As Object, e As EventArgs) Handles btnNo.Click
        UserChoice = DialogResult.No
        Me.Close()
    End Sub

    Public Sub New(titleText As String, questionText As String, yesButtonText As String, noButtonText As String)
        ' This call is required by the designer.
        InitializeComponent()
        ' Initialize and modify controls
        lblTitle.Text = titleText
        lblQuestion.Text = questionText
        btnYes.Text = yesButtonText
        btnNo.Text = noButtonText

        ' Center lblQuestion vertically within the form
        lblQuestion.Top = (Me.ClientSize.Width - lblQuestion.Width) / 2
    End Sub

    Private Sub pnlTopBar_Paint(sender As Object, e As PaintEventArgs) Handles pnlTopBar.Paint

    End Sub
End Class