﻿Imports System.Data.OleDb
Imports System.Reflection.Emit

Public Class frmSection

    Sub LoadPcode()
        cboPcode.Items.Clear()
        cn.Open()
        cm = New OleDbCommand("select * from tblProgram", cn)
        dr = cm.ExecuteReader
        While dr.Read
            cboPcode.Items.Add(dr.Item("pcode").ToString)
        End While
        dr.Close()
        cn.Close()
    End Sub

    Private Sub pcbClose_Click(sender As Object, e As EventArgs) Handles pcbClose.Click
        Dim customMessageBox As New frmMessageDialogue("Exit Section Details", "Do you want to exit?", "Yes", "No")
        customMessageBox.ShowDialog()

        If customMessageBox.UserChoice = DialogResult.Yes Then
            Me.Dispose()
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            ' Check if textboxes and combobox are empty
            If String.IsNullOrEmpty(txtSection.Text) OrElse
           String.IsNullOrEmpty(cboPcode.Text) Then
                snbInformation.Show(Me,
            "Please fill in all fields before saving.",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return ' Exit the subroutine if any field is empty
            End If

            Dim customMessageBox As New frmMessageDialogue("Save", "Save record?", "Yes", "No")
            customMessageBox.ShowDialog()

            If customMessageBox.UserChoice = DialogResult.Yes Then
                cn.Open()
                cm = New OleDbCommand("INSERT INTO tblSection (sectionname, pcode) VALUES (@sectionname, @pcode)", cn)
                With cm
                    .Parameters.AddWithValue("@sectionname", txtSection.Text)
                    .Parameters.AddWithValue("@pcode", cboPcode.Text)
                    .ExecuteNonQuery()
                End With
                cn.Close()
                snbInformation.Show(Me,
            "Record has been successfully saved",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Clear()
                With frmMain
                    .LoadRecordsSection()
                End With
            End If
        Catch ex As Exception
            cn.Close()
            snbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)

        End Try
    End Sub

    Sub Clear()
        txtSection.Clear()
        btnSave.Enabled = True
        btnUpdate.Enabled = False
        cboPcode.SelectedIndex = -1
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            ' Check if textboxes and combobox are empty
            If String.IsNullOrEmpty(txtSection.Text) OrElse
           String.IsNullOrEmpty(cboPcode.Text) Then
                snbInformation.Show(Me,
            "Please fill in all fields before saving.",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return ' Exit the subroutine if any field is empty
            End If

            Dim customMessageBox As New frmMessageDialogue("Update", "Update record?", "Yes", "No")
            customMessageBox.ShowDialog()

            If customMessageBox.UserChoice = DialogResult.Yes Then
                cn.Open()
                cm = New OleDbCommand("update tblsection set sectionname = @sectionname, pcode=@pcode where sectionid = @sectionid", cn)
                With cm
                    .Parameters.AddWithValue("@sectionname", txtSection.Text)
                    .Parameters.AddWithValue("@pcode", cboPcode.Text)
                    .Parameters.AddWithValue("@sectionid", txtSectionID.Text)
                    .ExecuteNonQuery()
                End With
                cn.Close()
                snbInformation.Show(Me,
            "Record has been successfully updated",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Clear()
                With frmMain
                    .LoadRecordsSection()
                End With
                Me.Dispose()
            End If
        Catch ex As Exception
            cn.Close()
            snbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)

        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Dispose()
    End Sub

    Private Sub cboPcode_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cboPcode.KeyPress
        e.Handled = True
    End Sub
End Class