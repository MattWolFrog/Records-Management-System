﻿
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmProgram
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProgram))
        Dim BorderEdges1 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges2 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim StateProperties1 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties2 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties3 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties4 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties5 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties6 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties7 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties8 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim BorderEdges3 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Me.lblProgramDetails = New System.Windows.Forms.Label()
        Me.pnlTopBar = New System.Windows.Forms.Panel()
        Me.pcbClose = New System.Windows.Forms.PictureBox()
        Me.lblPcode = New Bunifu.UI.WinForms.BunifuLabel()
        Me.lblDescription = New Bunifu.UI.WinForms.BunifuLabel()
        Me.lblType = New Bunifu.UI.WinForms.BunifuLabel()
        Me.cboType = New Bunifu.UI.WinForms.BunifuDropdown()
        Me.btnCancel = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnUpdate = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.txtDescription = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.txtPcode = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.btnSave = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.ElipseFrmProgram = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.snbInformation = New Bunifu.UI.WinForms.BunifuSnackbar(Me.components)
        Me.pnlTopBar.SuspendLayout()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblProgramDetails
        '
        Me.lblProgramDetails.AutoSize = True
        Me.lblProgramDetails.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgramDetails.Location = New System.Drawing.Point(7, 6)
        Me.lblProgramDetails.Name = "lblProgramDetails"
        Me.lblProgramDetails.Size = New System.Drawing.Size(150, 25)
        Me.lblProgramDetails.TabIndex = 0
        Me.lblProgramDetails.Text = "Program Details"
        '
        'pnlTopBar
        '
        Me.pnlTopBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.pnlTopBar.Controls.Add(Me.pcbClose)
        Me.pnlTopBar.Controls.Add(Me.lblProgramDetails)
        Me.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTopBar.Location = New System.Drawing.Point(0, 0)
        Me.pnlTopBar.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pnlTopBar.Name = "pnlTopBar"
        Me.pnlTopBar.Size = New System.Drawing.Size(750, 37)
        Me.pnlTopBar.TabIndex = 2
        '
        'pcbClose
        '
        Me.pcbClose.BackColor = System.Drawing.Color.Transparent
        Me.pcbClose.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_close_24__1_
        Me.pcbClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pcbClose.Dock = System.Windows.Forms.DockStyle.Right
        Me.pcbClose.Location = New System.Drawing.Point(720, 0)
        Me.pcbClose.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pcbClose.Name = "pcbClose"
        Me.pcbClose.Size = New System.Drawing.Size(30, 37)
        Me.pcbClose.TabIndex = 5
        Me.pcbClose.TabStop = False
        '
        'lblPcode
        '
        Me.lblPcode.AllowParentOverrides = False
        Me.lblPcode.AutoEllipsis = False
        Me.lblPcode.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPcode.CursorType = System.Windows.Forms.Cursors.Default
        Me.lblPcode.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPcode.Location = New System.Drawing.Point(65, 97)
        Me.lblPcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblPcode.Name = "lblPcode"
        Me.lblPcode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPcode.Size = New System.Drawing.Size(101, 21)
        Me.lblPcode.TabIndex = 17
        Me.lblPcode.Text = "Program Code"
        Me.lblPcode.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblPcode.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'lblDescription
        '
        Me.lblDescription.AllowParentOverrides = False
        Me.lblDescription.AutoEllipsis = False
        Me.lblDescription.CursorType = Nothing
        Me.lblDescription.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescription.Location = New System.Drawing.Point(87, 155)
        Me.lblDescription.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDescription.Size = New System.Drawing.Size(79, 21)
        Me.lblDescription.TabIndex = 19
        Me.lblDescription.Text = "Description"
        Me.lblDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblDescription.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'lblType
        '
        Me.lblType.AllowParentOverrides = False
        Me.lblType.AutoEllipsis = False
        Me.lblType.CursorType = Nothing
        Me.lblType.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblType.Location = New System.Drawing.Point(429, 97)
        Me.lblType.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblType.Name = "lblType"
        Me.lblType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblType.Size = New System.Drawing.Size(33, 21)
        Me.lblType.TabIndex = 21
        Me.lblType.Text = "Type"
        Me.lblType.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblType.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'cboType
        '
        Me.cboType.BackColor = System.Drawing.Color.Transparent
        Me.cboType.BackgroundColor = System.Drawing.Color.White
        Me.cboType.BorderColor = System.Drawing.Color.Silver
        Me.cboType.BorderRadius = 17
        Me.cboType.Color = System.Drawing.Color.Silver
        Me.cboType.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down
        Me.cboType.DisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboType.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cboType.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboType.DisabledForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.cboType.DisabledIndicatorColor = System.Drawing.Color.DarkGray
        Me.cboType.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cboType.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin
        Me.cboType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboType.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboType.FillDropDown = True
        Me.cboType.FillIndicator = False
        Me.cboType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboType.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cboType.ForeColor = System.Drawing.Color.Black
        Me.cboType.FormattingEnabled = True
        Me.cboType.Icon = Nothing
        Me.cboType.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboType.IndicatorColor = System.Drawing.Color.Gray
        Me.cboType.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboType.ItemBackColor = System.Drawing.Color.White
        Me.cboType.ItemBorderColor = System.Drawing.Color.Transparent
        Me.cboType.ItemForeColor = System.Drawing.Color.Black
        Me.cboType.ItemHeight = 26
        Me.cboType.ItemHighLightColor = System.Drawing.Color.DodgerBlue
        Me.cboType.ItemHighLightForeColor = System.Drawing.Color.White
        Me.cboType.Items.AddRange(New Object() {"ELEMENTARY", "JHS", "SHS"})
        Me.cboType.ItemTopMargin = 3
        Me.cboType.Location = New System.Drawing.Point(482, 97)
        Me.cboType.Name = "cboType"
        Me.cboType.Size = New System.Drawing.Size(204, 32)
        Me.cboType.TabIndex = 22
        Me.cboType.Text = Nothing
        Me.cboType.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboType.TextLeftMargin = 5
        '
        'btnCancel
        '
        Me.btnCancel.AllowAnimations = True
        Me.btnCancel.AllowMouseEffects = True
        Me.btnCancel.AllowToggling = False
        Me.btnCancel.AnimationSpeed = 200
        Me.btnCancel.AutoGenerateColors = False
        Me.btnCancel.AutoRoundBorders = False
        Me.btnCancel.AutoSizeLeftIcon = True
        Me.btnCancel.AutoSizeRightIcon = True
        Me.btnCancel.BackColor = System.Drawing.Color.Transparent
        Me.btnCancel.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnCancel.BackgroundImage = CType(resources.GetObject("btnCancel.BackgroundImage"), System.Drawing.Image)
        Me.btnCancel.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.ButtonText = "Cancel"
        Me.btnCancel.ButtonTextMarginLeft = 0
        Me.btnCancel.ColorContrastOnClick = 45
        Me.btnCancel.ColorContrastOnHover = 45
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges1.BottomLeft = True
        BorderEdges1.BottomRight = True
        BorderEdges1.TopLeft = True
        BorderEdges1.TopRight = True
        Me.btnCancel.CustomizableEdges = BorderEdges1
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnCancel.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnCancel.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnCancel.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnCancel.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnCancel.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnCancel.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnCancel.IconMarginLeft = 11
        Me.btnCancel.IconPadding = 10
        Me.btnCancel.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnCancel.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnCancel.IconSize = 25
        Me.btnCancel.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnCancel.IdleBorderRadius = 18
        Me.btnCancel.IdleBorderThickness = 1
        Me.btnCancel.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnCancel.IdleIconLeftImage = Nothing
        Me.btnCancel.IdleIconRightImage = Nothing
        Me.btnCancel.IndicateFocus = False
        Me.btnCancel.Location = New System.Drawing.Point(419, 216)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnCancel.OnDisabledState.BorderRadius = 18
        Me.btnCancel.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnDisabledState.BorderThickness = 1
        Me.btnCancel.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnCancel.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnCancel.OnDisabledState.IconLeftImage = Nothing
        Me.btnCancel.OnDisabledState.IconRightImage = Nothing
        Me.btnCancel.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCancel.onHoverState.BorderRadius = 18
        Me.btnCancel.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.onHoverState.BorderThickness = 1
        Me.btnCancel.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnCancel.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.onHoverState.IconLeftImage = Nothing
        Me.btnCancel.onHoverState.IconRightImage = Nothing
        Me.btnCancel.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnCancel.OnIdleState.BorderRadius = 18
        Me.btnCancel.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnIdleState.BorderThickness = 1
        Me.btnCancel.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnCancel.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.OnIdleState.IconLeftImage = Nothing
        Me.btnCancel.OnIdleState.IconRightImage = Nothing
        Me.btnCancel.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnCancel.OnPressedState.BorderRadius = 18
        Me.btnCancel.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnPressedState.BorderThickness = 1
        Me.btnCancel.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnCancel.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.OnPressedState.IconLeftImage = Nothing
        Me.btnCancel.OnPressedState.IconRightImage = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(78, 40)
        Me.btnCancel.TabIndex = 24
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnCancel.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnCancel.TextMarginLeft = 0
        Me.btnCancel.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnCancel.UseDefaultRadiusAndThickness = True
        '
        'btnUpdate
        '
        Me.btnUpdate.AllowAnimations = True
        Me.btnUpdate.AllowMouseEffects = True
        Me.btnUpdate.AllowToggling = False
        Me.btnUpdate.AnimationSpeed = 200
        Me.btnUpdate.AutoGenerateColors = False
        Me.btnUpdate.AutoRoundBorders = False
        Me.btnUpdate.AutoSizeLeftIcon = True
        Me.btnUpdate.AutoSizeRightIcon = True
        Me.btnUpdate.BackColor = System.Drawing.Color.Transparent
        Me.btnUpdate.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.BackgroundImage = CType(resources.GetObject("btnUpdate.BackgroundImage"), System.Drawing.Image)
        Me.btnUpdate.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.ButtonText = "Update"
        Me.btnUpdate.ButtonTextMarginLeft = 0
        Me.btnUpdate.ColorContrastOnClick = 45
        Me.btnUpdate.ColorContrastOnHover = 45
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges2.BottomLeft = True
        BorderEdges2.BottomRight = True
        BorderEdges2.TopLeft = True
        BorderEdges2.TopRight = True
        Me.btnUpdate.CustomizableEdges = BorderEdges2
        Me.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUpdate.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnUpdate.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUpdate.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUpdate.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUpdate.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnUpdate.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnUpdate.IconMarginLeft = 11
        Me.btnUpdate.IconPadding = 10
        Me.btnUpdate.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnUpdate.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnUpdate.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnUpdate.IconSize = 25
        Me.btnUpdate.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.IdleBorderRadius = 18
        Me.btnUpdate.IdleBorderThickness = 1
        Me.btnUpdate.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.IdleIconLeftImage = Nothing
        Me.btnUpdate.IdleIconRightImage = Nothing
        Me.btnUpdate.IndicateFocus = False
        Me.btnUpdate.Location = New System.Drawing.Point(335, 216)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnUpdate.OnDisabledState.BorderRadius = 18
        Me.btnUpdate.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnDisabledState.BorderThickness = 1
        Me.btnUpdate.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUpdate.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUpdate.OnDisabledState.IconLeftImage = Nothing
        Me.btnUpdate.OnDisabledState.IconRightImage = Nothing
        Me.btnUpdate.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUpdate.onHoverState.BorderRadius = 18
        Me.btnUpdate.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.onHoverState.BorderThickness = 1
        Me.btnUpdate.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUpdate.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.onHoverState.IconLeftImage = Nothing
        Me.btnUpdate.onHoverState.IconRightImage = Nothing
        Me.btnUpdate.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.OnIdleState.BorderRadius = 18
        Me.btnUpdate.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnIdleState.BorderThickness = 1
        Me.btnUpdate.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.OnIdleState.IconLeftImage = Nothing
        Me.btnUpdate.OnIdleState.IconRightImage = Nothing
        Me.btnUpdate.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnUpdate.OnPressedState.BorderRadius = 18
        Me.btnUpdate.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnPressedState.BorderThickness = 1
        Me.btnUpdate.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnUpdate.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.OnPressedState.IconLeftImage = Nothing
        Me.btnUpdate.OnPressedState.IconRightImage = Nothing
        Me.btnUpdate.Size = New System.Drawing.Size(78, 40)
        Me.btnUpdate.TabIndex = 23
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnUpdate.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnUpdate.TextMarginLeft = 0
        Me.btnUpdate.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnUpdate.UseDefaultRadiusAndThickness = True
        '
        'txtDescription
        '
        Me.txtDescription.AcceptsReturn = False
        Me.txtDescription.AcceptsTab = False
        Me.txtDescription.AnimationSpeed = 200
        Me.txtDescription.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtDescription.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtDescription.BackColor = System.Drawing.Color.White
        Me.txtDescription.BackgroundImage = CType(resources.GetObject("txtDescription.BackgroundImage"), System.Drawing.Image)
        Me.txtDescription.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtDescription.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtDescription.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtDescription.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtDescription.BorderRadius = 1
        Me.txtDescription.BorderThickness = 1
        Me.txtDescription.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtDescription.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDescription.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtDescription.DefaultText = ""
        Me.txtDescription.FillColor = System.Drawing.Color.White
        Me.txtDescription.HideSelection = True
        Me.txtDescription.IconLeft = Nothing
        Me.txtDescription.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDescription.IconPadding = 10
        Me.txtDescription.IconRight = Nothing
        Me.txtDescription.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDescription.Lines = New String(-1) {}
        Me.txtDescription.Location = New System.Drawing.Point(186, 141)
        Me.txtDescription.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDescription.MaxLength = 32767
        Me.txtDescription.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtDescription.Modified = False
        Me.txtDescription.Multiline = False
        Me.txtDescription.Name = "txtDescription"
        StateProperties1.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties1.FillColor = System.Drawing.Color.Empty
        StateProperties1.ForeColor = System.Drawing.Color.Empty
        StateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtDescription.OnActiveState = StateProperties1
        StateProperties2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties2.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtDescription.OnDisabledState = StateProperties2
        StateProperties3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties3.FillColor = System.Drawing.Color.Empty
        StateProperties3.ForeColor = System.Drawing.Color.Empty
        StateProperties3.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtDescription.OnHoverState = StateProperties3
        StateProperties4.BorderColor = System.Drawing.Color.Silver
        StateProperties4.FillColor = System.Drawing.Color.White
        StateProperties4.ForeColor = System.Drawing.Color.Empty
        StateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtDescription.OnIdleState = StateProperties4
        Me.txtDescription.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDescription.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtDescription.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtDescription.PlaceholderText = "Description"
        Me.txtDescription.ReadOnly = False
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtDescription.SelectedText = ""
        Me.txtDescription.SelectionLength = 0
        Me.txtDescription.SelectionStart = 0
        Me.txtDescription.ShortcutsEnabled = True
        Me.txtDescription.Size = New System.Drawing.Size(500, 45)
        Me.txtDescription.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtDescription.TabIndex = 18
        Me.txtDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtDescription.TextMarginBottom = 0
        Me.txtDescription.TextMarginLeft = 3
        Me.txtDescription.TextMarginTop = 0
        Me.txtDescription.TextPlaceholder = "Description"
        Me.txtDescription.UseSystemPasswordChar = False
        Me.txtDescription.WordWrap = True
        '
        'txtPcode
        '
        Me.txtPcode.AcceptsReturn = False
        Me.txtPcode.AcceptsTab = False
        Me.txtPcode.AnimationSpeed = 200
        Me.txtPcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtPcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtPcode.BackColor = System.Drawing.Color.White
        Me.txtPcode.BackgroundImage = CType(resources.GetObject("txtPcode.BackgroundImage"), System.Drawing.Image)
        Me.txtPcode.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtPcode.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtPcode.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPcode.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtPcode.BorderRadius = 1
        Me.txtPcode.BorderThickness = 1
        Me.txtPcode.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtPcode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPcode.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtPcode.DefaultText = ""
        Me.txtPcode.FillColor = System.Drawing.Color.White
        Me.txtPcode.HideSelection = True
        Me.txtPcode.IconLeft = Nothing
        Me.txtPcode.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPcode.IconPadding = 10
        Me.txtPcode.IconRight = Nothing
        Me.txtPcode.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPcode.Lines = New String(-1) {}
        Me.txtPcode.Location = New System.Drawing.Point(186, 83)
        Me.txtPcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPcode.MaxLength = 32767
        Me.txtPcode.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtPcode.Modified = False
        Me.txtPcode.Multiline = False
        Me.txtPcode.Name = "txtPcode"
        StateProperties5.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties5.FillColor = System.Drawing.Color.Empty
        StateProperties5.ForeColor = System.Drawing.Color.Empty
        StateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtPcode.OnActiveState = StateProperties5
        StateProperties6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties6.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtPcode.OnDisabledState = StateProperties6
        StateProperties7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties7.FillColor = System.Drawing.Color.Empty
        StateProperties7.ForeColor = System.Drawing.Color.Empty
        StateProperties7.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPcode.OnHoverState = StateProperties7
        StateProperties8.BorderColor = System.Drawing.Color.Silver
        StateProperties8.FillColor = System.Drawing.Color.White
        StateProperties8.ForeColor = System.Drawing.Color.Empty
        StateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtPcode.OnIdleState = StateProperties8
        Me.txtPcode.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPcode.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtPcode.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtPcode.PlaceholderText = "Program Code"
        Me.txtPcode.ReadOnly = False
        Me.txtPcode.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtPcode.SelectedText = ""
        Me.txtPcode.SelectionLength = 0
        Me.txtPcode.SelectionStart = 0
        Me.txtPcode.ShortcutsEnabled = True
        Me.txtPcode.Size = New System.Drawing.Size(204, 45)
        Me.txtPcode.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtPcode.TabIndex = 16
        Me.txtPcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtPcode.TextMarginBottom = 0
        Me.txtPcode.TextMarginLeft = 3
        Me.txtPcode.TextMarginTop = 0
        Me.txtPcode.TextPlaceholder = "Program Code"
        Me.txtPcode.UseSystemPasswordChar = False
        Me.txtPcode.WordWrap = True
        '
        'btnSave
        '
        Me.btnSave.AllowAnimations = True
        Me.btnSave.AllowMouseEffects = True
        Me.btnSave.AllowToggling = False
        Me.btnSave.AnimationSpeed = 200
        Me.btnSave.AutoGenerateColors = False
        Me.btnSave.AutoRoundBorders = False
        Me.btnSave.AutoSizeLeftIcon = True
        Me.btnSave.AutoSizeRightIcon = True
        Me.btnSave.BackColor = System.Drawing.Color.Transparent
        Me.btnSave.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnSave.BackgroundImage = CType(resources.GetObject("btnSave.BackgroundImage"), System.Drawing.Image)
        Me.btnSave.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.ButtonText = "Save"
        Me.btnSave.ButtonTextMarginLeft = 0
        Me.btnSave.ColorContrastOnClick = 45
        Me.btnSave.ColorContrastOnHover = 45
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges3.BottomLeft = True
        BorderEdges3.BottomRight = True
        BorderEdges3.TopLeft = True
        BorderEdges3.TopRight = True
        Me.btnSave.CustomizableEdges = BorderEdges3
        Me.btnSave.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSave.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSave.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSave.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSave.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnSave.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnSave.IconMarginLeft = 11
        Me.btnSave.IconPadding = 10
        Me.btnSave.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSave.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnSave.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnSave.IconSize = 25
        Me.btnSave.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.IdleBorderRadius = 18
        Me.btnSave.IdleBorderThickness = 1
        Me.btnSave.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.IdleIconLeftImage = Nothing
        Me.btnSave.IdleIconRightImage = Nothing
        Me.btnSave.IndicateFocus = False
        Me.btnSave.Location = New System.Drawing.Point(251, 216)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSave.OnDisabledState.BorderRadius = 18
        Me.btnSave.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnDisabledState.BorderThickness = 1
        Me.btnSave.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSave.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSave.OnDisabledState.IconLeftImage = Nothing
        Me.btnSave.OnDisabledState.IconRightImage = Nothing
        Me.btnSave.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.onHoverState.BorderRadius = 18
        Me.btnSave.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.onHoverState.BorderThickness = 1
        Me.btnSave.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnSave.onHoverState.IconLeftImage = Nothing
        Me.btnSave.onHoverState.IconRightImage = Nothing
        Me.btnSave.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.OnIdleState.BorderRadius = 18
        Me.btnSave.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnIdleState.BorderThickness = 1
        Me.btnSave.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnSave.OnIdleState.IconLeftImage = Nothing
        Me.btnSave.OnIdleState.IconRightImage = Nothing
        Me.btnSave.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSave.OnPressedState.BorderRadius = 18
        Me.btnSave.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnPressedState.BorderThickness = 1
        Me.btnSave.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSave.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnSave.OnPressedState.IconLeftImage = Nothing
        Me.btnSave.OnPressedState.IconRightImage = Nothing
        Me.btnSave.Size = New System.Drawing.Size(78, 40)
        Me.btnSave.TabIndex = 15
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSave.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnSave.TextMarginLeft = 0
        Me.btnSave.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnSave.UseDefaultRadiusAndThickness = True
        '
        'ElipseFrmProgram
        '
        Me.ElipseFrmProgram.ElipseRadius = 23
        Me.ElipseFrmProgram.TargetControl = Me
        '
        'snbInformation
        '
        Me.snbInformation.AllowDragging = False
        Me.snbInformation.AllowMultipleViews = True
        Me.snbInformation.ClickToClose = True
        Me.snbInformation.DoubleClickToClose = True
        Me.snbInformation.DurationAfterIdle = 3000
        Me.snbInformation.ErrorOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.ErrorOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.ErrorOptions.ActionBorderRadius = 1
        Me.snbInformation.ErrorOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.ErrorOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.ErrorOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.ErrorOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.ErrorOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.snbInformation.ErrorOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.ErrorOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.ErrorOptions.Icon = CType(resources.GetObject("resource.Icon"), System.Drawing.Image)
        Me.snbInformation.ErrorOptions.IconLeftMargin = 12
        Me.snbInformation.FadeCloseIcon = False
        Me.snbInformation.Host = Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner
        Me.snbInformation.InformationOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.InformationOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.InformationOptions.ActionBorderRadius = 1
        Me.snbInformation.InformationOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.InformationOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.InformationOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.InformationOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.InformationOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(213, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.InformationOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.InformationOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.InformationOptions.Icon = CType(resources.GetObject("resource.Icon1"), System.Drawing.Image)
        Me.snbInformation.InformationOptions.IconLeftMargin = 12
        Me.snbInformation.Margin = 10
        Me.snbInformation.MaximumSize = New System.Drawing.Size(0, 0)
        Me.snbInformation.MaximumViews = 7
        Me.snbInformation.MessageRightMargin = 15
        Me.snbInformation.MinimumSize = New System.Drawing.Size(0, 0)
        Me.snbInformation.ShowBorders = False
        Me.snbInformation.ShowCloseIcon = False
        Me.snbInformation.ShowIcon = True
        Me.snbInformation.ShowShadows = True
        Me.snbInformation.SuccessOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.SuccessOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.SuccessOptions.ActionBorderRadius = 1
        Me.snbInformation.SuccessOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.SuccessOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.SuccessOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.SuccessOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.SuccessOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.snbInformation.SuccessOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.SuccessOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.SuccessOptions.Icon = CType(resources.GetObject("resource.Icon2"), System.Drawing.Image)
        Me.snbInformation.SuccessOptions.IconLeftMargin = 12
        Me.snbInformation.ViewsMargin = 7
        Me.snbInformation.WarningOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.WarningOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.WarningOptions.ActionBorderRadius = 1
        Me.snbInformation.WarningOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.WarningOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.WarningOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.WarningOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.WarningOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.snbInformation.WarningOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.WarningOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.WarningOptions.Icon = CType(resources.GetObject("resource.Icon3"), System.Drawing.Image)
        Me.snbInformation.WarningOptions.IconLeftMargin = 12
        Me.snbInformation.ZoomCloseIcon = True
        '
        'frmProgram
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(750, 338)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.cboType)
        Me.Controls.Add(Me.lblType)
        Me.Controls.Add(Me.lblDescription)
        Me.Controls.Add(Me.txtDescription)
        Me.Controls.Add(Me.lblPcode)
        Me.Controls.Add(Me.txtPcode)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.pnlTopBar)
        Me.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmProgram"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlTopBar.ResumeLayout(False)
        Me.pnlTopBar.PerformLayout()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblProgramDetails As Label
    Friend WithEvents pnlTopBar As Panel
    Friend WithEvents pcbClose As PictureBox
    Public WithEvents btnSave As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents txtPcode As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents lblPcode As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents lblDescription As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtDescription As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents lblType As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents cboType As Bunifu.UI.WinForms.BunifuDropdown
    Public WithEvents btnUpdate As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Public WithEvents btnCancel As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents ElipseFrmProgram As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents snbInformation As Bunifu.UI.WinForms.BunifuSnackbar
End Class

