﻿Imports System.Data.OleDb
Module Module1
    Public cn As New OleDbConnection("Provider=Microsoft.JET.OLEDB.4.0;Data Source=|DataDirectory|\OSA_Records.accdb")
    Public cm As New OleDbCommand
    Public dr As OleDbDataReader
    Public _user, _pass, _name As String
    Sub ConnectToDatabase()
        Try
            cn.Open()
            cn.Close()

        Catch ex As Exception
            Console.WriteLine("ConnectToDatabase Error: " & ex.ToString())
            MsgBox(ex.Message, vbCritical)
        End Try
    End Sub

    Function GetAy() As String
        Dim _ay As String
        cn.Open()
        cm = New OleDbCommand("select aycode from tblay where status like 'OPEN'", cn)
        dr = cm.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            _ay = dr.Item(0).ToString
        Else
            _ay = ""
        End If
        dr.Close()
        cn.Close()

        Return _ay
    End Function

    Sub Dashboard()
        Try
            frmMain.lblAY.Text = GetAy()
            cn.Open()
            cm = New OleDbCommand("SELECT count(*) from tblstudent", cn)
            frmMain.lblStudent.Text = Format(CLng(cm.ExecuteScalar), "#, ##0")
            cn.Close()

            cn.Open()
            cm = New OleDbCommand("SELECT count(*) from tblviolation where aycode like '" & frmMain.lblAY.Text & "'", cn)
            frmMain.lblViolation.Text = Format(CLng(cm.ExecuteScalar), "#, ##0")
            cn.Close()
        Catch ex As Exception
            cn.Close()
            MsgBox(ex.Message, vbCritical)
        End Try
    End Sub
End Module
