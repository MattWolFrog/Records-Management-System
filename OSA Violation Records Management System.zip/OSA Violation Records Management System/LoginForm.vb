﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Button
Imports System.Collections.Generic
Imports System.Drawing.Text
Imports System.Data.OleDb

Public Class LoginForm

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            If txtPassword.Text = String.Empty Or txtUsername.Text = String.Empty Then
                snbMissingCreds.Show(Me, "Required missing credentials",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomLeft,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return
            End If
            Dim found As Boolean = True
            cn.Open()
            cm = New OleDbCommand("SELECT * from tblUser where [username] = @username and [password] = @password", cn)
            With cm
                .Parameters.AddWithValue("@username", txtUsername.Text)
                .Parameters.AddWithValue("@password", txtPassword.Text)
            End With
            dr = cm.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                found = True
                _user = dr.Item("username").ToString
                _pass = dr.Item("password").ToString
                _name = dr.Item("name").ToString
            Else
                found = False
                snbMissingCreds.Show(Me, "Invalid username or password",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomLeft,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                _user = ""
                _pass = ""
                _name = ""
            End If
            dr.Close()
            cn.Close()

            If found = True Then
                With frmMain
                    txtUsername.Clear()
                    txtPassword.Clear()
                    Me.Hide()
                    .lblCurrentUser.Text = _name
                    frmMain.Show()
                End With

            End If
        Catch ex As Exception
            cn.Close()
            MsgBox(ex.Message, vbCritical)
        End Try
    End Sub

    Private Sub pcbClose_Click(sender As Object, e As EventArgs) Handles pcbClose.Click
        Dim customMessageBox As New frmMessageDialogue("Exit Application", "Do you want to exit?", "Yes", "No")
        customMessageBox.ShowDialog()

        If customMessageBox.UserChoice = DialogResult.Yes Then
            Application.ExitThread()
        End If
    End Sub

    Private Sub pcbMinimize_Click(sender As Object, e As EventArgs) Handles pcbMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private imageIndex As Integer = 0 ' Variable to track the current image index

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        If txtPassword.Text.Length > 0 Then
            txtPassword.UseSystemPasswordChar = True
        Else
            txtPassword.UseSystemPasswordChar = False
        End If
    End Sub

    Private Sub txtPassword_OnIconRightClick(sender As Object, e As EventArgs) Handles txtPassword.OnIconRightClick
        txtPassword.UseSystemPasswordChar = txtPassword.UseSystemPasswordChar Xor True

        If imageIndex = 0 Then
            txtPassword.IconRight = My.Resources.hide
            imageIndex = 1
        Else
            txtPassword.IconRight = My.Resources.show
            imageIndex = 0
        End If
    End Sub

End Class