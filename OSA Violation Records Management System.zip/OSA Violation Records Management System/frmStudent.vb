﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Reflection.Emit
Imports Bunifu.UI.WinForms

Public Class frmStudent
    Private Sub frmStudent_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Sub LoadProgram()
        cboProgram.Items.Clear()

        cn.Open()
        cm = New OleDbCommand("select * from tblprogram", cn)
        dr = cm.ExecuteReader
        While dr.Read
            cboProgram.Items.Add(dr.Item("pcode").ToString)
        End While
        dr.Close()
        cn.Close()
    End Sub

    Private Sub cboProgram_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboProgram.SelectedIndexChanged
        If String.IsNullOrEmpty(cboProgram.Text) Then
            snbInformation.Show(Me,
            "Please fill in the Program",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
            Return
        End If

        cboSection.Items.Clear()

        cn.Open()
        cm = New OleDbCommand("select * from tblsection where pcode = @pcode", cn)
        cm.Parameters.AddWithValue("@pcode", cboProgram.Text)
        dr = cm.ExecuteReader
        While dr.Read
            cboSection.Items.Add(dr.Item("sectionname").ToString)
        End While
        dr.Close()
        cn.Close()
    End Sub

    Private Sub cboProgram_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cboProgram.KeyPress
        e.Handled = True
    End Sub

    Private Sub cboSection_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cboSection.KeyPress
        e.Handled = True
    End Sub

    Private Sub pcbClose_Click(sender As Object, e As EventArgs) Handles pcbClose.Click
        Dim customMessageBox As New frmMessageDialogue("Exit Student Details", "Do you want to exit?", "Yes", "No")
        customMessageBox.ShowDialog()

        If customMessageBox.UserChoice = DialogResult.Yes Then
            Me.Dispose()
        End If
    End Sub

    Sub Clear()
        txtLName.Clear()
        txtFName.Clear()
        txtMName.Clear()
        txtContact.Clear()
        txtAddress.Clear()
        txtStudentNo.Clear()
        pcbImage.Image = Nothing
        cboProgram.SelectedIndex = -1
        cboSection.SelectedIndex = -1
        txtStudentNo.Enabled = True
        btnSave.Enabled = True
        btnUpdate.Enabled = False

    End Sub

    Private Sub btnBrowsePic_Click(sender As Object, e As EventArgs) Handles btnBrowsePic.Click
        Using ofd As New OpenFileDialog With {.Filter = "(Image Files)|*.jpg;*.png;|Jpg, |*.png", .Multiselect = False, .Title = "Select Image"}
            If ofd.ShowDialog = 1 Then
                pcbImage.Image = Image.FromFile(ofd.FileName)
                OpenFileDialog1.FileName = ofd.FileName

            End If
        End Using
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            ' Check if textboxes and combobox are empty
            If String.IsNullOrEmpty(txtLName.Text) OrElse
           String.IsNullOrEmpty(txtFName.Text) OrElse
           String.IsNullOrEmpty(txtMName.Text) OrElse
           String.IsNullOrEmpty(txtContact.Text) OrElse
           String.IsNullOrEmpty(txtAddress.Text) OrElse
           String.IsNullOrEmpty(cboSection.Text) OrElse
           String.IsNullOrEmpty(cboProgram.Text) Then

                snbInformation.Show(Me,
            "Please fill in all fields before saving.",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return ' Exit the subroutine if any field is empty
            End If

            Dim customMessageBox As New frmMessageDialogue("Save", "Save record?", "Yes", "No")
            customMessageBox.ShowDialog()

            If customMessageBox.UserChoice = DialogResult.Yes Then
                Dim sectionid As String
                cn.Open()
                cm = New OleDbCommand("select * From tblsection Where sectionname LIKE '" & cboSection.Text & "'", cn)
                cm.Parameters.AddWithValue("@sectionname", cboSection.Text)
                dr = cm.ExecuteReader
                dr.Read()
                If dr.HasRows Then sectionid = dr.Item("sectionid").ToString Else sectionid = ""
                dr.Close()
                cn.Close()

                Dim mstream As New System.IO.MemoryStream
                pcbImage.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg)
                Dim arrImage() As Byte = mstream.GetBuffer
                cn.Open()
                cm = New OleDbCommand("insert into tblstudent(studentno, lname, fname, mname, sectionid, address, contactno, pic)values(@studentno, @lname, @fname, @mname, @sectionid, @address, @contactno, @pic)", cn)
                With cm
                    .Parameters.AddWithValue("@studentno", txtStudentNo.Text)
                    .Parameters.AddWithValue("@lname", txtLName.Text)
                    .Parameters.AddWithValue("@fname", txtFName.Text)
                    .Parameters.AddWithValue("@mname", txtMName.Text)
                    .Parameters.AddWithValue("@sectionid", sectionid)
                    .Parameters.AddWithValue("@address", txtAddress.Text)
                    .Parameters.AddWithValue("@contactno", txtContact.Text)
                    .Parameters.AddWithValue("@pic", arrImage)
                    .ExecuteNonQuery()
                End With
                cn.Close()
                snbInformation.Show(Me,
            "Record has been successfully saved",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Clear()
                With frmMain
                    .LoadRecordsStudent()
                End With
                Dashboard()
            End If
        Catch ex As Exception
            cn.Close()
            snbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)

        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Dispose()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        ' Add code here
    End Sub

End Class