﻿Imports System.Data.OleDb
Public Class frmAY
    Private Sub pcbClose_Click(sender As Object, e As EventArgs) Handles pcbClose.Click
        Dim customMessageBox As New frmMessageDialogue("Exit Academic Year Details", "Do you want to exit?", "Yes", "No")
        customMessageBox.ShowDialog()

        If customMessageBox.UserChoice = DialogResult.Yes Then
            Me.Dispose()
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs)
        Me.Dispose()
    End Sub

    Private Sub txtTo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtTo.KeyPress
        e.Handled = True
    End Sub

    Sub clear()
        cboSem.Text = " "
        txtTo.Clear()
        txtCode.Clear()
        txtFrom.Clear()
    End Sub

    Private Sub cboSem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboSem.SelectedIndexChanged
        Try
            txtTo.Text = CLng(txtFrom.Text) + 1
            txtCode.Text = txtFrom.Text & "-" & txtTo.Text & " " & cboSem.Text
        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtFrom_TextChanged(sender As Object, e As EventArgs) Handles txtFrom.TextChanged
        Try
            txtTo.Text = CLng(txtFrom.Text) + 1
            txtCode.Text = txtFrom.Text & "-" & txtTo.Text & " " & cboSem.Text
        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtFrom_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtFrom.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57
            Case 8
            Case Else
                e.Handled = True
        End Select
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            ' Check if textboxes and combobox are empty
            If String.IsNullOrEmpty(txtCode.Text) OrElse
           String.IsNullOrEmpty(txtFrom.Text) OrElse
           String.IsNullOrEmpty(txtTo.Text) OrElse
           String.IsNullOrEmpty(cboSem.Text) Then

                snbInformation.Show(Me,
            "Please fill in all fields before saving.",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return ' Exit the subroutine if any field is empty
            End If

            If MsgBox("Save this Academic Year?", vbYesNo + vbQuestion) = vbYes Then
                cn.Open()
                cm = New OleDb.OleDbCommand("update tblay set status = 'CLOSE'", cn)
                cm.ExecuteNonQuery()
                cn.Close()
                cn.Open()
                cm = New OleDb.OleDbCommand("Insert into tblAy(aycode, year1, year2, semester)Values(@aycode, @year1, @year2, @semester)", cn)
                With cm
                    .Parameters.AddWithValue("@aycode", txtCode.Text)
                    .Parameters.AddWithValue("@year1", txtFrom.Text)
                    .Parameters.AddWithValue("@year2", txtTo.Text)
                    .Parameters.AddWithValue("@semester", cboSem.Text)
                    .ExecuteNonQuery()
                End With
                cn.Close()
                MsgBox("New Academic Year has been Added!", vbInformation)
                snbInformation.Show(Me,
            "New Academic Year has been Added",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                With frmMain
                    .LoadRecordsAcademicYear()
                End With
                clear()
                Dashboard()
            End If

        Catch ex As Exception
            cn.Close()
            snbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        End Try
    End Sub
End Class