﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Linq
Imports System.Data.SqlClient
Imports Microsoft.Office.Core
Imports Excel = Microsoft.Office.Interop.Excel
Imports ExcelAutoFormat = Microsoft.Office.Interop.Excel.XlRangeAutoFormat
Imports Microsoft.Office.Interop
Imports System.Xml.XPath
Imports System.Data
Imports System.Xml
Public Class frmMain

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConnectToDatabase()
        Dashboard()
        LoadRecordsStudent()
        LoadRecordsViolation()
        LoadAY()
        LoadRecords()
        LoadRecordsProgram()
        LoadRecordsSection()
        LoadRecordsAcademicYear()
        AutoSuggestStudent()
    End Sub

    'Tooltip code of the App bar

    Private Sub pcbClose_Click(sender As Object, e As EventArgs) Handles pcbClose.Click
        Dim customMessageBox As New frmMessageDialogue("Exit Application", "Do you want to exit?", "Yes", "No")
        customMessageBox.ShowDialog()

        If customMessageBox.UserChoice = DialogResult.Yes Then
            Application.ExitThread()
        End If
    End Sub

    Private Sub pcbMinimize_Click(sender As Object, e As EventArgs) Handles pcbMinimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        pnlIndicator.Top = CType(sender, Control).Top

        Dim customMessageBox As New frmMessageDialogue("Logout Confirmation", "Do you want to logout?", "Yes", "No")
        customMessageBox.ShowDialog()

        If customMessageBox.UserChoice = DialogResult.Yes Then
            Me.Hide()
            LoginForm.Show()
        End If
    End Sub

    ' Indicator Code
    Private Sub btnDashboard_Click(sender As Object, e As EventArgs) Handles btnDashboard.Click
        pnlIndicator.Top = CType(sender, Control).Top
        pages.SetPage("Dashboard")
    End Sub

    Private Sub btnStudent_Click(sender As Object, e As EventArgs) Handles btnStudent.Click
        pnlIndicator.Top = CType(sender, Control).Top
        pages.SetPage("Student Entry")
    End Sub

    Private Sub btnViolation_Click(sender As Object, e As EventArgs) Handles btnViolation.Click
        pnlIndicator.Top = CType(sender, Control).Top
        pages.SetPage("Violation Entry")
        txtAY.Text = GetAy()
    End Sub

    Private Sub btnRecords_Click(sender As Object, e As EventArgs) Handles btnRecords.Click
        pnlIndicator.Top = CType(sender, Control).Top
        pages.SetPage("Records")
    End Sub

    Private Sub btnProgram_Click(sender As Object, e As EventArgs) Handles btnProgram.Click
        pnlIndicator.Top = CType(sender, Control).Top
        pages.SetPage("Program")
    End Sub

    Private Sub btnSection_Click(sender As Object, e As EventArgs) Handles btnSection.Click
        pnlIndicator.Top = CType(sender, Control).Top
        pages.SetPage("Section")
    End Sub

    Private Sub btnAcademic_Click(sender As Object, e As EventArgs) Handles btnAcademic.Click
        pnlIndicator.Top = CType(sender, Control).Top
        pages.SetPage("Academic Year")
    End Sub

    Private Sub btnUserAccount_Click(sender As Object, e As EventArgs) Handles btnUserAccount.Click
        pnlIndicator.Top = CType(sender, Control).Top
        pages.SetPage("User Account")
    End Sub

    Private Sub linkLblAddNew_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles linkLblAddNew.LinkClicked
        With frmProgram
            .btnSave.Enabled = True
            .btnUpdate.Enabled = False
            .ShowDialog()
        End With
    End Sub

    'Student Entry Tab Code
    Private Sub lblAddStudent_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblAddStudent.LinkClicked
        With frmStudent
            .Clear()
            .LoadProgram()
            .ShowDialog()
        End With
    End Sub

    Sub LoadRecordsStudent()
        Try
            dgvStudent.Rows.Clear()
            Dim i As Integer


            ' Ensure the connection is closed before opening
            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If

            ' Create and execute the SQL command
            cm = New OleDbCommand("SELECT * FROM qstudent", cn)
            dr = cm.ExecuteReader()

            ' Debugging: Log message to verify the execution flow
            Console.WriteLine("Executing SQL query...")

            ' Loop through the data reader and populate DataGridView
            While dr.Read()
                i += 1
                Dim rowIndex As Integer = dgvStudent.Rows.Add()
                dgvStudent.Rows(rowIndex).Cells(0).Value = i.ToString
                dgvStudent.Rows(rowIndex).Cells(1).Value = dr("studentno").ToString()
                dgvStudent.Rows(rowIndex).Cells(2).Value = dr("lname").ToString()
                dgvStudent.Rows(rowIndex).Cells(3).Value = dr("fname").ToString()
                dgvStudent.Rows(rowIndex).Cells(4).Value = dr("mname").ToString()
                dgvStudent.Rows(rowIndex).Cells(5).Value = dr("sectionid").ToString()
                dgvStudent.Rows(rowIndex).Cells(6).Value = dr("pcode").ToString()
                dgvStudent.Rows(rowIndex).Cells(7).Value = dr("sectionname").ToString()
                dgvStudent.Rows(rowIndex).Cells(8).Value = dr("address").ToString()
                dgvStudent.Rows(rowIndex).Cells(9).Value = dr("contactno").ToString()

                ' Debugging: Log message for each row added
                Console.WriteLine("Row added to DataGridView.")
            End While

        Catch ex As Exception
            ' Log the exception details for debugging
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        Finally
            ' Close the data reader and connection
            If dr IsNot Nothing AndAlso Not dr.IsClosed Then
                dr.Close()
            End If
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

    'Violation Entry Tab Code
    <DllImport("user32.dll", CharSet:=CharSet.Auto)>
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As Integer, <MarshalAs(UnmanagedType.LPWStr)> ByVal lParam As String) As Int32

    End Function
    Sub AutoSuggestStudent()
        Dim col As New AutoCompleteStringCollection
        Try
            ' Check if the connection is not open
            If cn.State <>
                ConnectionState.Open Then
                ' Open the connection
                cn.Open()
            End If

            cm = New OleDbCommand("select * from qstudent", cn)
            Dim ds As New DataSet
            Dim da As New OleDbDataAdapter(cm)
            da.Fill(ds, "Student")
            Dim i As Integer
            For i = 0 To ds.Tables(0).Rows.Count - 1
                col.Add(ds.Tables(0).Rows(i)("fullname").ToString)
            Next
        Catch ex As Exception
            ' Handle exceptions here
            MsgBox(ex.Message, vbCritical)
        Finally
            ' Close the connection in the finally block to ensure it's always closed
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try

        txtSearch.AutoCompleteSource = AutoCompleteSource.CustomSource
        txtSearch.AutoCompleteCustomSource = col
        txtSearch.AutoCompleteMode = AutoCompleteMode.Suggest
    End Sub

    Sub Clear()
        txtProgram.Clear()
        txtSection.Clear()
        txtSanction.Clear()
        txtSno.Clear()
        txtName.Clear()
        txtViolation.Clear()
        cboTypeV.Text = ""
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        Try

            cn.Open()
            cm = New OleDbCommand("select * from qstudent where fullname = @fullname", cn)
            cm.Parameters.AddWithValue("@fullname", txtSearch.Text)
            dr = cm.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                txtSno.Text = dr.Item("studentno").ToString
                txtName.Text = dr.Item("fullname").ToString
                txtProgram.Text = dr.Item("pcode").ToString
                txtSection.Text = dr.Item("sectionNAME").ToString

                dr.Close()
                cn.Close()
                LoadRecordsViolation()
            Else
                Clear()
                dr.Close()
                cn.Close()
            End If

        Catch ex As Exception
            cn.Close()
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        End Try
    End Sub

    Private Sub cboTypeV_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cboTypeV.KeyPress
        e.Handled = True
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            Dim customMessageBox As New frmMessageDialogue("Save", "Do you want to save it?", "Yes", "No")
            customMessageBox.ShowDialog()

            If customMessageBox.UserChoice = DialogResult.Yes Then
                ' Open the connection
                cn.Open()

                ' Create a new OleDbCommand and associate it with the connection
                Using cm As New OleDbCommand("INSERT INTO tblviolation (studentno, aycode, sdate, violation, sanction, type, [user]) VALUES (@studentno, @aycode, @sdate, @violation, @sanction, @type, @user)", cn)
                    ' Add parameters to the command
                    cm.Parameters.AddWithValue("@studentno", txtSno.Text)
                    cm.Parameters.AddWithValue("@aycode", txtAY.Text)
                    cm.Parameters.AddWithValue("@sdate", Now.Date)
                    cm.Parameters.AddWithValue("@violation", txtViolation.Text)
                    cm.Parameters.AddWithValue("@sanction", txtSanction.Text)
                    cm.Parameters.AddWithValue("@type", cboTypeV.Text)
                    cm.Parameters.AddWithValue("@user", _user)

                    ' Execute the command
                    cm.ExecuteNonQuery()
                End Using ' Dispose of the command object

                ' Close the connection
                cn.Close()

                ' Display a success message
                MsgBox("Record has been successfully saved!", vbInformation)

                ' Reload the records if necessary
                LoadRecordsViolation()
                Dashboard()
            End If
        Catch ex As Exception
            ' Close the connection in case of an error
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
            ' Display the error message
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Clear()
        txtSearch.Clear()
    End Sub

    Sub LoadRecordsViolation()
        Try
            dgvViolation.Rows.Clear()
            Dim i As Integer


            ' Ensure the connection is closed before opening
            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If

            ' Create and execute the SQL command
            cm = New OleDbCommand("select v.id, v.studentno, s.fullname, s.sectionname, v.aycode, v.violation, v.sanction, v.type, v.[user] from tblviolation as v inner join qstudent as s on s.studentno = v.studentno where v.studentno like '" & txtSno.Text & "' and aycode like'" & txtAY.Text & "'", cn)
            dr = cm.ExecuteReader()

            ' Debugging: Log message to verify the execution flow
            Console.WriteLine("Executing SQL query...")

            ' Loop through the data reader and populate DataGridView
            While dr.Read()
                Dim rowIndex As Integer = dgvViolation.Rows.Add()
                dgvViolation.Rows(rowIndex).Cells(0).Value = dr("id").ToString
                dgvViolation.Rows(rowIndex).Cells(1).Value = dr("studentno").ToString()
                dgvViolation.Rows(rowIndex).Cells(2).Value = dr("fullname").ToString()
                dgvViolation.Rows(rowIndex).Cells(3).Value = dr("sectionname").ToString()
                dgvViolation.Rows(rowIndex).Cells(4).Value = dr("aycode").ToString()
                dgvViolation.Rows(rowIndex).Cells(5).Value = dr("violation").ToString()
                dgvViolation.Rows(rowIndex).Cells(6).Value = dr("sanction").ToString()
                dgvViolation.Rows(rowIndex).Cells(7).Value = dr("type").ToString()
                dgvViolation.Rows(rowIndex).Cells(8).Value = dr("user").ToString()

                ' Debugging: Log message for each row added
                Console.WriteLine("Row added to DataGridView.")
            End While

        Catch ex As Exception
            ' Log the exception details for debugging
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        Finally
            ' Close the data reader and connection
            If dr IsNot Nothing AndAlso Not dr.IsClosed Then
                dr.Close()
            End If
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

    'Records Tab Code
    Sub LoadRecords()

        Dim i As Integer
        dgvRecords1.Rows.Clear()
        cn.Open()
        ' Create and execute the SQL command
        cm = New OleDbCommand("SELECT * from qviolation where aycode like '" & cboAYCode.Text & "'", cn)
        dr = cm.ExecuteReader()

        ' Debugging: Log message to verify the execution flow
        Console.WriteLine("Executing SQL query...")

        While dr.Read()
            i += 1
            Dim rowIndex As Integer = dgvRecords1.Rows.Add()
            dgvRecords1.Rows(rowIndex).Cells(0).Value = i.ToString
            dgvRecords1.Rows(rowIndex).Cells(1).Value = dr("studentno").ToString()
            dgvRecords1.Rows(rowIndex).Cells(2).Value = dr("fullname").ToString()
            dgvRecords1.Rows(rowIndex).Cells(3).Value = dr("pcode").ToString()
            dgvRecords1.Rows(rowIndex).Cells(4).Value = dr("sectionname").ToString()
            dgvRecords1.Rows(rowIndex).Cells(5).Value = dr("totalviolation").ToString()
        End While

        dr.Close()
        cn.Close()
    End Sub

    Sub LoadDisplayViolation()

        Dim i As Integer
        dgvDisplay.Rows.Clear()
        cn.Open()
        ' Create and execute the SQL command
        cm = New OleDbCommand("SELECT * from tblviolation where aycode like '" & cboAYCode.Text & "' and studentno like '" & _id & "'", cn)
        dr = cm.ExecuteReader()

        ' Debugging: Log message to verify the execution flow
        Console.WriteLine("Executing SQL query...")

        While dr.Read()
            i += 1
            Dim rowIndex As Integer = dgvDisplay.Rows.Add()
            dgvDisplay.Rows(rowIndex).Cells(0).Value = i.ToString
            dgvDisplay.Rows(rowIndex).Cells(1).Value = Format(CDate(dr("sdate").ToString), "MMM-dd-yyyy")
            dgvDisplay.Rows(rowIndex).Cells(2).Value = dr("violation").ToString()
            dgvDisplay.Rows(rowIndex).Cells(3).Value = dr("sanction").ToString()
            dgvDisplay.Rows(rowIndex).Cells(4).Value = dr("type").ToString()
            dgvDisplay.Rows(rowIndex).Cells(5).Value = dr("user").ToString()
        End While

        dr.Close()
        cn.Close()
    End Sub

    Dim _id As String

    Private Sub dgvRecords1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvRecords1.CellContentClick
        Dim colName As String = dgvRecords1.Columns(e.ColumnIndex).Name
        If colName = "colDisplay" Then
            _id = dgvRecords1.Rows(e.RowIndex).Cells(1).Value.ToString
            LoadDisplayViolation()
        End If
    End Sub

    'Program Tab Code
    Sub LoadRecordsProgram()
        Try
            dgvProgram.Rows.Clear()
            Dim i As Integer


            ' Ensure the connection is closed before opening
            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If

            ' Create and execute the SQL command
            cm = New OleDbCommand("SELECT * FROM tblprogram", cn)
            dr = cm.ExecuteReader()

            ' Debugging: Log message to verify the execution flow
            Console.WriteLine("Executing SQL query...")

            ' Loop through the data reader and populate DataGridView
            While dr.Read()
                i += 1
                Dim rowIndex As Integer = dgvProgram.Rows.Add()
                dgvProgram.Rows(rowIndex).Cells(0).Value = i.ToString
                dgvProgram.Rows(rowIndex).Cells(1).Value = dr("pcode").ToString()
                dgvProgram.Rows(rowIndex).Cells(2).Value = dr("description").ToString()
                dgvProgram.Rows(rowIndex).Cells(3).Value = dr("type").ToString()

                ' Debugging: Log message for each row added
                Console.WriteLine("Row added to DataGridView.")
            End While

        Catch ex As Exception
            ' Log the exception details for debugging
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        Finally
            ' Close the data reader and connection
            If dr IsNot Nothing AndAlso Not dr.IsClosed Then
                dr.Close()
            End If
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

    Private Sub dgvProgram_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvProgram.CellContentClick
        Dim colName As String = dgvProgram.Columns(e.ColumnIndex).Name
        If colName = "colEdit" Then
            With frmProgram
                .txtPcode.Text = dgvProgram.Rows(e.RowIndex).Cells(1).Value.ToString
                .txtDescription.Text = dgvProgram.Rows(e.RowIndex).Cells(2).Value.ToString
                .cboType.Text = dgvProgram.Rows(e.RowIndex).Cells(3).Value.ToString
                .txtPcode.Enabled = False
                .btnSave.Enabled = False
                .btnUpdate.Enabled = True
                .ShowDialog()
            End With

        ElseIf colName = "colDelete" Then
            Dim customMessageBox As New frmMessageDialogue("Deletion", "Delete this record?", "Yes", "No")
            customMessageBox.ShowDialog()

            If customMessageBox.UserChoice = DialogResult.Yes Then
                cn.Open()
                cm = New OleDbCommand("delete from tblprogram where pcode like '" & dgvProgram.Rows(e.RowIndex).Cells(1).Value.ToString & "'", cn)
                cm.ExecuteNonQuery()
                cn.Close()
                SnbInformation.Show(Me,
            "Record has been successfully deleted",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
            End If

        End If
    End Sub

    'Section Tab Code
    Private Sub lblAddSection_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblAddsection.LinkClicked
        With frmSection
            .txtSectionID.Enabled = False
            .txtSectionID.Text = "(Auto)"
            .btnSave.Enabled = True
            .btnUpdate.Enabled = False
            .LoadPcode()
            .ShowDialog()
        End With
    End Sub

    Sub LoadRecordsSection()
        Try
            dgvSection.Rows.Clear()
            Dim i As Integer


            ' Ensure the connection is closed before opening
            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If

            ' Create and execute the SQL command
            cm = New OleDbCommand("SELECT * FROM TBLSECTION", cn)
            dr = cm.ExecuteReader()

            ' Debugging: Log message to verify the execution flow
            Console.WriteLine("Executing SQL query...")

            ' Loop through the data reader and populate DataGridView
            While dr.Read()
                i += 1
                Dim rowIndex As Integer = dgvSection.Rows.Add()
                dgvSection.Rows(rowIndex).Cells(0).Value = i.ToString
                dgvSection.Rows(rowIndex).Cells(1).Value = dr("sectionid").ToString()
                dgvSection.Rows(rowIndex).Cells(2).Value = dr("sectionname").ToString()
                dgvSection.Rows(rowIndex).Cells(3).Value = dr("pcode").ToString()

                ' Debugging: Log message for each row added
                Console.WriteLine("Row added to DataGridView.")
            End While

        Catch ex As Exception
            ' Log the exception details for debugging
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        Finally
            ' Close the data reader and connection
            If dr IsNot Nothing AndAlso Not dr.IsClosed Then
                dr.Close()
            End If
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub


    Private Sub dgvSection_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSection.CellContentClick
        Dim colName As String = dgvSection.Columns(e.ColumnIndex).Name
        If colName = "colEditSection" Then
            With frmSection
                .txtSectionID.Text = dgvSection.Rows(e.RowIndex).Cells(1).Value.ToString
                .txtSection.Text = dgvSection.Rows(e.RowIndex).Cells(2).Value.ToString
                .cboPcode.Text = dgvSection.Rows(e.RowIndex).Cells(3).Value.ToString
                .txtSectionID.Enabled = True
                .btnSave.Enabled = False
                .btnUpdate.Enabled = True
                .LoadPcode()
                .ShowDialog()
            End With

        ElseIf colName = "colDeleteSection" Then
            Dim customMessageBox As New frmMessageDialogue("Deletion", "Delete this record?", "Yes", "No")
            customMessageBox.ShowDialog()

            If customMessageBox.UserChoice = DialogResult.Yes Then
                cn.Open()
                cm = New OleDbCommand("delete from tblsection where pcode like '" & dgvSection.Rows(e.RowIndex).Cells(1).Value.ToString & "'", cn)
                cm.ExecuteNonQuery()
                cn.Close()
                SnbInformation.Show(Me,
            "Record has been successfully deleted",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
            End If

        End If
    End Sub

    'Academic Year Tab Code
    Private Sub lblAddAY_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblAddAY.LinkClicked
        With frmAY
            .txtCode.Enabled = False
            .txtTo.Enabled = False
            .ShowDialog()
        End With
    End Sub

    Sub LoadRecordsAcademicYear()
        Try
            dgvAY.Rows.Clear()
            Dim i As Integer


            ' Ensure the connection is closed before opening
            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If

            ' Create and execute the SQL command
            cm = New OleDbCommand("SELECT * FROM TBLAY", cn)
            dr = cm.ExecuteReader()

            ' Debugging: Log message to verify the execution flow
            Console.WriteLine("Executing SQL query...")

            ' Loop through the data reader and populate DataGridView
            While dr.Read()
                i += 1
                Dim rowIndex As Integer = dgvAY.Rows.Add()
                dgvAY.Rows(rowIndex).Cells(0).Value = i.ToString
                dgvAY.Rows(rowIndex).Cells(1).Value = dr("aycode").ToString()
                dgvAY.Rows(rowIndex).Cells(2).Value = dr("year1").ToString()
                dgvAY.Rows(rowIndex).Cells(3).Value = dr("year2").ToString()
                dgvAY.Rows(rowIndex).Cells(4).Value = dr("semester").ToString()
                dgvAY.Rows(rowIndex).Cells(5).Value = dr("status").ToString()
                ' Debugging: Log message for each row added
                Console.WriteLine("Row added to DataGridView.")
            End While

        Catch ex As Exception
            ' Log the exception details for debugging
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        Finally
            ' Close the data reader and connection
            If dr IsNot Nothing AndAlso Not dr.IsClosed Then
                dr.Close()
            End If
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

    Private Sub dgvAY_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvAY.CellContentClick
        Dim colOpen As String = dgvAY.Columns(e.ColumnIndex).Name
        Dim colClose As String = dgvAY.Columns(e.ColumnIndex).Name
        If colOpen = "colOpen" Then
            If MsgBox("Open this Academic Year " & dgvAY.Rows(e.RowIndex).Cells(1).Value.ToString & "?", vbYesNo + vbQuestion) = vbYes Then
                cn.Open()
                cm = New OleDbCommand("update tblay set status = 'CLOSE'", cn)
                cm.ExecuteNonQuery()
                cn.Close()

                cn.Open()
                cm = New OleDbCommand("update tblay set status = 'OPEN' where aycode like '" & dgvAY.Rows(e.RowIndex).Cells(1).Value.ToString & "'", cn)
                cm.ExecuteNonQuery()
                cn.Close()

                MsgBox("Academic Year " & dgvAY.Rows(e.RowIndex).Cells(1).Value.ToString & " has been successfully opened.", vbInformation)
                LoadRecordsAcademicYear()
            End If
        ElseIf colClose = "colClose" Then
            If MsgBox("Close this Academic Year " & dgvAY.Rows(e.RowIndex).Cells(1).Value.ToString & "?", vbYesNo + vbQuestion) = vbYes Then

                cn.Open()
                cm = New OleDbCommand("update tblay set status = 'CLOSE' where aycode like '" & dgvAY.Rows(e.RowIndex).Cells(1).Value.ToString & "'", cn)
                cm.ExecuteNonQuery()
                cn.Close()

                MsgBox("Academic Year " & dgvAY.Rows(e.RowIndex).Cells(1).Value.ToString & " has been successfully closed.", vbInformation)
                LoadRecordsAcademicYear()
            End If
        End If
        Dashboard()

    End Sub

    Sub LoadAY()
        Try
            cboAYCode.Items.Clear()

            ' Ensure the connection is closed before opening
            If cn.State = ConnectionState.Closed Then
                cn.Open()
            End If

            ' Create and execute the SQL command
            cm = New OleDbCommand("SELECT * FROM tblay", cn)
            dr = cm.ExecuteReader()

            ' Debugging: Log message to verify the execution flow
            Console.WriteLine("Executing SQL query...")

            While (dr.Read)
                cboAYCode.Items.Add(dr.Item("aycode").ToString)
            End While

        Catch ex As Exception
            ' Log the exception details for debugging
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        Finally
            ' Close the data reader and connection
            If dr IsNot Nothing AndAlso Not dr.IsClosed Then
                dr.Close()
            End If
            If cn.State = ConnectionState.Open Then
                cn.Close()
            End If
        End Try
    End Sub

    Private Sub cboAYCode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboAYCode.SelectedIndexChanged
        LoadRecords()
    End Sub
    Private Sub cboAYCode_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cboAYCode.KeyPress
        e.Handled = True
    End Sub


    ' User Account Tab: Create User Account
    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        If txtPassword.Text.Length > 0 Then
            txtPassword.UseSystemPasswordChar = True
        Else
            txtPassword.UseSystemPasswordChar = False
        End If
    End Sub

    Private Sub txtConfirmPass_TextChanged(sender As Object, e As EventArgs) Handles txtConfirmPass.TextChanged
        If txtConfirmPass.Text.Length > 0 Then
            txtConfirmPass.UseSystemPasswordChar = True
        Else
            txtConfirmPass.UseSystemPasswordChar = False
        End If
    End Sub

    Private Sub btnSaveUA_Click(sender As Object, e As EventArgs)
        Try
            Dim customMessageBox As New frmMessageDialogue("Account Creation", "Save this new account?", "Yes", "No")
            customMessageBox.ShowDialog()

            If txtPassword.Text <> txtConfirmPass.Text Then
                SnbInformation.Show(Me,
            "Confirm Password did not matched!",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return
            End If

            If customMessageBox.UserChoice = DialogResult.Yes Then
                cn.Open()
                cm = New OleDbCommand("INSERT INTO tblUser ([username], [password], [name]) values (@username, @password, @name)", cn)
                With cm
                    .Parameters.AddWithValue("@username", txtUsername.Text)
                    .Parameters.AddWithValue("@password", txtPassword.Text)
                    .Parameters.AddWithValue("@name", txtNameUA.Text)
                    .ExecuteNonQuery()
                End With
                cn.Close()
                txtUsername.Clear()
                txtPassword.Clear()
                txtConfirmPass.Clear()
                txtNameUA.Clear()
            End If
        Catch ex As Exception
            cn.Close()
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        End Try
    End Sub

    Private imageIndex As Integer = 0 ' Variable to track the current image index

    Private Sub txtPassword_OnIconRightClick(sender As Object, e As EventArgs) Handles txtPassword.OnIconRightClick
        txtPassword.UseSystemPasswordChar = txtPassword.UseSystemPasswordChar Xor True

        If imageIndex = 0 Then
            txtPassword.IconRight = My.Resources.hide
            imageIndex = 1
        Else
            txtPassword.IconRight = My.Resources.show
            imageIndex = 0
        End If
    End Sub

    Private Sub txtConfirmPass_OnIconRightClick(sender As Object, e As EventArgs) Handles txtConfirmPass.OnIconRightClick
        txtConfirmPass.UseSystemPasswordChar = txtConfirmPass.UseSystemPasswordChar Xor True

        If imageIndex = 0 Then
            txtPassword.IconRight = My.Resources.hide
            imageIndex = 1
        Else
            txtPassword.IconRight = My.Resources.show
            imageIndex = 0
        End If
    End Sub

    ' User Account Tab: Change Password
    Dim old As String

    Private Sub txtCPOldPass_TextChanged(sender As Object, e As EventArgs) Handles txtCPOldPass.TextChanged
        If txtCPOldPass.Text.Length > 0 Then
            txtCPOldPass.UseSystemPasswordChar = True
        Else
            txtCPOldPass.UseSystemPasswordChar = False
        End If
    End Sub
    Private Sub txtCPNewPass_TextChanged(sender As Object, e As EventArgs) Handles txtCPNewPass.TextChanged
        If txtCPNewPass.Text.Length > 0 Then
            txtCPNewPass.UseSystemPasswordChar = True
        Else
            txtCPNewPass.UseSystemPasswordChar = False
        End If
    End Sub

    Private Sub txtCPOldPass_OnIconRightClick(sender As Object, e As EventArgs) Handles txtCPOldPass.OnIconRightClick
        txtCPOldPass.UseSystemPasswordChar = txtCPOldPass.UseSystemPasswordChar Xor True

        If imageIndex = 0 Then
            txtCPOldPass.IconRight = My.Resources.hide
            imageIndex = 1
        Else
            txtCPOldPass.IconRight = My.Resources.show
            imageIndex = 0
        End If
    End Sub

    Private Sub txtCPNewPass_OnIconRightClick(sender As Object, e As EventArgs) Handles txtCPNewPass.OnIconRightClick
        txtCPNewPass.UseSystemPasswordChar = txtCPNewPass.UseSystemPasswordChar Xor True

        If imageIndex = 0 Then
            txtCPNewPass.IconRight = My.Resources.hide
            imageIndex = 1
        Else
            txtCPNewPass.IconRight = My.Resources.show
            imageIndex = 0
        End If
    End Sub

    Private Sub txtCPUsername_TextChanged(sender As Object, e As EventArgs) Handles txtCPUsername.TextChanged
        Try
            cn.Open()
            cm = New OleDbCommand("SELECT * from tblUser where [username] = @username", cn)
            With cm
                .Parameters.AddWithValue("@username", txtCPUsername.Text)
            End With
            dr = cm.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                txtCPOldPass.Enabled = True
                txtCPNewPass.Enabled = True
                txtCPConfirmPass.Enabled = True
                old = dr.Item("password").ToString
            Else
                old = ""
                txtCPOldPass.Enabled = False
                txtCPNewPass.Enabled = False
                txtCPConfirmPass.Enabled = False
            End If
            dr.Close()
            cn.Close()
        Catch ex As Exception
            cn.Close()
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            If old <> txtCPOldPass.Text Then
                SnbInformation.Show(Me,
            "Old password did not matched!",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return
            End If
            If txtCPNewPass.Text <> txtCPConfirmPass.Text Then
                SnbInformation.Show(Me,
            "Confirm new password did not matched!",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return
            End If
            cn.Open()
            cm = New OleDbCommand("UPDATE tblUser set [password] = @password where [username] = @username", cn)
            With cm
                .Parameters.AddWithValue("@password", txtCPNewPass.Text)
                .Parameters.AddWithValue("@username", txtCPUsername.Text)
                .ExecuteNonQuery()
            End With
            cn.Close()
            SnbInformation.Show(Me,
            "Password has been successfully changed!",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
            txtCPUsername.Clear()
            txtCPOldPass.Clear()
            txtCPNewPass.Clear()
            txtCPConfirmPass.Clear()
        Catch ex As Exception
            cn.Close()
            SnbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
        End Try
    End Sub

    Private Sub dgvStudent_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvStudent.CellContentClick
        Try
            Dim colName As String = dgvStudent.Columns(e.ColumnIndex).Name
            If colName = "colEditStudent" Then
                Dim _program, _section As String
                cn.Open()
                cm = New OleDbCommand("SELECT pic, studentno, lname, fname, mname, address, contactno, pcode, [section] FROM qstudent WHERE studentno LIKE @studentno", cn)

                ' Check if the value is not Nothing or an empty string
                Dim studentNoValue As String = dgvStudent.Rows(e.RowIndex).Cells(1).Value?.ToString()
                If String.IsNullOrEmpty(studentNoValue) Then
                    ' Handle the case where the value is Nothing or an empty string
                    SnbInformation.Show(Me,
                "The value is Nothing or an empty string",
                Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
                 4000, "Dismiss",
                Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
                Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                    dr.Close()
                    cn.Close()
                    Return
                End If
                cm.Parameters.AddWithValue("@studentno", "%" & studentNoValue & "%")

                dr = cm.ExecuteReader
                dr.Read()
                If dr.HasRows Then
                    With frmStudent
                        ' Handle the OLE Object column (pic)
                        Dim len As Long = dr.GetBytes(0, 0, Nothing, 0, 0)
                        Dim array(CInt(len)) As Byte
                        dr.GetBytes(0, 0, array, 0, CInt(len))
                        Dim ms As New MemoryStream(array)
                        Dim bitmap As New System.Drawing.Bitmap(ms)

                        .txtStudentNo.Text = dr.Item("studentno").ToString
                        .txtLName.Text = dr.Item("lname").ToString
                        .txtFName.Text = dr.Item("fname").ToString
                        .txtMName.Text = dr.Item("mname").ToString
                        .txtAddress.Text = dr.Item("address").ToString
                        .txtContact.Text = dr.Item("contactno").ToString
                        _program = dr.Item("pcode").ToString
                        _section = dr.Item("section").ToString
                        .btnSave.Enabled = False
                        .btnUpdate.Enabled = True
                        dr.Close()
                        cn.Close()
                        .LoadProgram()
                        .cboProgram.Text = _program
                        .cboSection.Text = _section
                        .ShowDialog()
                    End With
                Else

                End If

            ElseIf colName = "colDeleteStudent" Then
                Dim customMessageBox As New frmMessageDialogue("Deletion", "Delete this record?", "Yes", "No")
                customMessageBox.ShowDialog()

                If customMessageBox.UserChoice = DialogResult.Yes Then
                    cn.Open()
                    cm = New OleDbCommand("DELETE FROM tblprogram WHERE pcode LIKE @pcode", cn)
                    cm.Parameters.AddWithValue("@pcode", dgvStudent.Rows(e.RowIndex).Cells(1).Value.ToString)
                    cm.ExecuteNonQuery()
                    cn.Close()
                    SnbInformation.Show(Me,
                "Record has been successfully deleted",
                Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
                 4000, "Dismiss",
                Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
                Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                    LoadRecords()
                    Dashboard()
                End If
                dr.Close()
                cn.Close()
            End If
        Catch ex As Exception
            SnbInformation.Show(Me,
                "Error: " & ex.Message,
                Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
                 4000, "Dismiss",
                Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
                Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
            dr.Close()
            cn.Close()
        End Try
    End Sub

End Class