﻿
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LoginForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LoginForm))
        Dim BorderEdges1 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim StateProperties1 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties2 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties3 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties4 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties5 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties6 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties7 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties8 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim Animation1 As Bunifu.UI.WinForms.BunifuAnimatorNS.Animation = New Bunifu.UI.WinForms.BunifuAnimatorNS.Animation()
        Me.pnlLogin = New System.Windows.Forms.Panel()
        Me.btnLogin = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pcbLogo = New System.Windows.Forms.PictureBox()
        Me.txtUsername = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.txtPassword = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.ElipsePnlInvalidCreds = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.pnlDecors = New System.Windows.Forms.Panel()
        Me.pcbMinimize = New System.Windows.Forms.PictureBox()
        Me.pcbClose = New System.Windows.Forms.PictureBox()
        Me.snbMissingCreds = New Bunifu.UI.WinForms.BunifuSnackbar(Me.components)
        Me.trsLogin = New Bunifu.UI.WinForms.BunifuTransition(Me.components)
        Me.pnlLogin.SuspendLayout()
        CType(Me.pcbLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlDecors.SuspendLayout()
        CType(Me.pcbMinimize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlLogin
        '
        Me.pnlLogin.BackColor = System.Drawing.Color.White
        Me.pnlLogin.Controls.Add(Me.btnLogin)
        Me.pnlLogin.Controls.Add(Me.Label1)
        Me.pnlLogin.Controls.Add(Me.lblUsername)
        Me.pnlLogin.Controls.Add(Me.lblTitle)
        Me.pnlLogin.Controls.Add(Me.pcbLogo)
        Me.pnlLogin.Controls.Add(Me.txtUsername)
        Me.pnlLogin.Controls.Add(Me.txtPassword)
        Me.trsLogin.SetDecoration(Me.pnlLogin, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.pnlLogin.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlLogin.Location = New System.Drawing.Point(0, 0)
        Me.pnlLogin.Name = "pnlLogin"
        Me.pnlLogin.Size = New System.Drawing.Size(341, 536)
        Me.pnlLogin.TabIndex = 1
        '
        'btnLogin
        '
        Me.btnLogin.AllowAnimations = True
        Me.btnLogin.AllowMouseEffects = True
        Me.btnLogin.AllowToggling = False
        Me.btnLogin.AnimationSpeed = 200
        Me.btnLogin.AutoGenerateColors = False
        Me.btnLogin.AutoRoundBorders = False
        Me.btnLogin.AutoSizeLeftIcon = True
        Me.btnLogin.AutoSizeRightIcon = True
        Me.btnLogin.BackColor = System.Drawing.Color.Transparent
        Me.btnLogin.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnLogin.BackgroundImage = CType(resources.GetObject("btnLogin.BackgroundImage"), System.Drawing.Image)
        Me.btnLogin.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogin.ButtonText = "Log In"
        Me.btnLogin.ButtonTextMarginLeft = 0
        Me.btnLogin.ColorContrastOnClick = 45
        Me.btnLogin.ColorContrastOnHover = 45
        Me.btnLogin.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges1.BottomLeft = True
        BorderEdges1.BottomRight = True
        BorderEdges1.TopLeft = True
        BorderEdges1.TopRight = True
        Me.btnLogin.CustomizableEdges = BorderEdges1
        Me.trsLogin.SetDecoration(Me.btnLogin, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.btnLogin.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnLogin.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnLogin.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnLogin.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnLogin.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnLogin.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.ForeColor = System.Drawing.Color.White
        Me.btnLogin.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogin.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnLogin.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnLogin.IconMarginLeft = 11
        Me.btnLogin.IconPadding = 10
        Me.btnLogin.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnLogin.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnLogin.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnLogin.IconSize = 25
        Me.btnLogin.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnLogin.IdleBorderRadius = 15
        Me.btnLogin.IdleBorderThickness = 1
        Me.btnLogin.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnLogin.IdleIconLeftImage = Nothing
        Me.btnLogin.IdleIconRightImage = Nothing
        Me.btnLogin.IndicateFocus = False
        Me.btnLogin.Location = New System.Drawing.Point(54, 416)
        Me.btnLogin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnLogin.OnDisabledState.BorderRadius = 15
        Me.btnLogin.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogin.OnDisabledState.BorderThickness = 1
        Me.btnLogin.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnLogin.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnLogin.OnDisabledState.IconLeftImage = Nothing
        Me.btnLogin.OnDisabledState.IconRightImage = Nothing
        Me.btnLogin.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLogin.onHoverState.BorderRadius = 15
        Me.btnLogin.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogin.onHoverState.BorderThickness = 1
        Me.btnLogin.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLogin.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnLogin.onHoverState.IconLeftImage = Nothing
        Me.btnLogin.onHoverState.IconRightImage = Nothing
        Me.btnLogin.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnLogin.OnIdleState.BorderRadius = 15
        Me.btnLogin.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogin.OnIdleState.BorderThickness = 1
        Me.btnLogin.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnLogin.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnLogin.OnIdleState.IconLeftImage = Nothing
        Me.btnLogin.OnIdleState.IconRightImage = Nothing
        Me.btnLogin.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnLogin.OnPressedState.BorderRadius = 15
        Me.btnLogin.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnLogin.OnPressedState.BorderThickness = 1
        Me.btnLogin.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnLogin.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnLogin.OnPressedState.IconLeftImage = Nothing
        Me.btnLogin.OnPressedState.IconRightImage = Nothing
        Me.btnLogin.Size = New System.Drawing.Size(225, 40)
        Me.btnLogin.TabIndex = 62
        Me.btnLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnLogin.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnLogin.TextMarginLeft = 0
        Me.btnLogin.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnLogin.UseDefaultRadiusAndThickness = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.trsLogin.SetDecoration(Me.Label1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.Label1.Font = New System.Drawing.Font("Cascadia Code", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(50, 317)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 21)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Password"
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.trsLogin.SetDecoration(Me.lblUsername, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.lblUsername.Font = New System.Drawing.Font("Cascadia Code", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsername.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblUsername.Location = New System.Drawing.Point(50, 234)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(82, 21)
        Me.lblUsername.TabIndex = 2
        Me.lblUsername.Text = "Username"
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.trsLogin.SetDecoration(Me.lblTitle, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.lblTitle.Font = New System.Drawing.Font("Cascadia Code SemiBold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblTitle.Location = New System.Drawing.Point(49, 132)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(242, 62)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "OSA Records Management System"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pcbLogo
        '
        Me.trsLogin.SetDecoration(Me.pcbLogo, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.pcbLogo.Image = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.LOA_Logo
        Me.pcbLogo.Location = New System.Drawing.Point(108, 23)
        Me.pcbLogo.Name = "pcbLogo"
        Me.pcbLogo.Size = New System.Drawing.Size(120, 100)
        Me.pcbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pcbLogo.TabIndex = 0
        Me.pcbLogo.TabStop = False
        '
        'txtUsername
        '
        Me.txtUsername.AcceptsReturn = False
        Me.txtUsername.AcceptsTab = False
        Me.txtUsername.AnimationSpeed = 200
        Me.txtUsername.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtUsername.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtUsername.BackColor = System.Drawing.Color.White
        Me.txtUsername.BackgroundImage = CType(resources.GetObject("txtUsername.BackgroundImage"), System.Drawing.Image)
        Me.txtUsername.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtUsername.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtUsername.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtUsername.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtUsername.BorderRadius = 15
        Me.txtUsername.BorderThickness = 1
        Me.txtUsername.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtUsername.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.trsLogin.SetDecoration(Me.txtUsername, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.txtUsername.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtUsername.DefaultText = ""
        Me.txtUsername.FillColor = System.Drawing.Color.White
        Me.txtUsername.ForeColor = System.Drawing.SystemColors.ControlText
        Me.txtUsername.HideSelection = True
        Me.txtUsername.IconLeft = Nothing
        Me.txtUsername.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUsername.IconPadding = 10
        Me.txtUsername.IconRight = Nothing
        Me.txtUsername.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtUsername.Lines = New String(-1) {}
        Me.txtUsername.Location = New System.Drawing.Point(54, 259)
        Me.txtUsername.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtUsername.MaxLength = 32767
        Me.txtUsername.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtUsername.Modified = False
        Me.txtUsername.Multiline = False
        Me.txtUsername.Name = "txtUsername"
        StateProperties1.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties1.FillColor = System.Drawing.Color.Empty
        StateProperties1.ForeColor = System.Drawing.Color.Empty
        StateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtUsername.OnActiveState = StateProperties1
        StateProperties2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties2.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtUsername.OnDisabledState = StateProperties2
        StateProperties3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties3.FillColor = System.Drawing.Color.Empty
        StateProperties3.ForeColor = System.Drawing.Color.Empty
        StateProperties3.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtUsername.OnHoverState = StateProperties3
        StateProperties4.BorderColor = System.Drawing.Color.Silver
        StateProperties4.FillColor = System.Drawing.Color.White
        StateProperties4.ForeColor = System.Drawing.SystemColors.ControlText
        StateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtUsername.OnIdleState = StateProperties4
        Me.txtUsername.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtUsername.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtUsername.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtUsername.PlaceholderText = "Enter your username"
        Me.txtUsername.ReadOnly = False
        Me.txtUsername.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtUsername.SelectedText = ""
        Me.txtUsername.SelectionLength = 0
        Me.txtUsername.SelectionStart = 0
        Me.txtUsername.ShortcutsEnabled = True
        Me.txtUsername.Size = New System.Drawing.Size(225, 45)
        Me.txtUsername.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtUsername.TabIndex = 58
        Me.txtUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtUsername.TextMarginBottom = 0
        Me.txtUsername.TextMarginLeft = 3
        Me.txtUsername.TextMarginTop = 0
        Me.txtUsername.TextPlaceholder = "Enter your username"
        Me.txtUsername.UseSystemPasswordChar = False
        Me.txtUsername.WordWrap = True
        '
        'txtPassword
        '
        Me.txtPassword.AcceptsReturn = False
        Me.txtPassword.AcceptsTab = False
        Me.txtPassword.AnimationSpeed = 200
        Me.txtPassword.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtPassword.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtPassword.BackColor = System.Drawing.Color.White
        Me.txtPassword.BackgroundImage = CType(resources.GetObject("txtPassword.BackgroundImage"), System.Drawing.Image)
        Me.txtPassword.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtPassword.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtPassword.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPassword.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtPassword.BorderRadius = 15
        Me.txtPassword.BorderThickness = 1
        Me.txtPassword.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.trsLogin.SetDecoration(Me.txtPassword, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.txtPassword.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtPassword.DefaultText = ""
        Me.txtPassword.FillColor = System.Drawing.Color.White
        Me.txtPassword.ForeColor = System.Drawing.SystemColors.ControlText
        Me.txtPassword.HideSelection = True
        Me.txtPassword.IconLeft = Nothing
        Me.txtPassword.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPassword.IconPadding = 10
        Me.txtPassword.IconRight = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.show
        Me.txtPassword.IconRightCursor = System.Windows.Forms.Cursors.Hand
        Me.txtPassword.Lines = New String(-1) {}
        Me.txtPassword.Location = New System.Drawing.Point(54, 342)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPassword.MaxLength = 32767
        Me.txtPassword.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtPassword.Modified = False
        Me.txtPassword.Multiline = False
        Me.txtPassword.Name = "txtPassword"
        StateProperties5.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties5.FillColor = System.Drawing.Color.Empty
        StateProperties5.ForeColor = System.Drawing.Color.Empty
        StateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtPassword.OnActiveState = StateProperties5
        StateProperties6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties6.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtPassword.OnDisabledState = StateProperties6
        StateProperties7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties7.FillColor = System.Drawing.Color.Empty
        StateProperties7.ForeColor = System.Drawing.Color.Empty
        StateProperties7.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPassword.OnHoverState = StateProperties7
        StateProperties8.BorderColor = System.Drawing.Color.Silver
        StateProperties8.FillColor = System.Drawing.Color.White
        StateProperties8.ForeColor = System.Drawing.SystemColors.ControlText
        StateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtPassword.OnIdleState = StateProperties8
        Me.txtPassword.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtPassword.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtPassword.PlaceholderText = "Enter your password"
        Me.txtPassword.ReadOnly = False
        Me.txtPassword.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtPassword.SelectedText = ""
        Me.txtPassword.SelectionLength = 0
        Me.txtPassword.SelectionStart = 0
        Me.txtPassword.ShortcutsEnabled = True
        Me.txtPassword.Size = New System.Drawing.Size(225, 45)
        Me.txtPassword.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtPassword.TabIndex = 59
        Me.txtPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtPassword.TextMarginBottom = 0
        Me.txtPassword.TextMarginLeft = 3
        Me.txtPassword.TextMarginTop = 0
        Me.txtPassword.TextPlaceholder = "Enter your password"
        Me.txtPassword.UseSystemPasswordChar = False
        Me.txtPassword.WordWrap = True
        '
        'ElipsePnlInvalidCreds
        '
        Me.ElipsePnlInvalidCreds.ElipseRadius = 15
        Me.ElipsePnlInvalidCreds.TargetControl = Me
        '
        'pnlDecors
        '
        Me.pnlDecors.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlDecors.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.Untitled_design
        Me.pnlDecors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pnlDecors.Controls.Add(Me.pcbMinimize)
        Me.pnlDecors.Controls.Add(Me.pcbClose)
        Me.trsLogin.SetDecoration(Me.pnlDecors, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.pnlDecors.Location = New System.Drawing.Point(340, 0)
        Me.pnlDecors.Name = "pnlDecors"
        Me.pnlDecors.Size = New System.Drawing.Size(1001, 536)
        Me.pnlDecors.TabIndex = 0
        '
        'pcbMinimize
        '
        Me.pcbMinimize.BackColor = System.Drawing.Color.Transparent
        Me.pcbMinimize.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_minimize_24__1_
        Me.pcbMinimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.trsLogin.SetDecoration(Me.pcbMinimize, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.pcbMinimize.Location = New System.Drawing.Point(940, 0)
        Me.pcbMinimize.Name = "pcbMinimize"
        Me.pcbMinimize.Size = New System.Drawing.Size(30, 35)
        Me.pcbMinimize.TabIndex = 1
        Me.pcbMinimize.TabStop = False
        '
        'pcbClose
        '
        Me.pcbClose.BackColor = System.Drawing.Color.Transparent
        Me.pcbClose.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_close_24__1_
        Me.pcbClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.trsLogin.SetDecoration(Me.pcbClose, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.pcbClose.Location = New System.Drawing.Point(970, 0)
        Me.pcbClose.Name = "pcbClose"
        Me.pcbClose.Size = New System.Drawing.Size(30, 35)
        Me.pcbClose.TabIndex = 0
        Me.pcbClose.TabStop = False
        '
        'snbMissingCreds
        '
        Me.snbMissingCreds.AllowDragging = False
        Me.snbMissingCreds.AllowMultipleViews = True
        Me.snbMissingCreds.ClickToClose = True
        Me.snbMissingCreds.DoubleClickToClose = True
        Me.snbMissingCreds.DurationAfterIdle = 3000
        Me.snbMissingCreds.ErrorOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbMissingCreds.ErrorOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbMissingCreds.ErrorOptions.ActionBorderRadius = 1
        Me.snbMissingCreds.ErrorOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbMissingCreds.ErrorOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbMissingCreds.ErrorOptions.BackColor = System.Drawing.Color.White
        Me.snbMissingCreds.ErrorOptions.BorderColor = System.Drawing.Color.White
        Me.snbMissingCreds.ErrorOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.snbMissingCreds.ErrorOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbMissingCreds.ErrorOptions.ForeColor = System.Drawing.Color.Black
        Me.snbMissingCreds.ErrorOptions.Icon = CType(resources.GetObject("resource.Icon"), System.Drawing.Image)
        Me.snbMissingCreds.ErrorOptions.IconLeftMargin = 12
        Me.snbMissingCreds.FadeCloseIcon = False
        Me.snbMissingCreds.Host = Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner
        Me.snbMissingCreds.InformationOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbMissingCreds.InformationOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbMissingCreds.InformationOptions.ActionBorderRadius = 1
        Me.snbMissingCreds.InformationOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbMissingCreds.InformationOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbMissingCreds.InformationOptions.BackColor = System.Drawing.Color.White
        Me.snbMissingCreds.InformationOptions.BorderColor = System.Drawing.Color.White
        Me.snbMissingCreds.InformationOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(213, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbMissingCreds.InformationOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbMissingCreds.InformationOptions.ForeColor = System.Drawing.Color.Black
        Me.snbMissingCreds.InformationOptions.Icon = CType(resources.GetObject("resource.Icon1"), System.Drawing.Image)
        Me.snbMissingCreds.InformationOptions.IconLeftMargin = 12
        Me.snbMissingCreds.Margin = 10
        Me.snbMissingCreds.MaximumSize = New System.Drawing.Size(0, 0)
        Me.snbMissingCreds.MaximumViews = 7
        Me.snbMissingCreds.MessageRightMargin = 15
        Me.snbMissingCreds.MinimumSize = New System.Drawing.Size(0, 0)
        Me.snbMissingCreds.ShowBorders = False
        Me.snbMissingCreds.ShowCloseIcon = False
        Me.snbMissingCreds.ShowIcon = True
        Me.snbMissingCreds.ShowShadows = True
        Me.snbMissingCreds.SuccessOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbMissingCreds.SuccessOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbMissingCreds.SuccessOptions.ActionBorderRadius = 1
        Me.snbMissingCreds.SuccessOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbMissingCreds.SuccessOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbMissingCreds.SuccessOptions.BackColor = System.Drawing.Color.White
        Me.snbMissingCreds.SuccessOptions.BorderColor = System.Drawing.Color.White
        Me.snbMissingCreds.SuccessOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.snbMissingCreds.SuccessOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbMissingCreds.SuccessOptions.ForeColor = System.Drawing.Color.Black
        Me.snbMissingCreds.SuccessOptions.Icon = CType(resources.GetObject("resource.Icon2"), System.Drawing.Image)
        Me.snbMissingCreds.SuccessOptions.IconLeftMargin = 12
        Me.snbMissingCreds.ViewsMargin = 7
        Me.snbMissingCreds.WarningOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbMissingCreds.WarningOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbMissingCreds.WarningOptions.ActionBorderRadius = 1
        Me.snbMissingCreds.WarningOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbMissingCreds.WarningOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbMissingCreds.WarningOptions.BackColor = System.Drawing.Color.White
        Me.snbMissingCreds.WarningOptions.BorderColor = System.Drawing.Color.White
        Me.snbMissingCreds.WarningOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.snbMissingCreds.WarningOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbMissingCreds.WarningOptions.ForeColor = System.Drawing.Color.Black
        Me.snbMissingCreds.WarningOptions.Icon = CType(resources.GetObject("resource.Icon3"), System.Drawing.Image)
        Me.snbMissingCreds.WarningOptions.IconLeftMargin = 12
        Me.snbMissingCreds.ZoomCloseIcon = True
        '
        'trsLogin
        '
        Me.trsLogin.AnimationType = Bunifu.UI.WinForms.BunifuAnimatorNS.AnimationType.VertSlide
        Me.trsLogin.Cursor = Nothing
        Animation1.AnimateOnlyDifferences = True
        Animation1.BlindCoeff = CType(resources.GetObject("Animation1.BlindCoeff"), System.Drawing.PointF)
        Animation1.LeafCoeff = 0!
        Animation1.MaxTime = 1.0!
        Animation1.MinTime = 0!
        Animation1.MosaicCoeff = CType(resources.GetObject("Animation1.MosaicCoeff"), System.Drawing.PointF)
        Animation1.MosaicShift = CType(resources.GetObject("Animation1.MosaicShift"), System.Drawing.PointF)
        Animation1.MosaicSize = 0
        Animation1.Padding = New System.Windows.Forms.Padding(0)
        Animation1.RotateCoeff = 0!
        Animation1.RotateLimit = 0!
        Animation1.ScaleCoeff = CType(resources.GetObject("Animation1.ScaleCoeff"), System.Drawing.PointF)
        Animation1.SlideCoeff = CType(resources.GetObject("Animation1.SlideCoeff"), System.Drawing.PointF)
        Animation1.TimeCoeff = 0!
        Animation1.TransparencyCoeff = 0!
        Me.trsLogin.DefaultAnimation = Animation1
        '
        'LoginForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(18, Byte), Integer), CType(CType(18, Byte), Integer), CType(CType(18, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1341, 536)
        Me.Controls.Add(Me.pnlLogin)
        Me.Controls.Add(Me.pnlDecors)
        Me.trsLogin.SetDecoration(Me, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "LoginForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LoginForm"
        Me.pnlLogin.ResumeLayout(False)
        Me.pnlLogin.PerformLayout()
        CType(Me.pcbLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlDecors.ResumeLayout(False)
        CType(Me.pcbMinimize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlDecors As Panel
    Friend WithEvents pnlLogin As Panel
    Friend WithEvents lblUsername As Label
    Friend WithEvents lblTitle As Label
    Friend WithEvents pcbLogo As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents pcbClose As PictureBox
    Friend WithEvents pcbMinimize As PictureBox
    Friend WithEvents ElipsePnlInvalidCreds As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents txtUsername As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents txtPassword As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents snbMissingCreds As Bunifu.UI.WinForms.BunifuSnackbar
    Public WithEvents btnLogin As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents trsLogin As Bunifu.UI.WinForms.BunifuTransition
End Class
