﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmStudent))
        Dim BorderEdges1 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges2 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim StateProperties1 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties2 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties3 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties4 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties5 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties6 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties7 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties8 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties9 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties10 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties11 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties12 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties13 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties14 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties15 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties16 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties17 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties18 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties19 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties20 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties21 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties22 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties23 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties24 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim BorderEdges3 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges4 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Me.btnUpdate = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.cboProgram = New Bunifu.UI.WinForms.BunifuDropdown()
        Me.lblType = New Bunifu.UI.WinForms.BunifuLabel()
        Me.btnSave = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.pnlTopBar = New System.Windows.Forms.Panel()
        Me.pcbClose = New System.Windows.Forms.PictureBox()
        Me.lblProgramDetails = New System.Windows.Forms.Label()
        Me.lblPersonalInfo = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel2 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtLName = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel3 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtFName = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.pnlPersonalInfo = New Bunifu.UI.WinForms.BunifuPanel()
        Me.txtMName = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel4 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtStudentNo = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel1 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.pnlStudentInfo = New Bunifu.UI.WinForms.BunifuPanel()
        Me.txtAddress = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.BunifuLabel8 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtContact = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.cboSection = New Bunifu.UI.WinForms.BunifuDropdown()
        Me.BunifuLabel7 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel6 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.BunifuLabel5 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.btnCancel = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.pcbImage = New Bunifu.UI.WinForms.BunifuPictureBox()
        Me.BunifuPanel1 = New Bunifu.UI.WinForms.BunifuPanel()
        Me.btnBrowsePic = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.lblStudentPic = New Bunifu.UI.WinForms.BunifuLabel()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ElipseFrmStudent = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.snbInformation = New Bunifu.UI.WinForms.BunifuSnackbar(Me.components)
        Me.pnlTopBar.SuspendLayout()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlPersonalInfo.SuspendLayout()
        Me.pnlStudentInfo.SuspendLayout()
        CType(Me.pcbImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BunifuPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnUpdate
        '
        Me.btnUpdate.AllowAnimations = True
        Me.btnUpdate.AllowMouseEffects = True
        Me.btnUpdate.AllowToggling = False
        Me.btnUpdate.AnimationSpeed = 200
        Me.btnUpdate.AutoGenerateColors = False
        Me.btnUpdate.AutoRoundBorders = False
        Me.btnUpdate.AutoSizeLeftIcon = True
        Me.btnUpdate.AutoSizeRightIcon = True
        Me.btnUpdate.BackColor = System.Drawing.Color.Transparent
        Me.btnUpdate.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.BackgroundImage = CType(resources.GetObject("btnUpdate.BackgroundImage"), System.Drawing.Image)
        Me.btnUpdate.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.ButtonText = "Update"
        Me.btnUpdate.ButtonTextMarginLeft = 0
        Me.btnUpdate.ColorContrastOnClick = 45
        Me.btnUpdate.ColorContrastOnHover = 45
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges1.BottomLeft = True
        BorderEdges1.BottomRight = True
        BorderEdges1.TopLeft = True
        BorderEdges1.TopRight = True
        Me.btnUpdate.CustomizableEdges = BorderEdges1
        Me.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUpdate.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnUpdate.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUpdate.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUpdate.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUpdate.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnUpdate.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnUpdate.IconMarginLeft = 11
        Me.btnUpdate.IconPadding = 10
        Me.btnUpdate.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnUpdate.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnUpdate.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnUpdate.IconSize = 25
        Me.btnUpdate.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.IdleBorderRadius = 18
        Me.btnUpdate.IdleBorderThickness = 1
        Me.btnUpdate.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.IdleIconLeftImage = Nothing
        Me.btnUpdate.IdleIconRightImage = Nothing
        Me.btnUpdate.IndicateFocus = False
        Me.btnUpdate.Location = New System.Drawing.Point(620, 493)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnUpdate.OnDisabledState.BorderRadius = 18
        Me.btnUpdate.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnDisabledState.BorderThickness = 1
        Me.btnUpdate.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUpdate.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUpdate.OnDisabledState.IconLeftImage = Nothing
        Me.btnUpdate.OnDisabledState.IconRightImage = Nothing
        Me.btnUpdate.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUpdate.onHoverState.BorderRadius = 18
        Me.btnUpdate.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.onHoverState.BorderThickness = 1
        Me.btnUpdate.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUpdate.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.onHoverState.IconLeftImage = Nothing
        Me.btnUpdate.onHoverState.IconRightImage = Nothing
        Me.btnUpdate.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.OnIdleState.BorderRadius = 18
        Me.btnUpdate.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnIdleState.BorderThickness = 1
        Me.btnUpdate.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.OnIdleState.IconLeftImage = Nothing
        Me.btnUpdate.OnIdleState.IconRightImage = Nothing
        Me.btnUpdate.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnUpdate.OnPressedState.BorderRadius = 18
        Me.btnUpdate.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnPressedState.BorderThickness = 1
        Me.btnUpdate.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnUpdate.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.OnPressedState.IconLeftImage = Nothing
        Me.btnUpdate.OnPressedState.IconRightImage = Nothing
        Me.btnUpdate.Size = New System.Drawing.Size(78, 40)
        Me.btnUpdate.TabIndex = 41
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnUpdate.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnUpdate.TextMarginLeft = 0
        Me.btnUpdate.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnUpdate.UseDefaultRadiusAndThickness = True
        '
        'cboProgram
        '
        Me.cboProgram.BackColor = System.Drawing.Color.Transparent
        Me.cboProgram.BackgroundColor = System.Drawing.Color.White
        Me.cboProgram.BorderColor = System.Drawing.Color.Silver
        Me.cboProgram.BorderRadius = 17
        Me.cboProgram.Color = System.Drawing.Color.Silver
        Me.cboProgram.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down
        Me.cboProgram.DisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboProgram.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cboProgram.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboProgram.DisabledForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.cboProgram.DisabledIndicatorColor = System.Drawing.Color.DarkGray
        Me.cboProgram.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cboProgram.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin
        Me.cboProgram.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProgram.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboProgram.FillDropDown = True
        Me.cboProgram.FillIndicator = False
        Me.cboProgram.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboProgram.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cboProgram.ForeColor = System.Drawing.Color.Black
        Me.cboProgram.FormattingEnabled = True
        Me.cboProgram.Icon = Nothing
        Me.cboProgram.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboProgram.IndicatorColor = System.Drawing.Color.Gray
        Me.cboProgram.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboProgram.ItemBackColor = System.Drawing.Color.White
        Me.cboProgram.ItemBorderColor = System.Drawing.Color.Transparent
        Me.cboProgram.ItemForeColor = System.Drawing.Color.Black
        Me.cboProgram.ItemHeight = 26
        Me.cboProgram.ItemHighLightColor = System.Drawing.Color.DodgerBlue
        Me.cboProgram.ItemHighLightForeColor = System.Drawing.Color.White
        Me.cboProgram.Items.AddRange(New Object() {"ELEMENTARY", "JHS", "SHS"})
        Me.cboProgram.ItemTopMargin = 3
        Me.cboProgram.Location = New System.Drawing.Point(502, 121)
        Me.cboProgram.Name = "cboProgram"
        Me.cboProgram.Size = New System.Drawing.Size(247, 32)
        Me.cboProgram.TabIndex = 40
        Me.cboProgram.Text = Nothing
        Me.cboProgram.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboProgram.TextLeftMargin = 5
        '
        'lblType
        '
        Me.lblType.AllowParentOverrides = False
        Me.lblType.AutoEllipsis = False
        Me.lblType.CursorType = Nothing
        Me.lblType.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblType.Location = New System.Drawing.Point(421, 121)
        Me.lblType.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblType.Name = "lblType"
        Me.lblType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblType.Size = New System.Drawing.Size(61, 21)
        Me.lblType.TabIndex = 39
        Me.lblType.Text = "Program"
        Me.lblType.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblType.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'btnSave
        '
        Me.btnSave.AllowAnimations = True
        Me.btnSave.AllowMouseEffects = True
        Me.btnSave.AllowToggling = False
        Me.btnSave.AnimationSpeed = 200
        Me.btnSave.AutoGenerateColors = False
        Me.btnSave.AutoRoundBorders = False
        Me.btnSave.AutoSizeLeftIcon = True
        Me.btnSave.AutoSizeRightIcon = True
        Me.btnSave.BackColor = System.Drawing.Color.Transparent
        Me.btnSave.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnSave.BackgroundImage = CType(resources.GetObject("btnSave.BackgroundImage"), System.Drawing.Image)
        Me.btnSave.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.ButtonText = "Save"
        Me.btnSave.ButtonTextMarginLeft = 0
        Me.btnSave.ColorContrastOnClick = 45
        Me.btnSave.ColorContrastOnHover = 45
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges2.BottomLeft = True
        BorderEdges2.BottomRight = True
        BorderEdges2.TopLeft = True
        BorderEdges2.TopRight = True
        Me.btnSave.CustomizableEdges = BorderEdges2
        Me.btnSave.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSave.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSave.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSave.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSave.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnSave.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnSave.IconMarginLeft = 11
        Me.btnSave.IconPadding = 10
        Me.btnSave.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSave.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnSave.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnSave.IconSize = 25
        Me.btnSave.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.IdleBorderRadius = 18
        Me.btnSave.IdleBorderThickness = 1
        Me.btnSave.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.IdleIconLeftImage = Nothing
        Me.btnSave.IdleIconRightImage = Nothing
        Me.btnSave.IndicateFocus = False
        Me.btnSave.Location = New System.Drawing.Point(536, 493)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSave.OnDisabledState.BorderRadius = 18
        Me.btnSave.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnDisabledState.BorderThickness = 1
        Me.btnSave.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSave.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSave.OnDisabledState.IconLeftImage = Nothing
        Me.btnSave.OnDisabledState.IconRightImage = Nothing
        Me.btnSave.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.onHoverState.BorderRadius = 18
        Me.btnSave.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.onHoverState.BorderThickness = 1
        Me.btnSave.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnSave.onHoverState.IconLeftImage = Nothing
        Me.btnSave.onHoverState.IconRightImage = Nothing
        Me.btnSave.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.OnIdleState.BorderRadius = 18
        Me.btnSave.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnIdleState.BorderThickness = 1
        Me.btnSave.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnSave.OnIdleState.IconLeftImage = Nothing
        Me.btnSave.OnIdleState.IconRightImage = Nothing
        Me.btnSave.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSave.OnPressedState.BorderRadius = 18
        Me.btnSave.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnPressedState.BorderThickness = 1
        Me.btnSave.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSave.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnSave.OnPressedState.IconLeftImage = Nothing
        Me.btnSave.OnPressedState.IconRightImage = Nothing
        Me.btnSave.Size = New System.Drawing.Size(78, 40)
        Me.btnSave.TabIndex = 34
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSave.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnSave.TextMarginLeft = 0
        Me.btnSave.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnSave.UseDefaultRadiusAndThickness = True
        '
        'pnlTopBar
        '
        Me.pnlTopBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.pnlTopBar.Controls.Add(Me.pcbClose)
        Me.pnlTopBar.Controls.Add(Me.lblProgramDetails)
        Me.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTopBar.Location = New System.Drawing.Point(0, 0)
        Me.pnlTopBar.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pnlTopBar.Name = "pnlTopBar"
        Me.pnlTopBar.Size = New System.Drawing.Size(1107, 37)
        Me.pnlTopBar.TabIndex = 33
        '
        'pcbClose
        '
        Me.pcbClose.BackColor = System.Drawing.Color.Transparent
        Me.pcbClose.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_close_24__1_
        Me.pcbClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pcbClose.Dock = System.Windows.Forms.DockStyle.Right
        Me.pcbClose.Location = New System.Drawing.Point(1077, 0)
        Me.pcbClose.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pcbClose.Name = "pcbClose"
        Me.pcbClose.Size = New System.Drawing.Size(30, 37)
        Me.pcbClose.TabIndex = 5
        Me.pcbClose.TabStop = False
        '
        'lblProgramDetails
        '
        Me.lblProgramDetails.AutoSize = True
        Me.lblProgramDetails.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgramDetails.ForeColor = System.Drawing.Color.White
        Me.lblProgramDetails.Location = New System.Drawing.Point(7, 6)
        Me.lblProgramDetails.Name = "lblProgramDetails"
        Me.lblProgramDetails.Size = New System.Drawing.Size(142, 25)
        Me.lblProgramDetails.TabIndex = 0
        Me.lblProgramDetails.Text = "Student Details"
        '
        'lblPersonalInfo
        '
        Me.lblPersonalInfo.AllowParentOverrides = False
        Me.lblPersonalInfo.AutoEllipsis = False
        Me.lblPersonalInfo.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPersonalInfo.CursorType = System.Windows.Forms.Cursors.Default
        Me.lblPersonalInfo.Font = New System.Drawing.Font("Cascadia Mono", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPersonalInfo.Location = New System.Drawing.Point(20, 17)
        Me.lblPersonalInfo.Name = "lblPersonalInfo"
        Me.lblPersonalInfo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPersonalInfo.Size = New System.Drawing.Size(117, 21)
        Me.lblPersonalInfo.TabIndex = 42
        Me.lblPersonalInfo.Text = "Personal Info"
        Me.lblPersonalInfo.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblPersonalInfo.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel2
        '
        Me.BunifuLabel2.AllowParentOverrides = False
        Me.BunifuLabel2.AutoEllipsis = False
        Me.BunifuLabel2.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel2.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel2.Location = New System.Drawing.Point(44, 72)
        Me.BunifuLabel2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel2.Name = "BunifuLabel2"
        Me.BunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel2.Size = New System.Drawing.Size(74, 21)
        Me.BunifuLabel2.TabIndex = 44
        Me.BunifuLabel2.Text = "Last Name"
        Me.BunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtLName
        '
        Me.txtLName.AcceptsReturn = False
        Me.txtLName.AcceptsTab = False
        Me.txtLName.AnimationSpeed = 200
        Me.txtLName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtLName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtLName.BackColor = System.Drawing.Color.White
        Me.txtLName.BackgroundImage = CType(resources.GetObject("txtLName.BackgroundImage"), System.Drawing.Image)
        Me.txtLName.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtLName.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtLName.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtLName.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtLName.BorderRadius = 1
        Me.txtLName.BorderThickness = 1
        Me.txtLName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtLName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLName.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtLName.DefaultText = ""
        Me.txtLName.FillColor = System.Drawing.Color.White
        Me.txtLName.HideSelection = True
        Me.txtLName.IconLeft = Nothing
        Me.txtLName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLName.IconPadding = 10
        Me.txtLName.IconRight = Nothing
        Me.txtLName.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLName.Lines = New String(-1) {}
        Me.txtLName.Location = New System.Drawing.Point(134, 60)
        Me.txtLName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLName.MaxLength = 32767
        Me.txtLName.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtLName.Modified = False
        Me.txtLName.Multiline = False
        Me.txtLName.Name = "txtLName"
        StateProperties1.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties1.FillColor = System.Drawing.Color.Empty
        StateProperties1.ForeColor = System.Drawing.Color.Empty
        StateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtLName.OnActiveState = StateProperties1
        StateProperties2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties2.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtLName.OnDisabledState = StateProperties2
        StateProperties3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties3.FillColor = System.Drawing.Color.Empty
        StateProperties3.ForeColor = System.Drawing.Color.Empty
        StateProperties3.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtLName.OnHoverState = StateProperties3
        StateProperties4.BorderColor = System.Drawing.Color.Silver
        StateProperties4.FillColor = System.Drawing.Color.White
        StateProperties4.ForeColor = System.Drawing.Color.Empty
        StateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtLName.OnIdleState = StateProperties4
        Me.txtLName.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtLName.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtLName.PlaceholderText = "Last Name"
        Me.txtLName.ReadOnly = False
        Me.txtLName.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtLName.SelectedText = ""
        Me.txtLName.SelectionLength = 0
        Me.txtLName.SelectionStart = 0
        Me.txtLName.ShortcutsEnabled = True
        Me.txtLName.Size = New System.Drawing.Size(247, 45)
        Me.txtLName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtLName.TabIndex = 43
        Me.txtLName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtLName.TextMarginBottom = 0
        Me.txtLName.TextMarginLeft = 3
        Me.txtLName.TextMarginTop = 0
        Me.txtLName.TextPlaceholder = "Last Name"
        Me.txtLName.UseSystemPasswordChar = False
        Me.txtLName.WordWrap = True
        '
        'BunifuLabel3
        '
        Me.BunifuLabel3.AllowParentOverrides = False
        Me.BunifuLabel3.AutoEllipsis = False
        Me.BunifuLabel3.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel3.Location = New System.Drawing.Point(42, 127)
        Me.BunifuLabel3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel3.Name = "BunifuLabel3"
        Me.BunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel3.Size = New System.Drawing.Size(76, 21)
        Me.BunifuLabel3.TabIndex = 47
        Me.BunifuLabel3.Text = "First Name"
        Me.BunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtFName
        '
        Me.txtFName.AcceptsReturn = False
        Me.txtFName.AcceptsTab = False
        Me.txtFName.AnimationSpeed = 200
        Me.txtFName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtFName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtFName.BackColor = System.Drawing.Color.White
        Me.txtFName.BackgroundImage = CType(resources.GetObject("txtFName.BackgroundImage"), System.Drawing.Image)
        Me.txtFName.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtFName.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtFName.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtFName.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtFName.BorderRadius = 1
        Me.txtFName.BorderThickness = 1
        Me.txtFName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtFName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFName.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtFName.DefaultText = ""
        Me.txtFName.FillColor = System.Drawing.Color.White
        Me.txtFName.HideSelection = True
        Me.txtFName.IconLeft = Nothing
        Me.txtFName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFName.IconPadding = 10
        Me.txtFName.IconRight = Nothing
        Me.txtFName.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFName.Lines = New String(-1) {}
        Me.txtFName.Location = New System.Drawing.Point(134, 115)
        Me.txtFName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFName.MaxLength = 32767
        Me.txtFName.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtFName.Modified = False
        Me.txtFName.Multiline = False
        Me.txtFName.Name = "txtFName"
        StateProperties5.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties5.FillColor = System.Drawing.Color.Empty
        StateProperties5.ForeColor = System.Drawing.Color.Empty
        StateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtFName.OnActiveState = StateProperties5
        StateProperties6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties6.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtFName.OnDisabledState = StateProperties6
        StateProperties7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties7.FillColor = System.Drawing.Color.Empty
        StateProperties7.ForeColor = System.Drawing.Color.Empty
        StateProperties7.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtFName.OnHoverState = StateProperties7
        StateProperties8.BorderColor = System.Drawing.Color.Silver
        StateProperties8.FillColor = System.Drawing.Color.White
        StateProperties8.ForeColor = System.Drawing.Color.Empty
        StateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtFName.OnIdleState = StateProperties8
        Me.txtFName.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtFName.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtFName.PlaceholderText = "First Name"
        Me.txtFName.ReadOnly = False
        Me.txtFName.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtFName.SelectedText = ""
        Me.txtFName.SelectionLength = 0
        Me.txtFName.SelectionStart = 0
        Me.txtFName.ShortcutsEnabled = True
        Me.txtFName.Size = New System.Drawing.Size(247, 45)
        Me.txtFName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtFName.TabIndex = 46
        Me.txtFName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtFName.TextMarginBottom = 0
        Me.txtFName.TextMarginLeft = 3
        Me.txtFName.TextMarginTop = 0
        Me.txtFName.TextPlaceholder = "First Name"
        Me.txtFName.UseSystemPasswordChar = False
        Me.txtFName.WordWrap = True
        '
        'pnlPersonalInfo
        '
        Me.pnlPersonalInfo.BackgroundColor = System.Drawing.Color.Transparent
        Me.pnlPersonalInfo.BackgroundImage = CType(resources.GetObject("pnlPersonalInfo.BackgroundImage"), System.Drawing.Image)
        Me.pnlPersonalInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlPersonalInfo.BorderColor = System.Drawing.Color.DarkGray
        Me.pnlPersonalInfo.BorderRadius = 25
        Me.pnlPersonalInfo.BorderThickness = 1
        Me.pnlPersonalInfo.Controls.Add(Me.txtMName)
        Me.pnlPersonalInfo.Controls.Add(Me.BunifuLabel4)
        Me.pnlPersonalInfo.Controls.Add(Me.BunifuLabel3)
        Me.pnlPersonalInfo.Controls.Add(Me.lblPersonalInfo)
        Me.pnlPersonalInfo.Controls.Add(Me.txtFName)
        Me.pnlPersonalInfo.Controls.Add(Me.txtLName)
        Me.pnlPersonalInfo.Controls.Add(Me.BunifuLabel2)
        Me.pnlPersonalInfo.Location = New System.Drawing.Point(12, 48)
        Me.pnlPersonalInfo.Name = "pnlPersonalInfo"
        Me.pnlPersonalInfo.ShowBorders = True
        Me.pnlPersonalInfo.Size = New System.Drawing.Size(771, 188)
        Me.pnlPersonalInfo.TabIndex = 48
        '
        'txtMName
        '
        Me.txtMName.AcceptsReturn = False
        Me.txtMName.AcceptsTab = False
        Me.txtMName.AnimationSpeed = 200
        Me.txtMName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtMName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtMName.BackColor = System.Drawing.Color.White
        Me.txtMName.BackgroundImage = CType(resources.GetObject("txtMName.BackgroundImage"), System.Drawing.Image)
        Me.txtMName.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtMName.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtMName.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtMName.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtMName.BorderRadius = 1
        Me.txtMName.BorderThickness = 1
        Me.txtMName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtMName.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMName.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtMName.DefaultText = ""
        Me.txtMName.FillColor = System.Drawing.Color.White
        Me.txtMName.HideSelection = True
        Me.txtMName.IconLeft = Nothing
        Me.txtMName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMName.IconPadding = 10
        Me.txtMName.IconRight = Nothing
        Me.txtMName.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtMName.Lines = New String(-1) {}
        Me.txtMName.Location = New System.Drawing.Point(502, 60)
        Me.txtMName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMName.MaxLength = 32767
        Me.txtMName.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtMName.Modified = False
        Me.txtMName.Multiline = False
        Me.txtMName.Name = "txtMName"
        StateProperties9.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties9.FillColor = System.Drawing.Color.Empty
        StateProperties9.ForeColor = System.Drawing.Color.Empty
        StateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtMName.OnActiveState = StateProperties9
        StateProperties10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties10.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtMName.OnDisabledState = StateProperties10
        StateProperties11.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties11.FillColor = System.Drawing.Color.Empty
        StateProperties11.ForeColor = System.Drawing.Color.Empty
        StateProperties11.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtMName.OnHoverState = StateProperties11
        StateProperties12.BorderColor = System.Drawing.Color.Silver
        StateProperties12.FillColor = System.Drawing.Color.White
        StateProperties12.ForeColor = System.Drawing.Color.Empty
        StateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtMName.OnIdleState = StateProperties12
        Me.txtMName.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMName.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtMName.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtMName.PlaceholderText = "Middle Name"
        Me.txtMName.ReadOnly = False
        Me.txtMName.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtMName.SelectedText = ""
        Me.txtMName.SelectionLength = 0
        Me.txtMName.SelectionStart = 0
        Me.txtMName.ShortcutsEnabled = True
        Me.txtMName.Size = New System.Drawing.Size(247, 45)
        Me.txtMName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtMName.TabIndex = 48
        Me.txtMName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtMName.TextMarginBottom = 0
        Me.txtMName.TextMarginLeft = 3
        Me.txtMName.TextMarginTop = 0
        Me.txtMName.TextPlaceholder = "Middle Name"
        Me.txtMName.UseSystemPasswordChar = False
        Me.txtMName.WordWrap = True
        '
        'BunifuLabel4
        '
        Me.BunifuLabel4.AllowParentOverrides = False
        Me.BunifuLabel4.AutoEllipsis = False
        Me.BunifuLabel4.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel4.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel4.Location = New System.Drawing.Point(393, 72)
        Me.BunifuLabel4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel4.Name = "BunifuLabel4"
        Me.BunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel4.Size = New System.Drawing.Size(94, 21)
        Me.BunifuLabel4.TabIndex = 49
        Me.BunifuLabel4.Text = "Middle Name"
        Me.BunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtStudentNo
        '
        Me.txtStudentNo.AcceptsReturn = False
        Me.txtStudentNo.AcceptsTab = False
        Me.txtStudentNo.AnimationSpeed = 200
        Me.txtStudentNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtStudentNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtStudentNo.BackColor = System.Drawing.Color.White
        Me.txtStudentNo.BackgroundImage = CType(resources.GetObject("txtStudentNo.BackgroundImage"), System.Drawing.Image)
        Me.txtStudentNo.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtStudentNo.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtStudentNo.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtStudentNo.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtStudentNo.BorderRadius = 1
        Me.txtStudentNo.BorderThickness = 1
        Me.txtStudentNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtStudentNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtStudentNo.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtStudentNo.DefaultText = ""
        Me.txtStudentNo.FillColor = System.Drawing.Color.White
        Me.txtStudentNo.HideSelection = True
        Me.txtStudentNo.IconLeft = Nothing
        Me.txtStudentNo.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtStudentNo.IconPadding = 10
        Me.txtStudentNo.IconRight = Nothing
        Me.txtStudentNo.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtStudentNo.Lines = New String(-1) {}
        Me.txtStudentNo.Location = New System.Drawing.Point(138, 55)
        Me.txtStudentNo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtStudentNo.MaxLength = 32767
        Me.txtStudentNo.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtStudentNo.Modified = False
        Me.txtStudentNo.Multiline = False
        Me.txtStudentNo.Name = "txtStudentNo"
        StateProperties13.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties13.FillColor = System.Drawing.Color.Empty
        StateProperties13.ForeColor = System.Drawing.Color.Empty
        StateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtStudentNo.OnActiveState = StateProperties13
        StateProperties14.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties14.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtStudentNo.OnDisabledState = StateProperties14
        StateProperties15.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties15.FillColor = System.Drawing.Color.Empty
        StateProperties15.ForeColor = System.Drawing.Color.Empty
        StateProperties15.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtStudentNo.OnHoverState = StateProperties15
        StateProperties16.BorderColor = System.Drawing.Color.Silver
        StateProperties16.FillColor = System.Drawing.Color.White
        StateProperties16.ForeColor = System.Drawing.Color.Empty
        StateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtStudentNo.OnIdleState = StateProperties16
        Me.txtStudentNo.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtStudentNo.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtStudentNo.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtStudentNo.PlaceholderText = "Student Number"
        Me.txtStudentNo.ReadOnly = False
        Me.txtStudentNo.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtStudentNo.SelectedText = ""
        Me.txtStudentNo.SelectionLength = 0
        Me.txtStudentNo.SelectionStart = 0
        Me.txtStudentNo.ShortcutsEnabled = True
        Me.txtStudentNo.Size = New System.Drawing.Size(247, 45)
        Me.txtStudentNo.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtStudentNo.TabIndex = 50
        Me.txtStudentNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtStudentNo.TextMarginBottom = 0
        Me.txtStudentNo.TextMarginLeft = 3
        Me.txtStudentNo.TextMarginTop = 0
        Me.txtStudentNo.TextPlaceholder = "Student Number"
        Me.txtStudentNo.UseSystemPasswordChar = False
        Me.txtStudentNo.WordWrap = True
        '
        'BunifuLabel1
        '
        Me.BunifuLabel1.AllowParentOverrides = False
        Me.BunifuLabel1.AutoEllipsis = False
        Me.BunifuLabel1.Cursor = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default
        Me.BunifuLabel1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel1.Location = New System.Drawing.Point(40, 67)
        Me.BunifuLabel1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel1.Name = "BunifuLabel1"
        Me.BunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel1.Size = New System.Drawing.Size(82, 21)
        Me.BunifuLabel1.TabIndex = 51
        Me.BunifuLabel1.Text = "Student No."
        Me.BunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'pnlStudentInfo
        '
        Me.pnlStudentInfo.BackgroundColor = System.Drawing.Color.Transparent
        Me.pnlStudentInfo.BackgroundImage = CType(resources.GetObject("pnlStudentInfo.BackgroundImage"), System.Drawing.Image)
        Me.pnlStudentInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlStudentInfo.BorderColor = System.Drawing.Color.DarkGray
        Me.pnlStudentInfo.BorderRadius = 25
        Me.pnlStudentInfo.BorderThickness = 1
        Me.pnlStudentInfo.Controls.Add(Me.txtAddress)
        Me.pnlStudentInfo.Controls.Add(Me.BunifuLabel8)
        Me.pnlStudentInfo.Controls.Add(Me.txtContact)
        Me.pnlStudentInfo.Controls.Add(Me.BunifuLabel1)
        Me.pnlStudentInfo.Controls.Add(Me.cboSection)
        Me.pnlStudentInfo.Controls.Add(Me.BunifuLabel7)
        Me.pnlStudentInfo.Controls.Add(Me.BunifuLabel6)
        Me.pnlStudentInfo.Controls.Add(Me.BunifuLabel5)
        Me.pnlStudentInfo.Controls.Add(Me.cboProgram)
        Me.pnlStudentInfo.Controls.Add(Me.lblType)
        Me.pnlStudentInfo.Controls.Add(Me.txtStudentNo)
        Me.pnlStudentInfo.Location = New System.Drawing.Point(12, 242)
        Me.pnlStudentInfo.Name = "pnlStudentInfo"
        Me.pnlStudentInfo.ShowBorders = True
        Me.pnlStudentInfo.Size = New System.Drawing.Size(771, 241)
        Me.pnlStudentInfo.TabIndex = 49
        '
        'txtAddress
        '
        Me.txtAddress.AcceptsReturn = False
        Me.txtAddress.AcceptsTab = False
        Me.txtAddress.AnimationSpeed = 200
        Me.txtAddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtAddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtAddress.BackColor = System.Drawing.Color.White
        Me.txtAddress.BackgroundImage = CType(resources.GetObject("txtAddress.BackgroundImage"), System.Drawing.Image)
        Me.txtAddress.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtAddress.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtAddress.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAddress.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtAddress.BorderRadius = 1
        Me.txtAddress.BorderThickness = 1
        Me.txtAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtAddress.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAddress.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtAddress.DefaultText = ""
        Me.txtAddress.FillColor = System.Drawing.Color.White
        Me.txtAddress.HideSelection = True
        Me.txtAddress.IconLeft = Nothing
        Me.txtAddress.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAddress.IconPadding = 10
        Me.txtAddress.IconRight = Nothing
        Me.txtAddress.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtAddress.Lines = New String(-1) {}
        Me.txtAddress.Location = New System.Drawing.Point(138, 178)
        Me.txtAddress.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtAddress.MaxLength = 32767
        Me.txtAddress.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtAddress.Modified = False
        Me.txtAddress.Multiline = False
        Me.txtAddress.Name = "txtAddress"
        StateProperties17.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties17.FillColor = System.Drawing.Color.Empty
        StateProperties17.ForeColor = System.Drawing.Color.Empty
        StateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtAddress.OnActiveState = StateProperties17
        StateProperties18.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties18.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties18.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtAddress.OnDisabledState = StateProperties18
        StateProperties19.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties19.FillColor = System.Drawing.Color.Empty
        StateProperties19.ForeColor = System.Drawing.Color.Empty
        StateProperties19.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtAddress.OnHoverState = StateProperties19
        StateProperties20.BorderColor = System.Drawing.Color.Silver
        StateProperties20.FillColor = System.Drawing.Color.White
        StateProperties20.ForeColor = System.Drawing.Color.Empty
        StateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtAddress.OnIdleState = StateProperties20
        Me.txtAddress.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtAddress.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtAddress.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtAddress.PlaceholderText = "Address"
        Me.txtAddress.ReadOnly = False
        Me.txtAddress.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtAddress.SelectedText = ""
        Me.txtAddress.SelectionLength = 0
        Me.txtAddress.SelectionStart = 0
        Me.txtAddress.ShortcutsEnabled = True
        Me.txtAddress.Size = New System.Drawing.Size(611, 45)
        Me.txtAddress.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtAddress.TabIndex = 54
        Me.txtAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAddress.TextMarginBottom = 0
        Me.txtAddress.TextMarginLeft = 3
        Me.txtAddress.TextMarginTop = 0
        Me.txtAddress.TextPlaceholder = "Address"
        Me.txtAddress.UseSystemPasswordChar = False
        Me.txtAddress.WordWrap = True
        '
        'BunifuLabel8
        '
        Me.BunifuLabel8.AllowParentOverrides = False
        Me.BunifuLabel8.AutoEllipsis = False
        Me.BunifuLabel8.CursorType = Nothing
        Me.BunifuLabel8.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel8.Location = New System.Drawing.Point(62, 189)
        Me.BunifuLabel8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel8.Name = "BunifuLabel8"
        Me.BunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel8.Size = New System.Drawing.Size(56, 21)
        Me.BunifuLabel8.TabIndex = 53
        Me.BunifuLabel8.Text = "Address"
        Me.BunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtContact
        '
        Me.txtContact.AcceptsReturn = False
        Me.txtContact.AcceptsTab = False
        Me.txtContact.AnimationSpeed = 200
        Me.txtContact.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtContact.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtContact.BackColor = System.Drawing.Color.White
        Me.txtContact.BackgroundImage = CType(resources.GetObject("txtContact.BackgroundImage"), System.Drawing.Image)
        Me.txtContact.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtContact.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtContact.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtContact.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtContact.BorderRadius = 1
        Me.txtContact.BorderThickness = 1
        Me.txtContact.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtContact.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtContact.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtContact.DefaultText = ""
        Me.txtContact.FillColor = System.Drawing.Color.White
        Me.txtContact.HideSelection = True
        Me.txtContact.IconLeft = Nothing
        Me.txtContact.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtContact.IconPadding = 10
        Me.txtContact.IconRight = Nothing
        Me.txtContact.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtContact.Lines = New String(-1) {}
        Me.txtContact.Location = New System.Drawing.Point(138, 108)
        Me.txtContact.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtContact.MaxLength = 32767
        Me.txtContact.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtContact.Modified = False
        Me.txtContact.Multiline = False
        Me.txtContact.Name = "txtContact"
        StateProperties21.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties21.FillColor = System.Drawing.Color.Empty
        StateProperties21.ForeColor = System.Drawing.Color.Empty
        StateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtContact.OnActiveState = StateProperties21
        StateProperties22.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties22.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties22.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties22.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtContact.OnDisabledState = StateProperties22
        StateProperties23.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties23.FillColor = System.Drawing.Color.Empty
        StateProperties23.ForeColor = System.Drawing.Color.Empty
        StateProperties23.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtContact.OnHoverState = StateProperties23
        StateProperties24.BorderColor = System.Drawing.Color.Silver
        StateProperties24.FillColor = System.Drawing.Color.White
        StateProperties24.ForeColor = System.Drawing.Color.Empty
        StateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtContact.OnIdleState = StateProperties24
        Me.txtContact.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtContact.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtContact.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtContact.PlaceholderText = "Contact Number"
        Me.txtContact.ReadOnly = False
        Me.txtContact.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtContact.SelectedText = ""
        Me.txtContact.SelectionLength = 0
        Me.txtContact.SelectionStart = 0
        Me.txtContact.ShortcutsEnabled = True
        Me.txtContact.Size = New System.Drawing.Size(247, 45)
        Me.txtContact.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtContact.TabIndex = 52
        Me.txtContact.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtContact.TextMarginBottom = 0
        Me.txtContact.TextMarginLeft = 3
        Me.txtContact.TextMarginTop = 0
        Me.txtContact.TextPlaceholder = "Contact Number"
        Me.txtContact.UseSystemPasswordChar = False
        Me.txtContact.WordWrap = True
        '
        'cboSection
        '
        Me.cboSection.BackColor = System.Drawing.Color.Transparent
        Me.cboSection.BackgroundColor = System.Drawing.Color.White
        Me.cboSection.BorderColor = System.Drawing.Color.Silver
        Me.cboSection.BorderRadius = 17
        Me.cboSection.Color = System.Drawing.Color.Silver
        Me.cboSection.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down
        Me.cboSection.DisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboSection.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cboSection.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboSection.DisabledForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.cboSection.DisabledIndicatorColor = System.Drawing.Color.DarkGray
        Me.cboSection.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cboSection.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin
        Me.cboSection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSection.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboSection.FillDropDown = True
        Me.cboSection.FillIndicator = False
        Me.cboSection.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboSection.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cboSection.ForeColor = System.Drawing.Color.Black
        Me.cboSection.FormattingEnabled = True
        Me.cboSection.Icon = Nothing
        Me.cboSection.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboSection.IndicatorColor = System.Drawing.Color.Gray
        Me.cboSection.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboSection.ItemBackColor = System.Drawing.Color.White
        Me.cboSection.ItemBorderColor = System.Drawing.Color.Transparent
        Me.cboSection.ItemForeColor = System.Drawing.Color.Black
        Me.cboSection.ItemHeight = 26
        Me.cboSection.ItemHighLightColor = System.Drawing.Color.DodgerBlue
        Me.cboSection.ItemHighLightForeColor = System.Drawing.Color.White
        Me.cboSection.ItemTopMargin = 3
        Me.cboSection.Location = New System.Drawing.Point(502, 68)
        Me.cboSection.Name = "cboSection"
        Me.cboSection.Size = New System.Drawing.Size(247, 32)
        Me.cboSection.TabIndex = 47
        Me.cboSection.Text = Nothing
        Me.cboSection.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboSection.TextLeftMargin = 5
        '
        'BunifuLabel7
        '
        Me.BunifuLabel7.AllowParentOverrides = False
        Me.BunifuLabel7.AutoEllipsis = False
        Me.BunifuLabel7.CursorType = Nothing
        Me.BunifuLabel7.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel7.Location = New System.Drawing.Point(431, 68)
        Me.BunifuLabel7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel7.Name = "BunifuLabel7"
        Me.BunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel7.Size = New System.Drawing.Size(51, 21)
        Me.BunifuLabel7.TabIndex = 46
        Me.BunifuLabel7.Text = "Section"
        Me.BunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel7.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel6
        '
        Me.BunifuLabel6.AllowParentOverrides = False
        Me.BunifuLabel6.AutoEllipsis = False
        Me.BunifuLabel6.CursorType = Nothing
        Me.BunifuLabel6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel6.Location = New System.Drawing.Point(41, 119)
        Me.BunifuLabel6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel6.Name = "BunifuLabel6"
        Me.BunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel6.Size = New System.Drawing.Size(81, 21)
        Me.BunifuLabel6.TabIndex = 44
        Me.BunifuLabel6.Text = "Contact No."
        Me.BunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'BunifuLabel5
        '
        Me.BunifuLabel5.AllowParentOverrides = False
        Me.BunifuLabel5.AutoEllipsis = False
        Me.BunifuLabel5.CursorType = Nothing
        Me.BunifuLabel5.Font = New System.Drawing.Font("Cascadia Mono", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel5.Location = New System.Drawing.Point(20, 17)
        Me.BunifuLabel5.Name = "BunifuLabel5"
        Me.BunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel5.Size = New System.Drawing.Size(108, 21)
        Me.BunifuLabel5.TabIndex = 43
        Me.BunifuLabel5.Text = "Student Info"
        Me.BunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'btnCancel
        '
        Me.btnCancel.AllowAnimations = True
        Me.btnCancel.AllowMouseEffects = True
        Me.btnCancel.AllowToggling = False
        Me.btnCancel.AnimationSpeed = 200
        Me.btnCancel.AutoGenerateColors = False
        Me.btnCancel.AutoRoundBorders = False
        Me.btnCancel.AutoSizeLeftIcon = True
        Me.btnCancel.AutoSizeRightIcon = True
        Me.btnCancel.BackColor = System.Drawing.Color.Transparent
        Me.btnCancel.BackColor1 = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.BackgroundImage = CType(resources.GetObject("btnCancel.BackgroundImage"), System.Drawing.Image)
        Me.btnCancel.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.ButtonText = "Cancel"
        Me.btnCancel.ButtonTextMarginLeft = 0
        Me.btnCancel.ColorContrastOnClick = 45
        Me.btnCancel.ColorContrastOnHover = 45
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges3.BottomLeft = True
        BorderEdges3.BottomRight = True
        BorderEdges3.TopLeft = True
        BorderEdges3.TopRight = True
        Me.btnCancel.CustomizableEdges = BorderEdges3
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnCancel.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnCancel.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnCancel.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnCancel.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnCancel.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnCancel.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnCancel.IconMarginLeft = 11
        Me.btnCancel.IconPadding = 10
        Me.btnCancel.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnCancel.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnCancel.IconSize = 25
        Me.btnCancel.IdleBorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.IdleBorderRadius = 18
        Me.btnCancel.IdleBorderThickness = 1
        Me.btnCancel.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.IdleIconLeftImage = Nothing
        Me.btnCancel.IdleIconRightImage = Nothing
        Me.btnCancel.IndicateFocus = False
        Me.btnCancel.Location = New System.Drawing.Point(704, 493)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnCancel.OnDisabledState.BorderRadius = 18
        Me.btnCancel.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnDisabledState.BorderThickness = 1
        Me.btnCancel.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnCancel.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnCancel.OnDisabledState.IconLeftImage = Nothing
        Me.btnCancel.OnDisabledState.IconRightImage = Nothing
        Me.btnCancel.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.btnCancel.onHoverState.BorderRadius = 18
        Me.btnCancel.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.onHoverState.BorderThickness = 1
        Me.btnCancel.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.btnCancel.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.onHoverState.IconLeftImage = Nothing
        Me.btnCancel.onHoverState.IconRightImage = Nothing
        Me.btnCancel.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnIdleState.BorderRadius = 18
        Me.btnCancel.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnIdleState.BorderThickness = 1
        Me.btnCancel.OnIdleState.FillColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.OnIdleState.IconLeftImage = Nothing
        Me.btnCancel.OnIdleState.IconRightImage = Nothing
        Me.btnCancel.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnPressedState.BorderRadius = 18
        Me.btnCancel.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnPressedState.BorderThickness = 1
        Me.btnCancel.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.OnPressedState.IconLeftImage = Nothing
        Me.btnCancel.OnPressedState.IconRightImage = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(78, 40)
        Me.btnCancel.TabIndex = 50
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnCancel.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnCancel.TextMarginLeft = 0
        Me.btnCancel.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnCancel.UseDefaultRadiusAndThickness = True
        '
        'pcbImage
        '
        Me.pcbImage.AllowFocused = False
        Me.pcbImage.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.pcbImage.AutoSizeHeight = True
        Me.pcbImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pcbImage.BorderRadius = 100
        Me.pcbImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pcbImage.Image = CType(resources.GetObject("pcbImage.Image"), System.Drawing.Image)
        Me.pcbImage.InitialImage = Nothing
        Me.pcbImage.IsCircle = False
        Me.pcbImage.Location = New System.Drawing.Point(53, 60)
        Me.pcbImage.Name = "pcbImage"
        Me.pcbImage.Size = New System.Drawing.Size(200, 200)
        Me.pcbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pcbImage.TabIndex = 51
        Me.pcbImage.TabStop = False
        Me.pcbImage.Type = Bunifu.UI.WinForms.BunifuPictureBox.Types.Circle
        '
        'BunifuPanel1
        '
        Me.BunifuPanel1.BackgroundColor = System.Drawing.Color.Transparent
        Me.BunifuPanel1.BackgroundImage = CType(resources.GetObject("BunifuPanel1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuPanel1.BorderColor = System.Drawing.Color.DarkGray
        Me.BunifuPanel1.BorderRadius = 25
        Me.BunifuPanel1.BorderThickness = 1
        Me.BunifuPanel1.Controls.Add(Me.btnBrowsePic)
        Me.BunifuPanel1.Controls.Add(Me.lblStudentPic)
        Me.BunifuPanel1.Controls.Add(Me.pcbImage)
        Me.BunifuPanel1.Location = New System.Drawing.Point(789, 48)
        Me.BunifuPanel1.Name = "BunifuPanel1"
        Me.BunifuPanel1.ShowBorders = True
        Me.BunifuPanel1.Size = New System.Drawing.Size(306, 435)
        Me.BunifuPanel1.TabIndex = 52
        '
        'btnBrowsePic
        '
        Me.btnBrowsePic.AllowAnimations = True
        Me.btnBrowsePic.AllowMouseEffects = True
        Me.btnBrowsePic.AllowToggling = False
        Me.btnBrowsePic.AnimationSpeed = 200
        Me.btnBrowsePic.AutoGenerateColors = False
        Me.btnBrowsePic.AutoRoundBorders = False
        Me.btnBrowsePic.AutoSizeLeftIcon = True
        Me.btnBrowsePic.AutoSizeRightIcon = True
        Me.btnBrowsePic.BackColor = System.Drawing.Color.Transparent
        Me.btnBrowsePic.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnBrowsePic.BackgroundImage = CType(resources.GetObject("btnBrowsePic.BackgroundImage"), System.Drawing.Image)
        Me.btnBrowsePic.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnBrowsePic.ButtonText = "Browse Picture"
        Me.btnBrowsePic.ButtonTextMarginLeft = 0
        Me.btnBrowsePic.ColorContrastOnClick = 45
        Me.btnBrowsePic.ColorContrastOnHover = 45
        Me.btnBrowsePic.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges4.BottomLeft = True
        BorderEdges4.BottomRight = True
        BorderEdges4.TopLeft = True
        BorderEdges4.TopRight = True
        Me.btnBrowsePic.CustomizableEdges = BorderEdges4
        Me.btnBrowsePic.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnBrowsePic.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnBrowsePic.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnBrowsePic.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnBrowsePic.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnBrowsePic.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBrowsePic.ForeColor = System.Drawing.Color.White
        Me.btnBrowsePic.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBrowsePic.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnBrowsePic.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnBrowsePic.IconMarginLeft = 11
        Me.btnBrowsePic.IconPadding = 10
        Me.btnBrowsePic.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnBrowsePic.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnBrowsePic.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnBrowsePic.IconSize = 25
        Me.btnBrowsePic.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnBrowsePic.IdleBorderRadius = 18
        Me.btnBrowsePic.IdleBorderThickness = 1
        Me.btnBrowsePic.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnBrowsePic.IdleIconLeftImage = Nothing
        Me.btnBrowsePic.IdleIconRightImage = Nothing
        Me.btnBrowsePic.IndicateFocus = False
        Me.btnBrowsePic.Location = New System.Drawing.Point(49, 341)
        Me.btnBrowsePic.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnBrowsePic.Name = "btnBrowsePic"
        Me.btnBrowsePic.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnBrowsePic.OnDisabledState.BorderRadius = 18
        Me.btnBrowsePic.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnBrowsePic.OnDisabledState.BorderThickness = 1
        Me.btnBrowsePic.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnBrowsePic.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnBrowsePic.OnDisabledState.IconLeftImage = Nothing
        Me.btnBrowsePic.OnDisabledState.IconRightImage = Nothing
        Me.btnBrowsePic.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBrowsePic.onHoverState.BorderRadius = 18
        Me.btnBrowsePic.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnBrowsePic.onHoverState.BorderThickness = 1
        Me.btnBrowsePic.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBrowsePic.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnBrowsePic.onHoverState.IconLeftImage = Nothing
        Me.btnBrowsePic.onHoverState.IconRightImage = Nothing
        Me.btnBrowsePic.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnBrowsePic.OnIdleState.BorderRadius = 18
        Me.btnBrowsePic.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnBrowsePic.OnIdleState.BorderThickness = 1
        Me.btnBrowsePic.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnBrowsePic.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnBrowsePic.OnIdleState.IconLeftImage = Nothing
        Me.btnBrowsePic.OnIdleState.IconRightImage = Nothing
        Me.btnBrowsePic.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnBrowsePic.OnPressedState.BorderRadius = 18
        Me.btnBrowsePic.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnBrowsePic.OnPressedState.BorderThickness = 1
        Me.btnBrowsePic.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnBrowsePic.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnBrowsePic.OnPressedState.IconLeftImage = Nothing
        Me.btnBrowsePic.OnPressedState.IconRightImage = Nothing
        Me.btnBrowsePic.Size = New System.Drawing.Size(209, 40)
        Me.btnBrowsePic.TabIndex = 53
        Me.btnBrowsePic.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnBrowsePic.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnBrowsePic.TextMarginLeft = 0
        Me.btnBrowsePic.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnBrowsePic.UseDefaultRadiusAndThickness = True
        '
        'lblStudentPic
        '
        Me.lblStudentPic.AllowParentOverrides = False
        Me.lblStudentPic.AutoEllipsis = False
        Me.lblStudentPic.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblStudentPic.CursorType = System.Windows.Forms.Cursors.Default
        Me.lblStudentPic.Font = New System.Drawing.Font("Cascadia Mono", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentPic.Location = New System.Drawing.Point(86, 17)
        Me.lblStudentPic.Name = "lblStudentPic"
        Me.lblStudentPic.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblStudentPic.Size = New System.Drawing.Size(135, 21)
        Me.lblStudentPic.TabIndex = 52
        Me.lblStudentPic.Text = "Student Picture"
        Me.lblStudentPic.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblStudentPic.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'ElipseFrmStudent
        '
        Me.ElipseFrmStudent.ElipseRadius = 23
        Me.ElipseFrmStudent.TargetControl = Me
        '
        'snbInformation
        '
        Me.snbInformation.AllowDragging = False
        Me.snbInformation.AllowMultipleViews = True
        Me.snbInformation.ClickToClose = True
        Me.snbInformation.DoubleClickToClose = True
        Me.snbInformation.DurationAfterIdle = 3000
        Me.snbInformation.ErrorOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.ErrorOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.ErrorOptions.ActionBorderRadius = 1
        Me.snbInformation.ErrorOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.ErrorOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.ErrorOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.ErrorOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.ErrorOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.snbInformation.ErrorOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.ErrorOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.ErrorOptions.Icon = CType(resources.GetObject("resource.Icon"), System.Drawing.Image)
        Me.snbInformation.ErrorOptions.IconLeftMargin = 12
        Me.snbInformation.FadeCloseIcon = False
        Me.snbInformation.Host = Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner
        Me.snbInformation.InformationOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.InformationOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.InformationOptions.ActionBorderRadius = 1
        Me.snbInformation.InformationOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.InformationOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.InformationOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.InformationOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.InformationOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(213, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.InformationOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.InformationOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.InformationOptions.Icon = CType(resources.GetObject("resource.Icon1"), System.Drawing.Image)
        Me.snbInformation.InformationOptions.IconLeftMargin = 12
        Me.snbInformation.Margin = 10
        Me.snbInformation.MaximumSize = New System.Drawing.Size(0, 0)
        Me.snbInformation.MaximumViews = 7
        Me.snbInformation.MessageRightMargin = 15
        Me.snbInformation.MinimumSize = New System.Drawing.Size(0, 0)
        Me.snbInformation.ShowBorders = False
        Me.snbInformation.ShowCloseIcon = False
        Me.snbInformation.ShowIcon = True
        Me.snbInformation.ShowShadows = True
        Me.snbInformation.SuccessOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.SuccessOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.SuccessOptions.ActionBorderRadius = 1
        Me.snbInformation.SuccessOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.SuccessOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.SuccessOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.SuccessOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.SuccessOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.snbInformation.SuccessOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.SuccessOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.SuccessOptions.Icon = CType(resources.GetObject("resource.Icon2"), System.Drawing.Image)
        Me.snbInformation.SuccessOptions.IconLeftMargin = 12
        Me.snbInformation.ViewsMargin = 7
        Me.snbInformation.WarningOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.WarningOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.WarningOptions.ActionBorderRadius = 1
        Me.snbInformation.WarningOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.WarningOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.WarningOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.WarningOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.WarningOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.snbInformation.WarningOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.WarningOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.WarningOptions.Icon = CType(resources.GetObject("resource.Icon3"), System.Drawing.Image)
        Me.snbInformation.WarningOptions.IconLeftMargin = 12
        Me.snbInformation.ZoomCloseIcon = True
        '
        'frmStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1107, 544)
        Me.ControlBox = False
        Me.Controls.Add(Me.BunifuPanel1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.pnlStudentInfo)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.pnlTopBar)
        Me.Controls.Add(Me.pnlPersonalInfo)
        Me.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmStudent"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlTopBar.ResumeLayout(False)
        Me.pnlTopBar.PerformLayout()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlPersonalInfo.ResumeLayout(False)
        Me.pnlPersonalInfo.PerformLayout()
        Me.pnlStudentInfo.ResumeLayout(False)
        Me.pnlStudentInfo.PerformLayout()
        CType(Me.pcbImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BunifuPanel1.ResumeLayout(False)
        Me.BunifuPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Public WithEvents btnUpdate As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents cboProgram As Bunifu.UI.WinForms.BunifuDropdown
    Friend WithEvents lblType As Bunifu.UI.WinForms.BunifuLabel
    Public WithEvents btnSave As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents pnlTopBar As Panel
    Friend WithEvents pcbClose As PictureBox
    Friend WithEvents lblProgramDetails As Label
    Friend WithEvents lblPersonalInfo As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel2 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtLName As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel3 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtFName As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents pnlPersonalInfo As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents txtMName As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel4 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtStudentNo As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel1 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents pnlStudentInfo As Bunifu.UI.WinForms.BunifuPanel
    Friend WithEvents txtContact As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents cboSection As Bunifu.UI.WinForms.BunifuDropdown
    Friend WithEvents BunifuLabel7 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel6 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents BunifuLabel5 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtAddress As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents BunifuLabel8 As Bunifu.UI.WinForms.BunifuLabel
    Public WithEvents btnCancel As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents pcbImage As Bunifu.UI.WinForms.BunifuPictureBox
    Friend WithEvents BunifuPanel1 As Bunifu.UI.WinForms.BunifuPanel
    Public WithEvents btnBrowsePic As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents lblStudentPic As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents ElipseFrmStudent As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents snbInformation As Bunifu.UI.WinForms.BunifuSnackbar
End Class
