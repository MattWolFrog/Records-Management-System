﻿

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMessageDialogue
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMessageDialogue))
        Dim BorderEdges1 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim BorderEdges2 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Me.pnlTopBar = New System.Windows.Forms.Panel()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pcbMinimize = New System.Windows.Forms.PictureBox()
        Me.pcbClose = New System.Windows.Forms.PictureBox()
        Me.lblQuestion = New System.Windows.Forms.Label()
        Me.btnYes = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.btnNo = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.ElipseFrmMsgDia = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.pnlTopBar.SuspendLayout()
        CType(Me.pcbMinimize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlTopBar
        '
        Me.pnlTopBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.pnlTopBar.Controls.Add(Me.lblTitle)
        Me.pnlTopBar.Controls.Add(Me.pcbMinimize)
        Me.pnlTopBar.Controls.Add(Me.pcbClose)
        Me.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTopBar.Location = New System.Drawing.Point(0, 0)
        Me.pnlTopBar.Name = "pnlTopBar"
        Me.pnlTopBar.Size = New System.Drawing.Size(360, 32)
        Me.pnlTopBar.TabIndex = 2
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.Color.White
        Me.lblTitle.Location = New System.Drawing.Point(9, 6)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(44, 21)
        Me.lblTitle.TabIndex = 4
        Me.lblTitle.Text = "Title"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pcbMinimize
        '
        Me.pcbMinimize.BackColor = System.Drawing.Color.Transparent
        Me.pcbMinimize.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_minimize_24__1_
        Me.pcbMinimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pcbMinimize.Dock = System.Windows.Forms.DockStyle.Right
        Me.pcbMinimize.Location = New System.Drawing.Point(300, 0)
        Me.pcbMinimize.Name = "pcbMinimize"
        Me.pcbMinimize.Size = New System.Drawing.Size(30, 32)
        Me.pcbMinimize.TabIndex = 6
        Me.pcbMinimize.TabStop = False
        '
        'pcbClose
        '
        Me.pcbClose.BackColor = System.Drawing.Color.Transparent
        Me.pcbClose.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_close_24__1_
        Me.pcbClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pcbClose.Dock = System.Windows.Forms.DockStyle.Right
        Me.pcbClose.Location = New System.Drawing.Point(330, 0)
        Me.pcbClose.Name = "pcbClose"
        Me.pcbClose.Size = New System.Drawing.Size(30, 32)
        Me.pcbClose.TabIndex = 5
        Me.pcbClose.TabStop = False
        '
        'lblQuestion
        '
        Me.lblQuestion.Font = New System.Drawing.Font("Nirmala UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuestion.ForeColor = System.Drawing.Color.Black
        Me.lblQuestion.Location = New System.Drawing.Point(60, 79)
        Me.lblQuestion.Name = "lblQuestion"
        Me.lblQuestion.Size = New System.Drawing.Size(240, 21)
        Me.lblQuestion.TabIndex = 5
        Me.lblQuestion.Text = "Are you sure you want to logout?"
        Me.lblQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnYes
        '
        Me.btnYes.AllowAnimations = True
        Me.btnYes.AllowMouseEffects = True
        Me.btnYes.AllowToggling = False
        Me.btnYes.AnimationSpeed = 200
        Me.btnYes.AutoGenerateColors = False
        Me.btnYes.AutoRoundBorders = True
        Me.btnYes.AutoSizeLeftIcon = True
        Me.btnYes.AutoSizeRightIcon = True
        Me.btnYes.BackColor = System.Drawing.Color.Transparent
        Me.btnYes.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnYes.BackgroundImage = CType(resources.GetObject("btnYes.BackgroundImage"), System.Drawing.Image)
        Me.btnYes.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnYes.ButtonText = "Yes"
        Me.btnYes.ButtonTextMarginLeft = 0
        Me.btnYes.ColorContrastOnClick = 45
        Me.btnYes.ColorContrastOnHover = 45
        Me.btnYes.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges1.BottomLeft = True
        BorderEdges1.BottomRight = True
        BorderEdges1.TopLeft = True
        BorderEdges1.TopRight = True
        Me.btnYes.CustomizableEdges = BorderEdges1
        Me.btnYes.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnYes.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnYes.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnYes.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnYes.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnYes.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnYes.ForeColor = System.Drawing.Color.White
        Me.btnYes.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnYes.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnYes.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnYes.IconMarginLeft = 11
        Me.btnYes.IconPadding = 10
        Me.btnYes.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnYes.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnYes.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnYes.IconSize = 25
        Me.btnYes.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnYes.IdleBorderRadius = 32
        Me.btnYes.IdleBorderThickness = 1
        Me.btnYes.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnYes.IdleIconLeftImage = Nothing
        Me.btnYes.IdleIconRightImage = Nothing
        Me.btnYes.IndicateFocus = False
        Me.btnYes.Location = New System.Drawing.Point(105, 145)
        Me.btnYes.Name = "btnYes"
        Me.btnYes.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnYes.OnDisabledState.BorderRadius = 1
        Me.btnYes.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnYes.OnDisabledState.BorderThickness = 1
        Me.btnYes.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnYes.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnYes.OnDisabledState.IconLeftImage = Nothing
        Me.btnYes.OnDisabledState.IconRightImage = Nothing
        Me.btnYes.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnYes.onHoverState.BorderRadius = 1
        Me.btnYes.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnYes.onHoverState.BorderThickness = 1
        Me.btnYes.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnYes.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnYes.onHoverState.IconLeftImage = Nothing
        Me.btnYes.onHoverState.IconRightImage = Nothing
        Me.btnYes.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnYes.OnIdleState.BorderRadius = 1
        Me.btnYes.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnYes.OnIdleState.BorderThickness = 1
        Me.btnYes.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnYes.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnYes.OnIdleState.IconLeftImage = Nothing
        Me.btnYes.OnIdleState.IconRightImage = Nothing
        Me.btnYes.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnYes.OnPressedState.BorderRadius = 1
        Me.btnYes.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnYes.OnPressedState.BorderThickness = 1
        Me.btnYes.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnYes.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnYes.OnPressedState.IconLeftImage = Nothing
        Me.btnYes.OnPressedState.IconRightImage = Nothing
        Me.btnYes.Size = New System.Drawing.Size(63, 34)
        Me.btnYes.TabIndex = 6
        Me.btnYes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnYes.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnYes.TextMarginLeft = 0
        Me.btnYes.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnYes.UseDefaultRadiusAndThickness = True
        '
        'btnNo
        '
        Me.btnNo.AllowAnimations = True
        Me.btnNo.AllowMouseEffects = True
        Me.btnNo.AllowToggling = False
        Me.btnNo.AnimationSpeed = 200
        Me.btnNo.AutoGenerateColors = False
        Me.btnNo.AutoRoundBorders = True
        Me.btnNo.AutoSizeLeftIcon = True
        Me.btnNo.AutoSizeRightIcon = True
        Me.btnNo.BackColor = System.Drawing.Color.Transparent
        Me.btnNo.BackColor1 = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnNo.BackgroundImage = CType(resources.GetObject("btnNo.BackgroundImage"), System.Drawing.Image)
        Me.btnNo.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnNo.ButtonText = "No"
        Me.btnNo.ButtonTextMarginLeft = 0
        Me.btnNo.ColorContrastOnClick = 45
        Me.btnNo.ColorContrastOnHover = 45
        Me.btnNo.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges2.BottomLeft = True
        BorderEdges2.BottomRight = True
        BorderEdges2.TopLeft = True
        BorderEdges2.TopRight = True
        Me.btnNo.CustomizableEdges = BorderEdges2
        Me.btnNo.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnNo.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnNo.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnNo.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnNo.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnNo.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btnNo.ForeColor = System.Drawing.Color.White
        Me.btnNo.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnNo.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnNo.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnNo.IconMarginLeft = 11
        Me.btnNo.IconPadding = 10
        Me.btnNo.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnNo.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnNo.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnNo.IconSize = 25
        Me.btnNo.IdleBorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnNo.IdleBorderRadius = 32
        Me.btnNo.IdleBorderThickness = 1
        Me.btnNo.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnNo.IdleIconLeftImage = Nothing
        Me.btnNo.IdleIconRightImage = Nothing
        Me.btnNo.IndicateFocus = False
        Me.btnNo.Location = New System.Drawing.Point(193, 145)
        Me.btnNo.Name = "btnNo"
        Me.btnNo.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnNo.OnDisabledState.BorderRadius = 1
        Me.btnNo.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnNo.OnDisabledState.BorderThickness = 1
        Me.btnNo.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnNo.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnNo.OnDisabledState.IconLeftImage = Nothing
        Me.btnNo.OnDisabledState.IconRightImage = Nothing
        Me.btnNo.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnNo.onHoverState.BorderRadius = 1
        Me.btnNo.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnNo.onHoverState.BorderThickness = 1
        Me.btnNo.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnNo.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnNo.onHoverState.IconLeftImage = Nothing
        Me.btnNo.onHoverState.IconRightImage = Nothing
        Me.btnNo.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnNo.OnIdleState.BorderRadius = 1
        Me.btnNo.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnNo.OnIdleState.BorderThickness = 1
        Me.btnNo.OnIdleState.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnNo.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnNo.OnIdleState.IconLeftImage = Nothing
        Me.btnNo.OnIdleState.IconRightImage = Nothing
        Me.btnNo.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnNo.OnPressedState.BorderRadius = 1
        Me.btnNo.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnNo.OnPressedState.BorderThickness = 1
        Me.btnNo.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnNo.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnNo.OnPressedState.IconLeftImage = Nothing
        Me.btnNo.OnPressedState.IconRightImage = Nothing
        Me.btnNo.Size = New System.Drawing.Size(63, 34)
        Me.btnNo.TabIndex = 7
        Me.btnNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnNo.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnNo.TextMarginLeft = 0
        Me.btnNo.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnNo.UseDefaultRadiusAndThickness = True
        '
        'ElipseFrmMsgDia
        '
        Me.ElipseFrmMsgDia.ElipseRadius = 5
        Me.ElipseFrmMsgDia.TargetControl = Me
        '
        'frmMessageDialogue
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(360, 239)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnNo)
        Me.Controls.Add(Me.btnYes)
        Me.Controls.Add(Me.lblQuestion)
        Me.Controls.Add(Me.pnlTopBar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmMessageDialogue"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlTopBar.ResumeLayout(False)
        Me.pnlTopBar.PerformLayout()
        CType(Me.pcbMinimize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlTopBar As Panel
    Friend WithEvents pcbMinimize As PictureBox
    Friend WithEvents pcbClose As PictureBox
    Public WithEvents lblTitle As Label
    Public WithEvents lblQuestion As Label
    Public WithEvents btnYes As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Public WithEvents btnNo As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents ElipseFrmMsgDia As Bunifu.Framework.UI.BunifuElipse
End Class
