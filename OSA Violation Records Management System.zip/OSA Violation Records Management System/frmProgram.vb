﻿Imports System.Data.OleDb
Public Class frmProgram
    Private Sub pcbClose_Click(sender As Object, e As EventArgs) Handles pcbClose.Click
        Dim customMessageBox As New frmMessageDialogue("Exit Program Details", "Do you want to exit?", "Yes", "No")
        customMessageBox.ShowDialog()

        If customMessageBox.UserChoice = DialogResult.Yes Then
            Me.Dispose()
        End If
    End Sub

    Private Sub cboType_KeyPress(sender As Object, e As KeyPressEventArgs)
        e.Handled = True
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            ' Check if textboxes and combobox are empty
            If String.IsNullOrEmpty(txtPcode.Text) OrElse
           String.IsNullOrEmpty(txtDescription.Text) OrElse
           String.IsNullOrEmpty(cboType.Text) Then

                snbInformation.Show(Me,
            "Please fill in all fields before saving.",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return ' Exit the subroutine if any field is empty
            End If

            Dim customMessageBox As New frmMessageDialogue("Save", "Save record?", "Yes", "No")
            customMessageBox.ShowDialog()

            If customMessageBox.UserChoice = DialogResult.Yes Then
                cn.Open()
                cm = New OleDbCommand("insert into tblProgram(pcode, description, type)values(@pcode, @description, @type)", cn)
                With cm
                    .Parameters.AddWithValue("@pcode", txtPcode.Text)
                    .Parameters.AddWithValue("@description", txtDescription.Text)
                    .Parameters.AddWithValue("@type", cboType.Text)
                    .ExecuteNonQuery()
                End With
                cn.Close()
                snbInformation.Show(Me,
            "Record has been successfully saved",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Clear()
                With frmMain
                    .LoadRecordsProgram()
                End With
            End If
        Catch ex As Exception
            cn.Close()
            snbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)

        End Try
    End Sub

    Sub Clear()
        txtPcode.Clear()
        txtDescription.Clear()
        txtPcode.Enabled = True
        btnSave.Enabled = True
        btnUpdate.Enabled = False
        cboType.SelectedIndex = -1
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            ' Check if textboxes and combobox are empty
            If String.IsNullOrEmpty(txtPcode.Text) OrElse
           String.IsNullOrEmpty(txtDescription.Text) OrElse
           String.IsNullOrEmpty(cboType.Text) Then
                snbInformation.Show(Me,
            "Please fill in all fields before saving.",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Return ' Exit the subroutine if any field is empty
            End If

            Dim customMessageBox As New frmMessageDialogue("Update", "Update record?", "Yes", "No")
            customMessageBox.ShowDialog()

            If customMessageBox.UserChoice = DialogResult.Yes Then
                cn.Open()
                cm = New OleDbCommand("update tblProgram set description=@description, type=@type where pcode = @pcode", cn)
                With cm
                    .Parameters.AddWithValue("@description", txtDescription.Text)
                    .Parameters.AddWithValue("@type", cboType.Text)
                    .Parameters.AddWithValue("@pcode", txtPcode.Text)
                    .ExecuteNonQuery()
                End With
                cn.Close()
                snbInformation.Show(Me,
            "Record has been successfully updated",
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Success,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)
                Clear()
                With frmMain
                    .LoadRecordsProgram()
                End With
                Me.Dispose()
            End If
        Catch ex As Exception
            cn.Close()
            snbInformation.Show(Me,
            "Error:" & ex.Message,
            Bunifu.UI.WinForms.BunifuSnackbar.MessageTypes.Error,
             4000, "Dismiss",
            Bunifu.UI.WinForms.BunifuSnackbar.Positions.BottomRight,
            Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner)

        End Try
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Dispose()
    End Sub

End Class