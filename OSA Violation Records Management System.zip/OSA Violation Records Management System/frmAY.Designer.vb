﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAY
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAY))
        Dim BorderEdges1 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim StateProperties1 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties2 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties3 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties4 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties5 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties6 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties7 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties8 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim BorderEdges2 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Dim StateProperties9 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties10 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties11 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim StateProperties12 As Bunifu.UI.WinForms.BunifuTextBox.StateProperties = New Bunifu.UI.WinForms.BunifuTextBox.StateProperties()
        Dim BorderEdges3 As Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges = New Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges()
        Me.cboSem = New Bunifu.UI.WinForms.BunifuDropdown()
        Me.lblType = New Bunifu.UI.WinForms.BunifuLabel()
        Me.lblDescription = New Bunifu.UI.WinForms.BunifuLabel()
        Me.lblSectionID = New Bunifu.UI.WinForms.BunifuLabel()
        Me.pnlTopBar = New System.Windows.Forms.Panel()
        Me.pcbClose = New System.Windows.Forms.PictureBox()
        Me.lblProgramDetails = New System.Windows.Forms.Label()
        Me.btnUpdate = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.txtFrom = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.txtCode = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.btnSave = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.ElipseFrmAY = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.BunifuLabel1 = New Bunifu.UI.WinForms.BunifuLabel()
        Me.txtTo = New Bunifu.UI.WinForms.BunifuTextBox()
        Me.btnCancel = New Bunifu.UI.WinForms.BunifuButton.BunifuButton()
        Me.snbInformation = New Bunifu.UI.WinForms.BunifuSnackbar(Me.components)
        Me.pnlTopBar.SuspendLayout()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cboSem
        '
        Me.cboSem.BackColor = System.Drawing.Color.Transparent
        Me.cboSem.BackgroundColor = System.Drawing.Color.White
        Me.cboSem.BorderColor = System.Drawing.Color.Silver
        Me.cboSem.BorderRadius = 17
        Me.cboSem.Color = System.Drawing.Color.Silver
        Me.cboSem.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down
        Me.cboSem.DisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboSem.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.cboSem.DisabledColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.cboSem.DisabledForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.cboSem.DisabledIndicatorColor = System.Drawing.Color.DarkGray
        Me.cboSem.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cboSem.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin
        Me.cboSem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSem.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboSem.FillDropDown = True
        Me.cboSem.FillIndicator = False
        Me.cboSem.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cboSem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.cboSem.ForeColor = System.Drawing.Color.Black
        Me.cboSem.FormattingEnabled = True
        Me.cboSem.Icon = Nothing
        Me.cboSem.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboSem.IndicatorColor = System.Drawing.Color.Gray
        Me.cboSem.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right
        Me.cboSem.ItemBackColor = System.Drawing.Color.White
        Me.cboSem.ItemBorderColor = System.Drawing.Color.Transparent
        Me.cboSem.ItemForeColor = System.Drawing.Color.Black
        Me.cboSem.ItemHeight = 26
        Me.cboSem.ItemHighLightColor = System.Drawing.Color.DodgerBlue
        Me.cboSem.ItemHighLightForeColor = System.Drawing.Color.White
        Me.cboSem.Items.AddRange(New Object() {"1ST SEMESTER", "2ND SEMESTER", "SUMMER"})
        Me.cboSem.ItemTopMargin = 3
        Me.cboSem.Location = New System.Drawing.Point(158, 190)
        Me.cboSem.Name = "cboSem"
        Me.cboSem.Size = New System.Drawing.Size(205, 32)
        Me.cboSem.TabIndex = 41
        Me.cboSem.Text = Nothing
        Me.cboSem.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left
        Me.cboSem.TextLeftMargin = 5
        '
        'lblType
        '
        Me.lblType.AllowParentOverrides = False
        Me.lblType.AutoEllipsis = False
        Me.lblType.CursorType = Nothing
        Me.lblType.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblType.Location = New System.Drawing.Point(74, 190)
        Me.lblType.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblType.Name = "lblType"
        Me.lblType.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblType.Size = New System.Drawing.Size(65, 21)
        Me.lblType.TabIndex = 40
        Me.lblType.Text = "Semester"
        Me.lblType.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblType.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'lblDescription
        '
        Me.lblDescription.AllowParentOverrides = False
        Me.lblDescription.AutoEllipsis = False
        Me.lblDescription.CursorType = Nothing
        Me.lblDescription.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescription.Location = New System.Drawing.Point(67, 141)
        Me.lblDescription.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDescription.Size = New System.Drawing.Size(72, 21)
        Me.lblDescription.TabIndex = 39
        Me.lblDescription.Text = "Year From"
        Me.lblDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblDescription.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'lblSectionID
        '
        Me.lblSectionID.AllowParentOverrides = False
        Me.lblSectionID.AutoEllipsis = False
        Me.lblSectionID.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblSectionID.CursorType = System.Windows.Forms.Cursors.Default
        Me.lblSectionID.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSectionID.Location = New System.Drawing.Point(74, 90)
        Me.lblSectionID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.lblSectionID.Name = "lblSectionID"
        Me.lblSectionID.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblSectionID.Size = New System.Drawing.Size(65, 21)
        Me.lblSectionID.TabIndex = 37
        Me.lblSectionID.Text = "A.Y. Code"
        Me.lblSectionID.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.lblSectionID.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'pnlTopBar
        '
        Me.pnlTopBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.pnlTopBar.Controls.Add(Me.pcbClose)
        Me.pnlTopBar.Controls.Add(Me.lblProgramDetails)
        Me.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTopBar.Location = New System.Drawing.Point(0, 0)
        Me.pnlTopBar.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pnlTopBar.Name = "pnlTopBar"
        Me.pnlTopBar.Size = New System.Drawing.Size(734, 37)
        Me.pnlTopBar.TabIndex = 34
        '
        'pcbClose
        '
        Me.pcbClose.BackColor = System.Drawing.Color.Transparent
        Me.pcbClose.BackgroundImage = Global.OSA_Violation_Records_Management_System.My.Resources.Resources.icons8_close_24__1_
        Me.pcbClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.pcbClose.Dock = System.Windows.Forms.DockStyle.Right
        Me.pcbClose.Location = New System.Drawing.Point(704, 0)
        Me.pcbClose.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pcbClose.Name = "pcbClose"
        Me.pcbClose.Size = New System.Drawing.Size(30, 37)
        Me.pcbClose.TabIndex = 5
        Me.pcbClose.TabStop = False
        '
        'lblProgramDetails
        '
        Me.lblProgramDetails.AutoSize = True
        Me.lblProgramDetails.Font = New System.Drawing.Font("Segoe UI Semibold", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgramDetails.Location = New System.Drawing.Point(7, 6)
        Me.lblProgramDetails.Name = "lblProgramDetails"
        Me.lblProgramDetails.Size = New System.Drawing.Size(201, 25)
        Me.lblProgramDetails.TabIndex = 0
        Me.lblProgramDetails.Text = "Academic Year Details"
        '
        'btnUpdate
        '
        Me.btnUpdate.AllowAnimations = True
        Me.btnUpdate.AllowMouseEffects = True
        Me.btnUpdate.AllowToggling = False
        Me.btnUpdate.AnimationSpeed = 200
        Me.btnUpdate.AutoGenerateColors = False
        Me.btnUpdate.AutoRoundBorders = False
        Me.btnUpdate.AutoSizeLeftIcon = True
        Me.btnUpdate.AutoSizeRightIcon = True
        Me.btnUpdate.BackColor = System.Drawing.Color.Transparent
        Me.btnUpdate.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.BackgroundImage = CType(resources.GetObject("btnUpdate.BackgroundImage"), System.Drawing.Image)
        Me.btnUpdate.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.ButtonText = "Update"
        Me.btnUpdate.ButtonTextMarginLeft = 0
        Me.btnUpdate.ColorContrastOnClick = 45
        Me.btnUpdate.ColorContrastOnHover = 45
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges1.BottomLeft = True
        BorderEdges1.BottomRight = True
        BorderEdges1.TopLeft = True
        BorderEdges1.TopRight = True
        Me.btnUpdate.CustomizableEdges = BorderEdges1
        Me.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnUpdate.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnUpdate.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUpdate.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUpdate.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnUpdate.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnUpdate.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnUpdate.IconMarginLeft = 11
        Me.btnUpdate.IconPadding = 10
        Me.btnUpdate.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnUpdate.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnUpdate.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnUpdate.IconSize = 25
        Me.btnUpdate.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.IdleBorderRadius = 18
        Me.btnUpdate.IdleBorderThickness = 1
        Me.btnUpdate.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.IdleIconLeftImage = Nothing
        Me.btnUpdate.IdleIconRightImage = Nothing
        Me.btnUpdate.IndicateFocus = False
        Me.btnUpdate.Location = New System.Drawing.Point(505, 190)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnUpdate.OnDisabledState.BorderRadius = 18
        Me.btnUpdate.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnDisabledState.BorderThickness = 1
        Me.btnUpdate.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnUpdate.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnUpdate.OnDisabledState.IconLeftImage = Nothing
        Me.btnUpdate.OnDisabledState.IconRightImage = Nothing
        Me.btnUpdate.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUpdate.onHoverState.BorderRadius = 18
        Me.btnUpdate.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.onHoverState.BorderThickness = 1
        Me.btnUpdate.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnUpdate.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.onHoverState.IconLeftImage = Nothing
        Me.btnUpdate.onHoverState.IconRightImage = Nothing
        Me.btnUpdate.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.OnIdleState.BorderRadius = 18
        Me.btnUpdate.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnIdleState.BorderThickness = 1
        Me.btnUpdate.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnUpdate.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.OnIdleState.IconLeftImage = Nothing
        Me.btnUpdate.OnIdleState.IconRightImage = Nothing
        Me.btnUpdate.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnUpdate.OnPressedState.BorderRadius = 18
        Me.btnUpdate.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnUpdate.OnPressedState.BorderThickness = 1
        Me.btnUpdate.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnUpdate.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.OnPressedState.IconLeftImage = Nothing
        Me.btnUpdate.OnPressedState.IconRightImage = Nothing
        Me.btnUpdate.Size = New System.Drawing.Size(78, 40)
        Me.btnUpdate.TabIndex = 42
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnUpdate.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnUpdate.TextMarginLeft = 0
        Me.btnUpdate.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnUpdate.UseDefaultRadiusAndThickness = True
        '
        'txtFrom
        '
        Me.txtFrom.AcceptsReturn = False
        Me.txtFrom.AcceptsTab = False
        Me.txtFrom.AnimationSpeed = 200
        Me.txtFrom.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtFrom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtFrom.BackColor = System.Drawing.Color.White
        Me.txtFrom.BackgroundImage = CType(resources.GetObject("txtFrom.BackgroundImage"), System.Drawing.Image)
        Me.txtFrom.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtFrom.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtFrom.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtFrom.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtFrom.BorderRadius = 1
        Me.txtFrom.BorderThickness = 1
        Me.txtFrom.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtFrom.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFrom.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtFrom.DefaultText = ""
        Me.txtFrom.FillColor = System.Drawing.Color.White
        Me.txtFrom.HideSelection = True
        Me.txtFrom.IconLeft = Nothing
        Me.txtFrom.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFrom.IconPadding = 10
        Me.txtFrom.IconRight = Nothing
        Me.txtFrom.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtFrom.Lines = New String(-1) {}
        Me.txtFrom.Location = New System.Drawing.Point(159, 131)
        Me.txtFrom.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFrom.MaxLength = 32767
        Me.txtFrom.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtFrom.Modified = False
        Me.txtFrom.Multiline = False
        Me.txtFrom.Name = "txtFrom"
        StateProperties1.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties1.FillColor = System.Drawing.Color.Empty
        StateProperties1.ForeColor = System.Drawing.Color.Empty
        StateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtFrom.OnActiveState = StateProperties1
        StateProperties2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties2.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtFrom.OnDisabledState = StateProperties2
        StateProperties3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties3.FillColor = System.Drawing.Color.Empty
        StateProperties3.ForeColor = System.Drawing.Color.Empty
        StateProperties3.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtFrom.OnHoverState = StateProperties3
        StateProperties4.BorderColor = System.Drawing.Color.Silver
        StateProperties4.FillColor = System.Drawing.Color.White
        StateProperties4.ForeColor = System.Drawing.Color.Empty
        StateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtFrom.OnIdleState = StateProperties4
        Me.txtFrom.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFrom.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtFrom.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtFrom.PlaceholderText = "Year From"
        Me.txtFrom.ReadOnly = False
        Me.txtFrom.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtFrom.SelectedText = ""
        Me.txtFrom.SelectionLength = 0
        Me.txtFrom.SelectionStart = 0
        Me.txtFrom.ShortcutsEnabled = True
        Me.txtFrom.Size = New System.Drawing.Size(204, 45)
        Me.txtFrom.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtFrom.TabIndex = 38
        Me.txtFrom.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtFrom.TextMarginBottom = 0
        Me.txtFrom.TextMarginLeft = 3
        Me.txtFrom.TextMarginTop = 0
        Me.txtFrom.TextPlaceholder = "Year From"
        Me.txtFrom.UseSystemPasswordChar = False
        Me.txtFrom.WordWrap = True
        '
        'txtCode
        '
        Me.txtCode.AcceptsReturn = False
        Me.txtCode.AcceptsTab = False
        Me.txtCode.AnimationSpeed = 200
        Me.txtCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtCode.BackColor = System.Drawing.Color.White
        Me.txtCode.BackgroundImage = CType(resources.GetObject("txtCode.BackgroundImage"), System.Drawing.Image)
        Me.txtCode.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtCode.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtCode.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCode.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtCode.BorderRadius = 1
        Me.txtCode.BorderThickness = 1
        Me.txtCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtCode.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCode.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtCode.DefaultText = ""
        Me.txtCode.FillColor = System.Drawing.Color.White
        Me.txtCode.HideSelection = True
        Me.txtCode.IconLeft = Nothing
        Me.txtCode.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCode.IconPadding = 10
        Me.txtCode.IconRight = Nothing
        Me.txtCode.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCode.Lines = New String(-1) {}
        Me.txtCode.Location = New System.Drawing.Point(159, 78)
        Me.txtCode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCode.MaxLength = 32767
        Me.txtCode.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtCode.Modified = False
        Me.txtCode.Multiline = False
        Me.txtCode.Name = "txtCode"
        StateProperties5.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties5.FillColor = System.Drawing.Color.Empty
        StateProperties5.ForeColor = System.Drawing.Color.Empty
        StateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCode.OnActiveState = StateProperties5
        StateProperties6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties6.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCode.OnDisabledState = StateProperties6
        StateProperties7.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties7.FillColor = System.Drawing.Color.Empty
        StateProperties7.ForeColor = System.Drawing.Color.Empty
        StateProperties7.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCode.OnHoverState = StateProperties7
        StateProperties8.BorderColor = System.Drawing.Color.Silver
        StateProperties8.FillColor = System.Drawing.Color.White
        StateProperties8.ForeColor = System.Drawing.Color.Empty
        StateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtCode.OnIdleState = StateProperties8
        Me.txtCode.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCode.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtCode.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtCode.PlaceholderText = "Academic Year Code"
        Me.txtCode.ReadOnly = False
        Me.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtCode.SelectedText = ""
        Me.txtCode.SelectionLength = 0
        Me.txtCode.SelectionStart = 0
        Me.txtCode.ShortcutsEnabled = True
        Me.txtCode.Size = New System.Drawing.Size(507, 45)
        Me.txtCode.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtCode.TabIndex = 36
        Me.txtCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtCode.TextMarginBottom = 0
        Me.txtCode.TextMarginLeft = 3
        Me.txtCode.TextMarginTop = 0
        Me.txtCode.TextPlaceholder = "Academic Year Code"
        Me.txtCode.UseSystemPasswordChar = False
        Me.txtCode.WordWrap = True
        '
        'btnSave
        '
        Me.btnSave.AllowAnimations = True
        Me.btnSave.AllowMouseEffects = True
        Me.btnSave.AllowToggling = False
        Me.btnSave.AnimationSpeed = 200
        Me.btnSave.AutoGenerateColors = False
        Me.btnSave.AutoRoundBorders = False
        Me.btnSave.AutoSizeLeftIcon = True
        Me.btnSave.AutoSizeRightIcon = True
        Me.btnSave.BackColor = System.Drawing.Color.Transparent
        Me.btnSave.BackColor1 = System.Drawing.Color.DodgerBlue
        Me.btnSave.BackgroundImage = CType(resources.GetObject("btnSave.BackgroundImage"), System.Drawing.Image)
        Me.btnSave.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.ButtonText = "Save"
        Me.btnSave.ButtonTextMarginLeft = 0
        Me.btnSave.ColorContrastOnClick = 45
        Me.btnSave.ColorContrastOnHover = 45
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges2.BottomLeft = True
        BorderEdges2.BottomRight = True
        BorderEdges2.TopLeft = True
        BorderEdges2.TopRight = True
        Me.btnSave.CustomizableEdges = BorderEdges2
        Me.btnSave.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnSave.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSave.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSave.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSave.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSave.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnSave.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnSave.IconMarginLeft = 11
        Me.btnSave.IconPadding = 10
        Me.btnSave.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSave.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnSave.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnSave.IconSize = 25
        Me.btnSave.IdleBorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.IdleBorderRadius = 18
        Me.btnSave.IdleBorderThickness = 1
        Me.btnSave.IdleFillColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.IdleIconLeftImage = Nothing
        Me.btnSave.IdleIconRightImage = Nothing
        Me.btnSave.IndicateFocus = False
        Me.btnSave.Location = New System.Drawing.Point(421, 190)
        Me.btnSave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnSave.OnDisabledState.BorderRadius = 18
        Me.btnSave.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnDisabledState.BorderThickness = 1
        Me.btnSave.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnSave.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnSave.OnDisabledState.IconLeftImage = Nothing
        Me.btnSave.OnDisabledState.IconRightImage = Nothing
        Me.btnSave.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.onHoverState.BorderRadius = 18
        Me.btnSave.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.onHoverState.BorderThickness = 1
        Me.btnSave.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnSave.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnSave.onHoverState.IconLeftImage = Nothing
        Me.btnSave.onHoverState.IconRightImage = Nothing
        Me.btnSave.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.OnIdleState.BorderRadius = 18
        Me.btnSave.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnIdleState.BorderThickness = 1
        Me.btnSave.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue
        Me.btnSave.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnSave.OnIdleState.IconLeftImage = Nothing
        Me.btnSave.OnIdleState.IconRightImage = Nothing
        Me.btnSave.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSave.OnPressedState.BorderRadius = 18
        Me.btnSave.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnSave.OnPressedState.BorderThickness = 1
        Me.btnSave.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.btnSave.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnSave.OnPressedState.IconLeftImage = Nothing
        Me.btnSave.OnPressedState.IconRightImage = Nothing
        Me.btnSave.Size = New System.Drawing.Size(78, 40)
        Me.btnSave.TabIndex = 35
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSave.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnSave.TextMarginLeft = 0
        Me.btnSave.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnSave.UseDefaultRadiusAndThickness = True
        '
        'ElipseFrmAY
        '
        Me.ElipseFrmAY.ElipseRadius = 23
        Me.ElipseFrmAY.TargetControl = Me
        '
        'BunifuLabel1
        '
        Me.BunifuLabel1.AllowParentOverrides = False
        Me.BunifuLabel1.AutoEllipsis = False
        Me.BunifuLabel1.CursorType = Nothing
        Me.BunifuLabel1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BunifuLabel1.Location = New System.Drawing.Point(391, 141)
        Me.BunifuLabel1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuLabel1.Name = "BunifuLabel1"
        Me.BunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BunifuLabel1.Size = New System.Drawing.Size(52, 21)
        Me.BunifuLabel1.TabIndex = 45
        Me.BunifuLabel1.Text = "Year To"
        Me.BunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.BunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.[Default]
        '
        'txtTo
        '
        Me.txtTo.AcceptsReturn = False
        Me.txtTo.AcceptsTab = False
        Me.txtTo.AnimationSpeed = 200
        Me.txtTo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None
        Me.txtTo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None
        Me.txtTo.BackColor = System.Drawing.Color.White
        Me.txtTo.BackgroundImage = CType(resources.GetObject("txtTo.BackgroundImage"), System.Drawing.Image)
        Me.txtTo.BorderColorActive = System.Drawing.Color.DodgerBlue
        Me.txtTo.BorderColorDisabled = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.txtTo.BorderColorHover = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTo.BorderColorIdle = System.Drawing.Color.Silver
        Me.txtTo.BorderRadius = 1
        Me.txtTo.BorderThickness = 1
        Me.txtTo.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal
        Me.txtTo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTo.DefaultFont = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtTo.DefaultText = ""
        Me.txtTo.FillColor = System.Drawing.Color.White
        Me.txtTo.HideSelection = True
        Me.txtTo.IconLeft = Nothing
        Me.txtTo.IconLeftCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTo.IconPadding = 10
        Me.txtTo.IconRight = Nothing
        Me.txtTo.IconRightCursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTo.Lines = New String(-1) {}
        Me.txtTo.Location = New System.Drawing.Point(462, 131)
        Me.txtTo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTo.MaxLength = 32767
        Me.txtTo.MinimumSize = New System.Drawing.Size(1, 1)
        Me.txtTo.Modified = False
        Me.txtTo.Multiline = False
        Me.txtTo.Name = "txtTo"
        StateProperties9.BorderColor = System.Drawing.Color.DodgerBlue
        StateProperties9.FillColor = System.Drawing.Color.Empty
        StateProperties9.ForeColor = System.Drawing.Color.Empty
        StateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtTo.OnActiveState = StateProperties9
        StateProperties10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        StateProperties10.FillColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        StateProperties10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(109, Byte), Integer))
        StateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtTo.OnDisabledState = StateProperties10
        StateProperties11.BorderColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        StateProperties11.FillColor = System.Drawing.Color.Empty
        StateProperties11.ForeColor = System.Drawing.Color.Empty
        StateProperties11.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(105, Byte), Integer), CType(CType(181, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTo.OnHoverState = StateProperties11
        StateProperties12.BorderColor = System.Drawing.Color.Silver
        StateProperties12.FillColor = System.Drawing.Color.White
        StateProperties12.ForeColor = System.Drawing.Color.Empty
        StateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty
        Me.txtTo.OnIdleState = StateProperties12
        Me.txtTo.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTo.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtTo.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.txtTo.PlaceholderText = "Year To"
        Me.txtTo.ReadOnly = False
        Me.txtTo.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.txtTo.SelectedText = ""
        Me.txtTo.SelectionLength = 0
        Me.txtTo.SelectionStart = 0
        Me.txtTo.ShortcutsEnabled = True
        Me.txtTo.Size = New System.Drawing.Size(204, 45)
        Me.txtTo.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Material
        Me.txtTo.TabIndex = 44
        Me.txtTo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtTo.TextMarginBottom = 0
        Me.txtTo.TextMarginLeft = 3
        Me.txtTo.TextMarginTop = 0
        Me.txtTo.TextPlaceholder = "Year To"
        Me.txtTo.UseSystemPasswordChar = False
        Me.txtTo.WordWrap = True
        '
        'btnCancel
        '
        Me.btnCancel.AllowAnimations = True
        Me.btnCancel.AllowMouseEffects = True
        Me.btnCancel.AllowToggling = False
        Me.btnCancel.AnimationSpeed = 200
        Me.btnCancel.AutoGenerateColors = False
        Me.btnCancel.AutoRoundBorders = False
        Me.btnCancel.AutoSizeLeftIcon = True
        Me.btnCancel.AutoSizeRightIcon = True
        Me.btnCancel.BackColor = System.Drawing.Color.Transparent
        Me.btnCancel.BackColor1 = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.BackgroundImage = CType(resources.GetObject("btnCancel.BackgroundImage"), System.Drawing.Image)
        Me.btnCancel.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.ButtonText = "Cancel"
        Me.btnCancel.ButtonTextMarginLeft = 0
        Me.btnCancel.ColorContrastOnClick = 45
        Me.btnCancel.ColorContrastOnHover = 45
        Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Default
        BorderEdges3.BottomLeft = True
        BorderEdges3.BottomRight = True
        BorderEdges3.TopLeft = True
        BorderEdges3.TopRight = True
        Me.btnCancel.CustomizableEdges = BorderEdges3
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.None
        Me.btnCancel.DisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnCancel.DisabledFillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnCancel.DisabledForecolor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnCancel.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed
        Me.btnCancel.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnCancel.IconLeftCursor = System.Windows.Forms.Cursors.Default
        Me.btnCancel.IconLeftPadding = New System.Windows.Forms.Padding(11, 3, 3, 3)
        Me.btnCancel.IconMarginLeft = 11
        Me.btnCancel.IconPadding = 10
        Me.btnCancel.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnCancel.IconRightCursor = System.Windows.Forms.Cursors.Default
        Me.btnCancel.IconRightPadding = New System.Windows.Forms.Padding(3, 3, 7, 3)
        Me.btnCancel.IconSize = 25
        Me.btnCancel.IdleBorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.IdleBorderRadius = 18
        Me.btnCancel.IdleBorderThickness = 1
        Me.btnCancel.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.IdleIconLeftImage = Nothing
        Me.btnCancel.IdleIconRightImage = Nothing
        Me.btnCancel.IndicateFocus = False
        Me.btnCancel.Location = New System.Drawing.Point(588, 190)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.btnCancel.OnDisabledState.BorderRadius = 18
        Me.btnCancel.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnDisabledState.BorderThickness = 1
        Me.btnCancel.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.btnCancel.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(168, Byte), Integer))
        Me.btnCancel.OnDisabledState.IconLeftImage = Nothing
        Me.btnCancel.OnDisabledState.IconRightImage = Nothing
        Me.btnCancel.onHoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.btnCancel.onHoverState.BorderRadius = 18
        Me.btnCancel.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.onHoverState.BorderThickness = 1
        Me.btnCancel.onHoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.btnCancel.onHoverState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.onHoverState.IconLeftImage = Nothing
        Me.btnCancel.onHoverState.IconRightImage = Nothing
        Me.btnCancel.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnIdleState.BorderRadius = 18
        Me.btnCancel.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnIdleState.BorderThickness = 1
        Me.btnCancel.OnIdleState.FillColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnIdleState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.OnIdleState.IconLeftImage = Nothing
        Me.btnCancel.OnIdleState.IconRightImage = Nothing
        Me.btnCancel.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnPressedState.BorderRadius = 18
        Me.btnCancel.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid
        Me.btnCancel.OnPressedState.BorderThickness = 1
        Me.btnCancel.OnPressedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(93, Byte), Integer), CType(CType(187, Byte), Integer), CType(CType(99, Byte), Integer))
        Me.btnCancel.OnPressedState.ForeColor = System.Drawing.Color.White
        Me.btnCancel.OnPressedState.IconLeftImage = Nothing
        Me.btnCancel.OnPressedState.IconRightImage = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(78, 40)
        Me.btnCancel.TabIndex = 51
        Me.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnCancel.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center
        Me.btnCancel.TextMarginLeft = 0
        Me.btnCancel.TextPadding = New System.Windows.Forms.Padding(0)
        Me.btnCancel.UseDefaultRadiusAndThickness = True
        '
        'snbInformation
        '
        Me.snbInformation.AllowDragging = False
        Me.snbInformation.AllowMultipleViews = True
        Me.snbInformation.ClickToClose = True
        Me.snbInformation.DoubleClickToClose = True
        Me.snbInformation.DurationAfterIdle = 3000
        Me.snbInformation.ErrorOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.ErrorOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.ErrorOptions.ActionBorderRadius = 1
        Me.snbInformation.ErrorOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.ErrorOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.ErrorOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.ErrorOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.ErrorOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(204, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.snbInformation.ErrorOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.ErrorOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.ErrorOptions.Icon = CType(resources.GetObject("resource.Icon"), System.Drawing.Image)
        Me.snbInformation.ErrorOptions.IconLeftMargin = 12
        Me.snbInformation.FadeCloseIcon = False
        Me.snbInformation.Host = Bunifu.UI.WinForms.BunifuSnackbar.Hosts.FormOwner
        Me.snbInformation.InformationOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.InformationOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.InformationOptions.ActionBorderRadius = 1
        Me.snbInformation.InformationOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.InformationOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.InformationOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.InformationOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.InformationOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(145, Byte), Integer), CType(CType(213, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.InformationOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.InformationOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.InformationOptions.Icon = CType(resources.GetObject("resource.Icon1"), System.Drawing.Image)
        Me.snbInformation.InformationOptions.IconLeftMargin = 12
        Me.snbInformation.Margin = 10
        Me.snbInformation.MaximumSize = New System.Drawing.Size(0, 0)
        Me.snbInformation.MaximumViews = 7
        Me.snbInformation.MessageRightMargin = 15
        Me.snbInformation.MinimumSize = New System.Drawing.Size(0, 0)
        Me.snbInformation.ShowBorders = False
        Me.snbInformation.ShowCloseIcon = False
        Me.snbInformation.ShowIcon = True
        Me.snbInformation.ShowShadows = True
        Me.snbInformation.SuccessOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.SuccessOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.SuccessOptions.ActionBorderRadius = 1
        Me.snbInformation.SuccessOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.SuccessOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.SuccessOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.SuccessOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.SuccessOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(237, Byte), Integer))
        Me.snbInformation.SuccessOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.SuccessOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.SuccessOptions.Icon = CType(resources.GetObject("resource.Icon2"), System.Drawing.Image)
        Me.snbInformation.SuccessOptions.IconLeftMargin = 12
        Me.snbInformation.ViewsMargin = 7
        Me.snbInformation.WarningOptions.ActionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.WarningOptions.ActionBorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.snbInformation.WarningOptions.ActionBorderRadius = 1
        Me.snbInformation.WarningOptions.ActionFont = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.snbInformation.WarningOptions.ActionForeColor = System.Drawing.Color.Black
        Me.snbInformation.WarningOptions.BackColor = System.Drawing.Color.White
        Me.snbInformation.WarningOptions.BorderColor = System.Drawing.Color.White
        Me.snbInformation.WarningOptions.CloseIconColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.snbInformation.WarningOptions.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.snbInformation.WarningOptions.ForeColor = System.Drawing.Color.Black
        Me.snbInformation.WarningOptions.Icon = CType(resources.GetObject("resource.Icon3"), System.Drawing.Image)
        Me.snbInformation.WarningOptions.IconLeftMargin = 12
        Me.snbInformation.ZoomCloseIcon = True
        '
        'frmAY
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(734, 299)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.BunifuLabel1)
        Me.Controls.Add(Me.txtTo)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.cboSem)
        Me.Controls.Add(Me.lblType)
        Me.Controls.Add(Me.lblDescription)
        Me.Controls.Add(Me.txtFrom)
        Me.Controls.Add(Me.lblSectionID)
        Me.Controls.Add(Me.txtCode)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.pnlTopBar)
        Me.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmAY"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlTopBar.ResumeLayout(False)
        Me.pnlTopBar.PerformLayout()
        CType(Me.pcbClose, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents btnUpdate As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents cboSem As Bunifu.UI.WinForms.BunifuDropdown
    Friend WithEvents lblType As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents lblDescription As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtFrom As Bunifu.UI.WinForms.BunifuTextBox
    Friend WithEvents lblSectionID As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtCode As Bunifu.UI.WinForms.BunifuTextBox
    Public WithEvents btnSave As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents pnlTopBar As Panel
    Friend WithEvents pcbClose As PictureBox
    Friend WithEvents lblProgramDetails As Label
    Friend WithEvents ElipseFrmAY As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents BunifuLabel1 As Bunifu.UI.WinForms.BunifuLabel
    Friend WithEvents txtTo As Bunifu.UI.WinForms.BunifuTextBox
    Public WithEvents btnCancel As Bunifu.UI.WinForms.BunifuButton.BunifuButton
    Friend WithEvents snbInformation As Bunifu.UI.WinForms.BunifuSnackbar
End Class
